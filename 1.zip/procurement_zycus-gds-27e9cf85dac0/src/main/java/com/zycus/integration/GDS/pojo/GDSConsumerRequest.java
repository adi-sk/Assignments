
package com.zycus.integration.GDS.pojo;

import com.fasterxml.jackson.annotation.JsonInclude;

/**
 *punit.sukhija
 *
 */
public class GDSConsumerRequest {
	
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private Long gdsProducerId;
	private String gdscId;
	private Long deliveryId;
	private Long timeStamp;
	private String sourceProductCode;
	private String consumerProductCode;
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private String additionalInfo;
	
	private EventInfo eventInfo;
	
	
	private String messageToDispatch;
	private String messageType;
	
	public String getGdscId() {
		return gdscId;
	}
	public void setGdscId(String gdscId) {
		this.gdscId = gdscId;
	}
	public Long getTimeStamp() {
		return timeStamp;
	}
	public void setTimeStamp(Long timeStamp) {
		this.timeStamp = timeStamp;
	}
	public String getSourceProductCode() {
		return sourceProductCode;
	}
	public void setSourceProductCode(String sourceProductCode) {
		this.sourceProductCode = sourceProductCode;
	}
	public String getAdditionalInfo() {
		return additionalInfo;
	}
	public void setAdditionalInfo(String additionalInfo) {
		this.additionalInfo = additionalInfo;
	}
	public Long getGdsProducerId() {
		return gdsProducerId;
	}
	public void setGdsProducerId(Long gdsProducerId) {
		this.gdsProducerId = gdsProducerId;
	}
	public Long getDeliveryId() {
		return deliveryId;
	}
	public void setDeliveryId(Long deliveryId) {
		this.deliveryId = deliveryId;
	}
	public String getConsumerProductCode() {
		return consumerProductCode;
	}
	public void setConsumerProductCode(String consumerProductCode) {
		this.consumerProductCode = consumerProductCode;
	}
	public EventInfo getEventInfo() {
		return eventInfo;
	}
	public void setEventInfo(EventInfo eventInfo) {
		this.eventInfo = eventInfo;
	}
	public String getMessageToDispatch() {
		return messageToDispatch;
	}
	public void setMessageToDispatch(String messageToDispatch) {
		this.messageToDispatch = messageToDispatch;
	}
	public String getMessageType() {
		return messageType;
	}
	public void setMessageType(String messageType) {
		this.messageType = messageType;
	}

}
