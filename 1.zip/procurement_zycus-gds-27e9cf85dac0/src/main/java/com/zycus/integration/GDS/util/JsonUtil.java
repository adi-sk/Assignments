
package com.zycus.integration.GDS.util;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;

import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

/**
 *punit.sukhija
 *
 */
public class JsonUtil {
	
	 public static String serialize(Object object) throws IOException, JsonMappingException {
		    ObjectMapper mapper = new ObjectMapper();

		    ByteArrayOutputStream outputStream = new ByteArrayOutputStream();

		    mapper.writeValue(outputStream, object);

		    return outputStream.toString("UTF-8");
		  }

	 public static String serializeString(Object object){
		 ObjectMapper mapper = new ObjectMapper();
		 
		 ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
		 
		 try {
			mapper.writeValue(outputStream, object);
			return outputStream.toString("UTF-8");
		}catch (Exception e) {
			e.printStackTrace();
		}
		 return null;
	 }

		  public static <T>T deserialize(String json, Class<T> clazz) throws IOException, JsonMappingException {
		    ObjectMapper mapper = new ObjectMapper();

		    ByteArrayInputStream inputStream = new ByteArrayInputStream(json.getBytes("UTF-8"));

		    return mapper.readValue(inputStream, clazz);
		  }

}
