
package com.zycus.integration.GDS.scheduler;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import org.quartz.DisallowConcurrentExecution;
import org.quartz.Job;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import org.quartz.PersistJobDataAfterExecution;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.zycus.integration.GDS.constant.DeliveryTypeConstant;
import com.zycus.integration.GDS.service.GDSCPostBoxMessageService;
import com.zycus.integration.GDS.service.GDSCService;

/**
 * punit.sukhija
 *
 */
@Component
@PersistJobDataAfterExecution
@DisallowConcurrentExecution
public class GDSCScheduler  implements Job {

	@Autowired
	private GDSCService service;

	@Autowired
	private GDSCPostBoxMessageService gdscPostBoxMessageService;

	private static final Logger LOG = LoggerFactory.getLogger(GDSCScheduler.class);

	@Override
	public void execute(JobExecutionContext context) throws JobExecutionException {
		ExecutorService executorService = Executors.newFixedThreadPool(4);
		List<SchedulerJob> schedulerjobs = new ArrayList<>();
		schedulerjobs.add(new SchedulerJob(service,DeliveryTypeConstant.GDS));
		schedulerjobs.add(new SchedulerJob(service,DeliveryTypeConstant.QUEUE));
		schedulerjobs.add(new SchedulerJob(service,DeliveryTypeConstant.TOPIC));
		schedulerjobs.add(new SchedulerJob(service,DeliveryTypeConstant.HTTP));
		try {
			executorService.invokeAll(schedulerjobs);
		} catch (InterruptedException e) {
			LOG.error(" Unable to start Scheduler {}",e);
		}
		executorService.shutdown();
		gdscPostBoxMessageService.callBackToProducerScheduler();
	}

}
