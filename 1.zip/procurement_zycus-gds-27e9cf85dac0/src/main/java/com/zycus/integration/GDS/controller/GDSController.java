
package com.zycus.integration.GDS.controller;

import java.io.PrintWriter;
import java.io.StringWriter;
import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.zycus.integration.GDS.enums.ErrorEnums;
import com.zycus.integration.GDS.enums.GDSCErrorEnum;
import com.zycus.integration.GDS.exception.GDSCException;
import com.zycus.integration.GDS.model.Rule;
import com.zycus.integration.GDS.pojo.Ack;
import com.zycus.integration.GDS.pojo.Acknowledge;
import com.zycus.integration.GDS.pojo.Error;
import com.zycus.integration.GDS.pojo.Errors;
import com.zycus.integration.GDS.pojo.GDSPostBoxMessage;
import com.zycus.integration.GDS.pojo.GDSProducerRequest;
import com.zycus.integration.GDS.repository.RuleRepository;
import com.zycus.integration.GDS.service.GDSCPostBoxMessageService;
import com.zycus.integration.GDS.service.GDSCService;
import com.zycus.integration.GDS.util.GDSProducerRequestValidator;
import com.zycus.integration.GDS.util.JsonUtil;

/**
 * punit.sukhija
 *
 */

@RestController
@RequestMapping(value="gds")
public class GDSController {

	private final Logger LOG = LoggerFactory.getLogger(this.getClass().getName());
	
	@Autowired
	private GDSCService service;

	@Autowired
	private RuleRepository repo;
	
	@Autowired
	private GDSCPostBoxMessageService gdscMessageService;

	@RequestMapping("/postData")
	public ResponseEntity<Acknowledge> postDataPacket(@RequestBody GDSProducerRequest payload) {
		LOG.info(" In /gds/postData api...");
		LOG.info("Request Object : "+JsonUtil.serializeString(payload));
		if (payload == null) {
			return sendErrorAcknowlegde(ErrorEnums.INVALID_DATA_RECEIVED.getValue()+"",
					ErrorEnums.INVALID_DATA_RECEIVED.getValue(), "NullPointerException");
		}
		List<String> errorList = GDSProducerRequestValidator.validateEventInfo(payload);
	 	if(errorList.isEmpty()) {
	 		try {
				Acknowledge ack = service.captureEventData(payload);
				return ResponseEntity.status(HttpStatus.OK).body(ack);

			} catch (GDSCException e) {
				return sendErrorAcknowlegde(e.getErrorCode(), e.getErrorMessage(), getStackTraceInfoInString(e));
			}
	 	}else {
			StringBuilder errorMessage=new StringBuilder();
			for(String error : errorList) {
				errorMessage.append(error + "\n");
			}
			return sendErrorAcknowlegde(GDSCErrorEnum.GDSPRODUCERREQUEST_VALIDATION_FAILED.getValue(),errorMessage.toString(), GDSCErrorEnum.GDSPRODUCERREQUEST_VALIDATION_FAILED.getText());
		}
		

	}

	private String getStackTraceInfoInString(GDSCException e) {

		StringWriter sw = new StringWriter();
		e.printStackTrace(new PrintWriter(sw));
		String stackTrace = sw.toString();
		return stackTrace;
	}

	private ResponseEntity<Acknowledge> sendErrorAcknowlegde(String errorCode, String errorDescription,
			String stacktrace) {

		Acknowledge ack = new Acknowledge();
		ack.setErrorCode(String.valueOf(errorCode));
		ack.setErrorDescription(errorDescription);
		ack.setStackTrace(stacktrace);
		LOG.info(" Error Response : "+JsonUtil.serializeString(ack));
		return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(ack);

	}

	@RequestMapping("/testDB")
	public String chkDbConnection() {

		List<Rule> rules = repo.getRule("INVOICE", "INVOICE", "CREATE");
		System.out.println(rules.get(0));
		return "ok";
	}
	
	@RequestMapping("/callBack")
	public ResponseEntity<Ack> callBackToProduct(@RequestBody GDSPostBoxMessage postBoxMessage) {
		LOG.info(" In /gds/callBack api...");
		LOG.info("Request Object : "+JsonUtil.serializeString(postBoxMessage));
		if (postBoxMessage == null) {
			return sendErrorAck(ErrorEnums.INVALID_DATA_RECEIVED.getValue()+"",
					ErrorEnums.INVALID_DATA_RECEIVED.getValue(), "NullPointerException");
		}
		List<String> errorList = GDSProducerRequestValidator.validatePostBoxMessage(postBoxMessage);
	 	if(errorList.isEmpty()) {
	 		try {
				Ack ack = gdscMessageService.capturePostBoxMessage(postBoxMessage);
				return ResponseEntity.status(HttpStatus.OK).body(ack);

			} catch (GDSCException e) {
				return sendErrorAck(e.getErrorCode(), e.getErrorMessage(), getStackTraceInfoInString(e));
			}
	 	}else {
			StringBuilder errorMessage=new StringBuilder();
			for(String error : errorList) {
				errorMessage.append(error + "\n");
			}
			return sendErrorAck(GDSCErrorEnum.GDSPRODUCERREQUEST_VALIDATION_FAILED.getValue(), GDSCErrorEnum.GDSPRODUCERREQUEST_VALIDATION_FAILED.getText(),errorMessage.toString());
		}
		

	}
	
	private ResponseEntity<Ack> sendErrorAck(String errorCode, String errorDescription,
			String stacktrace) {

		Ack ack = new Ack();
		Errors errors=new Errors();
		List<Error> errorList=new ArrayList<>();
		Error error=new Error();
		error.setErrorCode(String.valueOf(errorCode));
		error.setErrorDescription(errorDescription);
		error.setStackTrace(stacktrace);
		errorList.add(error);
		errors.setError(errorList);
		ack.setErrors(errors);
		LOG.info(JsonUtil.serializeString(ack));
		return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(ack);

	}

}
