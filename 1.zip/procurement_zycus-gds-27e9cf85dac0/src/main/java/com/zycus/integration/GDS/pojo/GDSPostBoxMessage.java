package com.zycus.integration.GDS.pojo;

import javax.validation.constraints.NotNull;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonRootName;

@JsonRootName("gdsPostBoxMessage")
public class GDSPostBoxMessage {
	
	@NotNull(message="Mandatory and Cannot be null or Empty")
	private String gdsSource;
	
	@NotNull(message="Mandatory and Cannot be null or Empty")
	private String gdsDestination;
	
	@NotNull(message="Mandatory and Cannot be null or Empty")
	private String gdsMessageType;
	
	@NotNull(message="Mandatory and Cannot be null or Empty")
	private String sourceId;
	
	@NotNull(message="Mandatory and Cannot be null or Empty")
	private String destinationId;
	
	private String extraInfo;
	
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private PostBoxMessage message;
	
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private Errors errors;
	
	public String getGdsSource() {
		return gdsSource;
	}

	public void setGdsSource(String gdsSource) {
		this.gdsSource = gdsSource;
	}

	public String getGdsDestination() {
		return gdsDestination;
	}

	public void setGdsDestination(String gdsDestination) {
		this.gdsDestination = gdsDestination;
	}

	public String getGdsMessageType() {
		return gdsMessageType;
	}

	public void setGdsMessageType(String gdsMessageType) {
		this.gdsMessageType = gdsMessageType;
	}

	public String getSourceId() {
		return sourceId;
	}

	public void setSourceId(String sourceId) {
		this.sourceId = sourceId;
	}

	public void setExtraInfo(String extraInfo) {
		this.extraInfo = extraInfo;
	}

	public PostBoxMessage getMessage() {
		return message;
	}

	public void setMessage(PostBoxMessage message) {
		this.message = message;
	}

	public String getExtraInfo() {
		return extraInfo;
	}

	public String getDestinationId() {
		return destinationId;
	}

	public void setDestinationId(String destinationId) {
		this.destinationId = destinationId;
	}

	public Errors getErrors() {
		return errors;
	}

	public void setErrors(Errors errors) {
		this.errors = errors;
	}

}
