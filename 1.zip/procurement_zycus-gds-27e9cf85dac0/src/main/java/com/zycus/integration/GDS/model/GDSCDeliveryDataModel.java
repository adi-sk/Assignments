
package com.zycus.integration.GDS.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 *punit.sukhija
 *
 */

@Entity
@Table(name = "GDSC_DELIVERY_DATA")
@SequenceGenerator(name = "GDSC_DELIVERY_DATA_SEQ", sequenceName = "GDSC_DELIVERY_DATA_SEQ", initialValue = 1, allocationSize = 1)
public class GDSCDeliveryDataModel {
	
	private Long deliveryId;
	private Long gdsProducerId;
	private String tenantId;
	private String gdscId;
	private String consumerProductCode;
	private String messageToDispatch;
	private String status;
	private String executionAt;
	private String errorCode;
	private String errorDescription;
	private Date producerTimeStamp;
	private Date deliveryTimeStamp;
	private Date consumerTimeStamp;
	private String sourceProductCode;
	private String messageType;
	private Long gdsConsumerId;
	private String consumerResponse;
	private String consumerErrorCode;
	private String consumerExecutionAt;
	private String consumerStacktrace;
	private Long failedAttempts;
	private String destinationType;
	private String eventType;
	private String entityType;
	private String response;
	private String responseStatus;
	
	@Id
	@Column(name = "DELIVERY_ID")
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "GDSC_DELIVERY_DATA_SEQ")
	public Long getDeliveryId() {
		return deliveryId;
	}
	public void setDeliveryId(Long deliveryId) {
		this.deliveryId = deliveryId;
	}
	
	@Column(name = "GDS_PRODUCER_ID")
	public Long getGdsProducerId() {
		return gdsProducerId;
	}
	public void setGdsProducerId(Long gdsProducerId) {
		this.gdsProducerId = gdsProducerId;
	}
	
	@Column(name = "TENANT_ID")
	public String getTenantId() {
		return tenantId;
	}
	public void setTenantId(String tenantId) {
		this.tenantId = tenantId;
	}
	
	@Column(name = "GDSC_ID")
	public String getGdscId() {
		return gdscId;
	}
	public void setGdscId(String gdscId) {
		this.gdscId = gdscId;
	}
	
	@Column(name = "CONSUMER_PRODUCT_CODE")
	public String getConsumerProductCode() {
		return consumerProductCode;
	}
	public void setConsumerProductCode(String consumerProductCode) {
		this.consumerProductCode = consumerProductCode;
	}
	
	@Column(name = "MESSAGE_TO_DISPATCH")
	public String getMessageToDispatch() {
		return messageToDispatch;
	}
	public void setMessageToDispatch(String messageToDispatch) {
		this.messageToDispatch = messageToDispatch;
	}
	
	@Column(name = "STATUS")
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	
	@Column(name = "EXECUTION_AT")
	public String getExecutionAt() {
		return executionAt;
	}
	public void setExecutionAt(String executionAt) {
		this.executionAt = executionAt;
	}
	
	@Column(name = "ERROR_CODE")
	public String getErrorCode() {
		return errorCode;
	}
	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}
	
	@Lob
	@Column(name = "ERROR_DESCRIPTION")
	public String getErrorDescription() {
		return errorDescription;
	}
	public void setErrorDescription(String errorDescription) {
		this.errorDescription = errorDescription;
	}
	
	@Column(name = "DELIVERY_TIMESTAMP")
	@Temporal(TemporalType.TIMESTAMP)
	public Date getDeliveryTimeStamp() {
		return deliveryTimeStamp;
	}
	public void setDeliveryTimeStamp(Date deliveryTimeStamp) {
		this.deliveryTimeStamp = deliveryTimeStamp;
	}
	
	@Column(name = "SOURCE_PRODUCT_CODE")
	public String getSourceProductCode() {
		return sourceProductCode;
	}
	public void setSourceProductCode(String sourceProductCode) {
		this.sourceProductCode = sourceProductCode;
	}
	
	@Column(name = "MESSAGE_TYPE")
	public String getMessageType() {
		return messageType;
	}
	public void setMessageType(String messageType) {
		this.messageType = messageType;
	}
	
	@Column(name = "GDS_CONSUMER_ID")
	public Long getGdsConsumerId() {
		return gdsConsumerId;
	}
	public void setGdsConsumerId(Long gdsConsumerId) {
		this.gdsConsumerId = gdsConsumerId;
	}
	
	@Column(name = "CONSUMER_RESPONSE")
	public String getConsumerResponse() {
		return consumerResponse;
	}
	public void setConsumerResponse(String consumerResponse) {
		this.consumerResponse = consumerResponse;
	}
	
	@Column(name = "CONSUMER_ERROR_CODE")
	public String getConsumerErrorCode() {
		return consumerErrorCode;
	}
	public void setConsumerErrorCode(String consumerErrorCode) {
		this.consumerErrorCode = consumerErrorCode;
	}
	
	@Column(name = "CONSUMER_EXECUTION_AT")
	public String getConsumerExecutionAt() {
		return consumerExecutionAt;
	}
	public void setConsumerExecutionAt(String consumerExecutionAt) {
		this.consumerExecutionAt = consumerExecutionAt;
	}
	
	@Lob
	@Column(name = "CONSUMER_STACKTRACE")
	public String getConsumerStacktrace() {
		return consumerStacktrace;
	}
	public void setConsumerStacktrace(String consumerStacktrace) {
		this.consumerStacktrace = consumerStacktrace;
	}
	
	@Column(name = "PRODUCER_TIMESTAMP")
	public Date getProducerTimeStamp() {
		return producerTimeStamp;
	}
	public void setProducerTimeStamp(Date producerTimeStamp) {
		this.producerTimeStamp = producerTimeStamp;
	}
	
	@Column(name = "CONSUMER_TIMESTAMP")
	public Date getConsumerTimeStamp() {
		return consumerTimeStamp;
	}
	public void setConsumerTimeStamp(Date consumerTimeStamp) {
		this.consumerTimeStamp = consumerTimeStamp;
	}
	
	@Column(name = "FAILED_ATTEMPTS")
	public Long getFailedAttempts() {
		return failedAttempts;
	}
	public void setFailedAttempts(Long failedAttempts) {
		this.failedAttempts = failedAttempts;
	}
	
	@Column(name = "DESTINATION_TYPE")
	public String getDestinationType() {
		return destinationType;
	}
	public void setDestinationType(String destinationType) {
		this.destinationType = destinationType;
	}
	
	@Column(name = "ENTITY_TYPE")
	public String getEntityType() {
		return entityType;
	}
	public void setEntityType(String entityType) {
		this.entityType = entityType;
	}
	
	@Column(name = "EVENT_TYPE")
	public String getEventType() {
		return eventType;
	}
	public void setEventType(String eventType) {
		this.eventType = eventType;
	}
	
	@Lob
	@Column(name = "RESPONSE")
	public String getResponse() {
		return response;
	}
	public void setResponse(String response) {
		this.response = response;
	}
	
	@Column(name = "RESPONSE_STATUS")
	public String getResponseStatus() {
		return responseStatus;
	}
	public void setResponseStatus(String responseStatus) {
		this.responseStatus = responseStatus;
	}
}