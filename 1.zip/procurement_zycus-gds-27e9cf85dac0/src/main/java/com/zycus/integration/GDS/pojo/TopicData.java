package com.zycus.integration.GDS.pojo;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonRootName;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

@JsonRootName("topicData")
@JsonInclude(Include.NON_EMPTY)
public class TopicData {

	@JsonProperty("key")
	private String key;

	@JsonProperty("url")
	private String url;

	@JsonProperty("name")
	private String name;

	public String getKey() {
		return key;
	}

	public void setKey(String key) {
		this.key = key;
	}

	public String getUrl() {
		return url;
	}

	public void setUrl(String url) {
		this.url = url;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	@Override
	public String toString() {
		return "TopicData [key=" + key + ", url=" + url + ", name=" + name + "]";
	}

}
