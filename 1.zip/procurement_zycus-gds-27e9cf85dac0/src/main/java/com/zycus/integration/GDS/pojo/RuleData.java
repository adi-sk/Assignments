package com.zycus.integration.GDS.pojo;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonRootName;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

@JsonRootName("ruleData")
@JsonInclude(Include.NON_EMPTY)
public class RuleData {

	@JsonProperty("targetProductCode")
	private String targetProductCode;

	@JsonProperty("messageType")
	private String messageType;

	@JsonProperty("isTMS")
	private boolean isTms;

	@JsonProperty("isConsulKey")
	private boolean isConsulKey;

	@JsonProperty("keyName")
	private String keyName;

	@JsonProperty("useServiceDiscovery")
	private boolean useServiceDiscovery;

	@JsonProperty("url")
	private String url;

	@JsonProperty("serviceName")
	private String serviceName;

	@JsonProperty("name")
	private String name;

	@JsonProperty("callBack")
	private String callBack;

	@JsonProperty("useServiceDiscoveryForProducerCallback")
	private boolean useServiceDiscoveryForProducerCallback;

	public boolean isConsulKey() {
		return isConsulKey;
	}

	public void setConsulKey(boolean isConsulKey) {
		this.isConsulKey = isConsulKey;
	}

	public String getKeyName() {
		return keyName;
	}

	public void setKeyName(String keyName) {
		this.keyName = keyName;
	}

	public String getUrl() {
		return url;
	}

	public void setUrl(String url) {
		this.url = url;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public boolean isTms() {
		return isTms;
	}

	public void setTms(boolean isTms) {
		this.isTms = isTms;
	}

	public String getMessageType() {
		return messageType;
	}

	public void setMessageType(String messageType) {
		this.messageType = messageType;
	}

	public String getTargetProductCode() {
		return targetProductCode;
	}

	public void setTargetProductCode(String targetProductCode) {
		this.targetProductCode = targetProductCode;
	}

	public String getCallBack() {
		return callBack;
	}

	public void setCallBack(String callBack) {
		this.callBack = callBack;
	}

	public boolean isUseServiceDiscovery() {
		return useServiceDiscovery;
	}

	public void setUseServiceDiscovery(boolean useServiceDiscovery) {
		this.useServiceDiscovery = useServiceDiscovery;
	}

	public String getServiceName() {
		return serviceName;
	}

	public void setServiceName(String serviceName) {
		this.serviceName = serviceName;
	}

	public boolean isUseServiceDiscoveryForProducerCallback() {
		return useServiceDiscoveryForProducerCallback;
	}

	public void setUseServiceDiscoveryForProducerCallback(boolean useServiceDiscoveryForProducerCallback) {
		this.useServiceDiscoveryForProducerCallback = useServiceDiscoveryForProducerCallback;
	}

	@Override
	public String toString() {
		return "RuleData [targetProductCode=" + targetProductCode + ", messageType=" + messageType + ", isTms=" + isTms
				+ ", isConsulKey=" + isConsulKey + ", keyName=" + keyName + ", useServiceDiscovery="
				+ useServiceDiscovery + ", url=" + url + ", serviceName=" + serviceName + ", name=" + name
				+ ", callBack=" + callBack + ", useServiceDiscoveryForProducerCallback="
				+ useServiceDiscoveryForProducerCallback + "]";
	}

}
