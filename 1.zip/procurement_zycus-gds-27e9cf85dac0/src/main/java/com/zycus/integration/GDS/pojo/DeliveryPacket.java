
package com.zycus.integration.GDS.pojo;
/**
 *punit.sukhija
 *
 */
public class DeliveryPacket {
	
	Long id;
	String gdsid;
	String tenantId;
	String productCode;
	String consumerCode;
	String message;
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getGdsid() {
		return gdsid;
	}
	public void setGdsid(String gdsid) {
		this.gdsid = gdsid;
	}
	public String getTenantId() {
		return tenantId;
	}
	public void setTenantId(String tenantId) {
		this.tenantId = tenantId;
	}
	public String getProductCode() {
		return productCode;
	}
	public void setProductCode(String productCode) {
		this.productCode = productCode;
	}
	public String getConsumerCode() {
		return consumerCode;
	}
	public void setConsumerCode(String consumerCode) {
		this.consumerCode = consumerCode;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}

}
