
package com.zycus.integration.GDS.service;

import com.zycus.integration.GDS.exception.GDSCException;
import com.zycus.integration.GDS.pojo.Acknowledge;
import com.zycus.integration.GDS.pojo.GDSProducerRequest;

/**
 *punit.sukhija
 *
 */
public interface GDSCService {
	
	public Acknowledge captureEventData(GDSProducerRequest gdsProducerRequest) throws GDSCException;
	
	public void processCGDSPendingDeliveryData();
	
	public void processQueuePendingDeliveryData();
	
	public void processTopicPendingDeliveryData();
	
	public void processHttpPendingDeliveryData();

}
