
package com.zycus.integration.GDS.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.zycus.integration.GDS.model.GDSCDeliveryDataModel;

/**
 *punit.sukhija
 *
 */
@Repository
public abstract interface GDSCDeliveryDataRepository extends JpaRepository<GDSCDeliveryDataModel , Long> {
	
	@Query("select d from GDSCDeliveryDataModel d where d.destinationType= :destinationType and (d.status= :status1 OR d.status= :status2) order by d.deliveryId ASC")
	public List<GDSCDeliveryDataModel> getGDSCDeliveryDataModel(@Param("destinationType")String destinationType, @Param("status1")String status1 , @Param("status2")String status2);
	
	@Query("select d from GDSCDeliveryDataModel d where d.gdscId= :gdscId")
	public List<GDSCDeliveryDataModel> getGDSCDeliveryDataModelWithGdscId(@Param("gdscId")String gdscId);

}
