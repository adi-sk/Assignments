
package com.zycus.integration.GDS.enums;
/**
 *punit.sukhija
 *
 */
public enum ErrorEnums {

	INVALID_DATA_RECEIVED {
		@Override
		public String getValue() {
			return "RE-CGDS-S-3001";
		}
		@Override
		public String getText() {
			return "Invalid Data Received";
		}
	},
	INTERNAL_SERVER_ERROR {
		@Override
		public String getValue() {
			return "RE-CGDS-S-3002";
		}
		@Override
		public String getText() {
			return "Internal Server Error";
		}
	},
	NO_DATA_RECEIVED {
		@Override
		public String getValue() {
			return "RE-CGDS-S-3003";
		}
		@Override
		public String getText() {
			return "No Data Received";
		}
	},
	END_POINT_NOT_CONFIGURED {
		@Override
		public String getValue() {
			return "RE-CGDS-S-3004";
		}
		@Override
		public String getText() {
			return "End point not configured Correctly";
		}
	},
	RULE_NOT_FOUND {
		@Override
		public String getValue() {
			return "RE-CGDS-S-3005";
		}
		@Override
		public String getText() {
			return "Rule not configured";
		}
	},
	CALL_BACK_URL_NOT_CONFIGURED {
		@Override
		public String getValue() {
			return "RE-CGDS-S-3006";
		}
		@Override
		public String getText() {
			return "Call Back URL Not Configured";
		}
	};
	public abstract String getText();
	public abstract String getValue();

	

	/*INVALID_DATA_RECEIVED("RE-CGDS-S-3001"),
	INTERNAL_SERVER_ERROR("RE-CGDS-S-3002"),
	NO_DATA_RECEIVED("RE-CGDS-S-3003"),
	END_POINT_NOT_CONFIGURED("RE-CGDS-S-3004"),
	RULE_NOT_FOUND("RE-CGDS-S-3005");
	
	private String value;
	private String 
	private ErrorCode(String value)
	{
		this.value = value;
	}

	public String getValue() {
		return this.value;
	}*/
}
