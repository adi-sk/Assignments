package com.zycus.integration.GDS.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.zycus.integration.GDS.model.GDSPostBoxMessageModel;

@Repository
public abstract interface GDSCPostBoxMessageRepository extends JpaRepository<GDSPostBoxMessageModel, Long> {
	
	public static final String QUERY = "select d from GDSPostBoxMessageModel d where (d.executionAt='CALL_BACK_FROM_CONSUMER' and d.status='SUCCESS') OR (d.executionAt='CALL_BACK_TO_PRODUCER' and d.status='PROCESSING') OR (d.executionAt='CALL_BACK_TO_PRODUCER' and d.status='FAILED') order by d.postBoxId ASC" ;
	
	
	@Query(value = QUERY)
	public List<GDSPostBoxMessageModel> getGDSCGDSPostBoxMessageModel();

	@Query("select d from GDSPostBoxMessageModel d where d.consumerId= :consumerId and d.producerId=:producerId and d.gdscId=:gdscId")
	public GDSPostBoxMessageModel getDuplicateData(@Param("consumerId") String consumerId, @Param("producerId") String producerId,@Param("gdscId")  String gdscId);
}
