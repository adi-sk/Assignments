package com.zycus.integration.GDS.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name = "GDS_POST_BOX")
@SequenceGenerator(name = "GDS_POST_BOX_SEQ", sequenceName = "GDS_POST_BOX_SEQ", initialValue = 1, allocationSize = 1)
public class GDSPostBoxMessageModel {
	
		@Id
		@Column(name = "ID")
		@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "GDS_POST_BOX_SEQ")
		private long postBoxId;
		
		@Column(name = "GDS_SOURCE")
		private String gdsSource;
		
		@Column(name = "GDS_DESTINATION")
		private String gdsDestination;
		
		@Column(name = "GDS_MESSAGE_TYPE")
		private String gdsMessageType;
		
		@Column(name = "SOURCE_ID")
		private String sourceId;
		
		@Column(name = "DESTINATION_ID")
		private String destinationId;
		
		@Lob
		@Column(name = "EXTRA_INFO")
		private String extraInfo;
		
		@Column(name = "EVENT_ID")
		private String eventId;
		
		@Column(name = "ENTITY_ID")
		private String entityId;
		
		@Column(name = "EVENT_TYPE")
		private String eventType;
		
		@Column(name = "ENTITY_TYPE")
		private String entityType;
		
		@Column(name = "MESSAGE_TYPE")
		private String messageType;
		
		@Lob
		@Column(name = "PRODUCT_RESPONSE")
		private String productResponse;
		
		@Lob
		@Column(name = "MSG_EXTRA_INFO")
		private String msgExtraInfo;
		
		@Column(name = "CONSUMER_ID")
		private String consumerId;
		
		@Column(name = "PRODUCER_ID")
		private String producerId;

		@Column(name = "EXECUTION_AT")
		private String executionAt;
		
		@Column(name = "STATUS")
		private String status;

		@Column(name = "ERROR_CODE")
		private String errorCode;

		@Column(name = "ERROR_DESCRIPTION")
		private String errorDescription;

		@Lob
		@Column(name = "STACKTRACE")
		private String stacktrace;
		
		@Column(name = "GDSCID")
		private String gdscId; 

		@Column(name = "TENANT_ID")
		private String tenantId;
		
		@Lob
		@Column(name = "PRODUCER_RESPONSE")
		private String producerResponse;
		
		public long getPostBoxId() {
			return postBoxId;
		}

		public void setPostBoxId(long postBoxId) {
			this.postBoxId = postBoxId;
		}

		public String getGdsSource() {
			return gdsSource;
		}

		public void setGdsSource(String gdsSource) {
			this.gdsSource = gdsSource;
		}

		public String getGdsDestination() {
			return gdsDestination;
		}

		public void setGdsDestination(String gdsDestination) {
			this.gdsDestination = gdsDestination;
		}

		public String getGdsMessageType() {
			return gdsMessageType;
		}

		public void setGdsMessageType(String gdsMessageType) {
			this.gdsMessageType = gdsMessageType;
		}

		public String getSourceId() {
			return sourceId;
		}

		public void setSourceId(String sourceId) {
			this.sourceId = sourceId;
		}

		public String getEventId() {
			return eventId;
		}

		public void setEventId(String eventId) {
			this.eventId = eventId;
		}

		public String getEntityId() {
			return entityId;
		}

		public void setEntityId(String entityId) {
			this.entityId = entityId;
		}

		public String getEventType() {
			return eventType;
		}

		public void setEventType(String eventType) {
			this.eventType = eventType;
		}

		public String getEntityType() {
			return entityType;
		}

		public void setEntityType(String entityType) {
			this.entityType = entityType;
		}

		public String getMessageType() {
			return messageType;
		}

		public void setMessageType(String messageType) {
			this.messageType = messageType;
		}

		public String getProductResponse() {
			return productResponse;
		}

		public void setProductResponse(String productResponse) {
			this.productResponse = productResponse;
		}
		
		public String getExecutionAt() {
			return executionAt;
		}

		public void setExecutionAt(String executionAt) {
			this.executionAt = executionAt;
		}

		public String getStatus() {
			return status;
		}

		public void setStatus(String status) {
			this.status = status;
		}

		public String getErrorCode() {
			return errorCode;
		}

		public void setErrorCode(String errorCode) {
			this.errorCode = errorCode;
		}

		public String getErrorDescription() {
			return errorDescription;
		}

		public void setErrorDescription(String errorDescription) {
			this.errorDescription = errorDescription;
		}

		public String getStacktrace() {
			return stacktrace;
		}

		public void setStacktrace(String stacktrace) {
			this.stacktrace = stacktrace;
		}

		public String getExtraInfo() {
			return extraInfo;
		}

		public void setExtraInfo(String extraInfo) {
			this.extraInfo = extraInfo;
		}

		public String getMsgExtraInfo() {
			return msgExtraInfo;
		}

		public void setMsgExtraInfo(String msgExtraInfo) {
			this.msgExtraInfo = msgExtraInfo;
		}

		public String getConsumerId() {
			return consumerId;
		}

		public void setConsumerId(String consumerId) {
			this.consumerId = consumerId;
		}

		public String getProducerId() {
			return producerId;
		}

		public void setProducerId(String producerId) {
			this.producerId = producerId;
		}

		public String getDestinationId() {
			return destinationId;
		}

		public void setDestinationId(String destinationId) {
			this.destinationId = destinationId;
		}

		public String getGdscId() {
			return gdscId;
		}

		public void setGdscId(String gdscId) {
			this.gdscId = gdscId;
		}

		public String getTenantId() {
			return tenantId;
		}

		public void setTenantId(String tenantId) {
			this.tenantId = tenantId;
		}

		public String getProducerResponse() {
			return producerResponse;
		}

		public void setProducerResponse(String producerResponse) {
			this.producerResponse = producerResponse;
		}
}
