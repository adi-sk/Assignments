package com.zycus.integration.GDS.enums;

/**
 * Represents possible error constant's while Processing Host Request/Event.
 * @author Narendra M
 * @version 1.0
 */
public enum GDSCErrorEnum {
	
	
	BAD_JSON{
		@Override
		public String getValue() {
			return "RE-CGDS-S-2001";
		}
		@Override
		public String getText() {
			return "Bad Json Structure";
		}
	},
	/**
	 * Sent Data Successfully to CGDS But failed to change status of event.
	 */
	UNABLE_TO_SEND_VIA_ACTIVE_MQ {
		@Override
		public String getValue() {
			return "RE-CGDS-S-2002";
		}
		@Override
		public String getText() {
			return "Unable to Send Event via Active MQ ,Due to Active MQ is Down";
		}
	},
	
	RULE_CONFIGURATION_GDS_ENDPOINT_ERROR {
		@Override
		public String getValue() {
			return "RE-CGDS-S-2003";
		}
		@Override
		public String getText() {
			return "GDS endPoint Rule Configuration has been modified or GDS EndPoint Json error ";
		}
	},
	QUEUE_RULE_CONFIGURATION_ERROR {
		@Override
		public String getValue() {
			return "RE-CGDS-S-2004";
		}
		@Override
		public String getText() {
			return "Queue Rule Configuration not configured properly ";
		}
	},
	CONSUL_KEY_NOT_FOUND_GDS {
		@Override
		public String getValue() {
			return "RE-CGDS-S-2005";
		}
		@Override
		public String getText() {
			return "Unable to get consul key from Consul for GDS endpoint,Due to network problem/consul key not present in consul ";
		}
	},
	RULE_NOT_CONFIGURED {
		@Override
		public String getValue() {
			return "RE-CGDS-S-2006";
		}
		@Override
		public String getText() {
			return "Rule Not Configured for the Event";
		}
	},
	GDSPRODUCERREQUEST_VALIDATION_FAILED {
		@Override
		public String getValue() {
			return "RE-CGDS-S-2007";
		}
		@Override
		public String getText() {
			return "Request validation failed";
		}
	},
	UNABLE_TO_SAVE_REQUEST {
		@Override
		public String getValue() {
			return "RE-CGDS-S-2008";
		}
		@Override
		public String getText() {
			return "Unable to save data to DataBase";
		}
	},
	REST_OTHER_EXCEPTION {
		@Override
		public String getValue() {
			return "RE-GDSC-S-2009";
		}
		@Override
		public String getText() {
			return "Unable send data to Producer!!!";
		}
	},
	INTERNAL_SERVER_ERROR {
		@Override
		public String getValue() {
			return "RE-GDSC-S-2010";
		}
		@Override
		public String getText() {
			return "Exception occured internally at CGDS";
		}
	},
	ACK_FROM_CGDS_NULL{
		@Override
		public String getValue() {
			return "RE-GDSC-S-2011";
		}
		@Override
		public String getText() {
			return "Response from Producer cannot be Null";
		}
	},
	REST_CONNECTION_TIMEOUT {
		@Override
		public String getValue() {
			return "RE-GDSC-S-2012";
		}
		@Override
		public String getText() {
			return "Connection Time Out. Unable to reach Producer!!!";
		}
	},
	CALL_BACK_URL_NOT_FOUND {
		@Override
		public String getValue() {
			return "RE-GDSC-S-2013";
		}
		@Override
		public String getText() {
			return "Call back url not set in Rule Configuration";
		}
	},
	SERVICE_NAME_CANNOT_BE_NULL {
		@Override
		public String getValue() {
			return "RE-CGDS-S-3007";
		}
		@Override
		public String getText() {
			return "ServiceName for service discovery cannot be null or empty";
		}
	}	;	
	
	public abstract String getText();
	public abstract String getValue();
	
}
