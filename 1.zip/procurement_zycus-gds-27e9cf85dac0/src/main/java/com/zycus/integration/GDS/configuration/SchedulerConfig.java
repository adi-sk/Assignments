package com.zycus.integration.GDS.configuration;

import java.util.Properties;
import java.util.TimeZone;

import org.quartz.CronScheduleBuilder;
import org.quartz.CronTrigger;
import org.quartz.JobBuilder;
import org.quartz.JobDetail;
import org.quartz.Trigger;
import org.quartz.TriggerBuilder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.quartz.SchedulerFactoryBean;

import com.zycus.integration.GDS.constant.SchedularConstant;
import com.zycus.integration.GDS.scheduler.GDSCScheduler;

/**
 * 
 * @author narendra.m
 *
 */
@Configuration
public class SchedulerConfig {

	private JobDetail jobDetails = null;
	private Trigger triggers = null;

	@Value(value = "${cronExpression}")
	private String cronExpression;

	@Value(value = "${schedulerStartupDelay}")
	private String schedulerStartupDelay;

	@Value(value = "${spring.datasource.driverClassName}")
	private String driverClassName;

	@Value(value = "${spring.datasource.url}")
	private String dbUrl;
	
	@Value(value = "${spring.datasource.username}")
	private String dbUsername;
	
	@Value(value = "${spring.datasource.password}")
	private String dbPassword;

	@Autowired
	private ApplicationContext applicationContext;

	@Bean
	public SchedulerFactoryBean consumerQuartzScheduler() {
		SchedulerFactoryBean quartzScheduler = new SchedulerFactoryBean();
		Properties quartzProperties = new Properties();
		quartzProperties.setProperty("org.quartz.scheduler.instanceName", SchedularConstant.INSTANCENAME);
		quartzProperties.setProperty("org.quartz.scheduler.instanceId", SchedularConstant.INSTANCEID);
		quartzProperties.setProperty("org.quartz.threadPool.threadCount", SchedularConstant.THREADCOUNT);
		quartzProperties.setProperty("org.quartz.jobStore.class", SchedularConstant.QUARTZClASS);
		quartzProperties.setProperty("org.quartz.jobStore.driverDelegateClass", SchedularConstant.DRIVERDELEGATECLASS);
		quartzProperties.setProperty("org.quartz.jobStore.tablePrefix",SchedularConstant.TABLEPREFIX);
		quartzProperties.setProperty("org.quartz.jobStore.isClustered", SchedularConstant.ISCLUSTERED);
		quartzProperties.setProperty("org.quartz.jobStore.dataSource", SchedularConstant.DATASOURCE);
		quartzProperties.setProperty("org.quartz.jobStore.misfireThreshold", SchedularConstant.MISFIRETHRESHOLD);
		quartzProperties.setProperty("org.quartz.dataSource.myDS.driver", driverClassName);
		quartzProperties.setProperty("org.quartz.dataSource.myDS.URL", dbUrl);
		quartzProperties.setProperty("org.quartz.dataSource.myDS.user", dbUsername);
		quartzProperties.setProperty("org.quartz.dataSource.myDS.password", dbPassword);
		quartzProperties.setProperty("org.quartz.dataSource.myDS.maxConnections", SchedularConstant.MAXCONNECTIONS);
		quartzProperties.setProperty("org.quartz.dataSource.myDS.validationQuery", SchedularConstant.VALIDATIONQUERY);
		quartzProperties.setProperty("org.quartz.jobStore.selectWithLockSQL", SchedularConstant.SELECTWITHLOCKSQL);
		quartzScheduler.setQuartzProperties(quartzProperties);

		AutowiringSpringBeanJobFactory jobFactory = new AutowiringSpringBeanJobFactory();
		jobFactory.setApplicationContext(applicationContext);
		quartzScheduler.setJobFactory(jobFactory);
		quartzScheduler.setStartupDelay(Integer.parseInt(schedulerStartupDelay));
		quartzScheduler.setJobDetails(jobDetails());
		quartzScheduler.setTriggers(quartzTriggers());
		quartzScheduler.setOverwriteExistingJobs(true);
		quartzScheduler.setAutoStartup(true);
		quartzScheduler.setSchedulerName(SchedularConstant.SCHEDULER_NAME);
		return quartzScheduler;
	}

	public JobDetail jobDetails() {
		jobDetails = JobBuilder.newJob(GDSCScheduler.class).storeDurably()
				.withIdentity(SchedularConstant.SCHEDULER_JOB_NAME, SchedularConstant.SCHEDULER_GROUP).build();
		return jobDetails;
	}

	public Trigger quartzTriggers() {
		CronTrigger producerJobTriger = TriggerBuilder.newTrigger().forJob(jobDetails)
				.withIdentity(SchedularConstant.SCHEDULER_TRIGGER_NAME, SchedularConstant.SCHEDULER_GROUP)
				.withSchedule(CronScheduleBuilder.cronSchedule(cronExpression)
						.withMisfireHandlingInstructionDoNothing().inTimeZone(TimeZone.getTimeZone("UTC")))
				.build();
		triggers = producerJobTriger;
		return triggers;
	}

}
