
package com.zycus.integration.GDS.util;

import java.util.Date;
import java.util.UUID;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.zycus.integration.GDS.enums.ErrorEnums;
import com.zycus.integration.GDS.enums.GDSCErrorEnum;
import com.zycus.integration.GDS.exception.GDSCException;
import com.zycus.integration.consul_service_discovery_client.ConsulServiceDiscoveryAgent;
import com.zycus.integration.consul_service_discovery_client.exception.ServiceNameNotFoundException;
import com.zycus.management.authorization.exception.AuthorizationException;
import com.zycus.management.sso.exception.InvalidSessionException;
import com.zycus.management.sso.exception.InvalidSourceIPException;
import com.zycus.management.tenant.AllocatedProduct;
import com.zycus.management.tenant.AuthenticatedUser;
import com.zycus.management.tenant.Company;
import com.zycus.management.tenant.TenantManagementSystem;
import com.zycus.management.tenant.exception.AuthenticationException;
import com.zycus.management.tenant.exception.OperationFailedException;
import com.zycus.management.tenant.exception.ValidationException;

/**
 * punit.sukhija
 *
 */
public class GDSCUtil {

	private static final Logger LOG = LoggerFactory.getLogger(GDSCUtil.class);

	public static String getEndpointConsul(String tenantid, String serviceName,String aclToken,String serviceUrl) throws GDSCException {

		if(checkIfNullNEmpty(serviceName)) {
			throw new GDSCException(GDSCErrorEnum.SERVICE_NAME_CANNOT_BE_NULL.getValue(), GDSCErrorEnum.SERVICE_NAME_CANNOT_BE_NULL.getText(), new Exception());
		}
		LOG.info("Fetching base url from service Discovery...");
		LOG.info("Parameters :\nTenant Id :" + tenantid + "\nProduct :" + serviceName);
		LOG.info("Parameters :\n aclToken :" + aclToken + "\n serviceUrl :" + serviceUrl);
		String productURL;
		try {
			productURL = ConsulServiceDiscoveryAgent.getServiceUrl(serviceUrl, serviceName, tenantid, aclToken);
			return productURL;
		} catch (ServiceNameNotFoundException e) {
			LOG.error(e.getMessage(), e);
			throw new GDSCException(String.valueOf(ErrorEnums.INTERNAL_SERVER_ERROR.getValue()), e.getMessage(), e);
		}catch (Exception e) {
			LOG.error(e.getMessage(), e);
			throw new GDSCException(String.valueOf(ErrorEnums.INTERNAL_SERVER_ERROR.getValue()), e.getMessage(), e);
		}
	}

	public static String getEndpointTMS(String tenantid, String product,String tmsUserName,String tmsPassword) throws GDSCException {

		LOG.info("Fetching base url from TMS ...");
		LOG.info("Parameters :\nTenant Id :" + tenantid + "\nProduct :" + product);
		try {
			AuthenticatedUser loggedUser = TenantManagementSystem.authenticate(tmsUserName, tmsPassword);
			TenantManagementSystem tms1 = TenantManagementSystem.getInstance(loggedUser);
			Company company = tms1.getCompanyById(tenantid);
			AllocatedProduct ap = company.getProductByName(product);
			String productURL = ap.getProductUrl();
			return productURL;
		} catch (InvalidSourceIPException e) {
			LOG.error(e.getMessage(), e);
			throw new GDSCException(String.valueOf(ErrorEnums.INTERNAL_SERVER_ERROR.getValue()), e.getMessage(), e);
		} catch (InvalidSessionException e) {
			LOG.error(e.getMessage(), e);
			throw new GDSCException(String.valueOf(ErrorEnums.INTERNAL_SERVER_ERROR.getValue()), e.getMessage(), e);
		} catch (OperationFailedException e) {
			LOG.error(e.getMessage(), e);
			throw new GDSCException(String.valueOf(ErrorEnums.INTERNAL_SERVER_ERROR.getValue()), e.getMessage(), e);
		} catch (ValidationException e) {
			LOG.error(e.getMessage(), e);
			throw new GDSCException(String.valueOf(ErrorEnums.INTERNAL_SERVER_ERROR.getValue()), e.getMessage(), e);
		} catch (AuthorizationException e) {
			LOG.error(e.getMessage(), e);
			throw new GDSCException(String.valueOf(ErrorEnums.INTERNAL_SERVER_ERROR.getValue()), e.getMessage(), e);
		} catch (AuthenticationException e) {
			LOG.error(e.getMessage(), e);
			throw new GDSCException(String.valueOf(ErrorEnums.INTERNAL_SERVER_ERROR.getValue()), e.getMessage(), e);
		} catch (Exception e) {
			LOG.error(e.getMessage(), e);
			throw new GDSCException(String.valueOf(ErrorEnums.INTERNAL_SERVER_ERROR.getValue()), e.getMessage(), e);
		}
	}
	public static String generateRandomNumber() {
		return UUID.randomUUID() + "#" + (new Date()).getTime();
	}

	private static boolean checkIfNullNEmpty(String str) {
		return (str == null || str.isEmpty()) ? true : false;
	}
}
