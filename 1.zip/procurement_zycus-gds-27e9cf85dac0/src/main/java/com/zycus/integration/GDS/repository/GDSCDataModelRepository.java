
package com.zycus.integration.GDS.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.zycus.integration.GDS.model.GDSCDataModel;

/**
 *punit.sukhija
 *
 */
@Repository
public abstract interface GDSCDataModelRepository extends JpaRepository<GDSCDataModel, Long> {
	
	
	@Query("select d from GDSCDataModel d where d.gdsProducerId= :gdsProducerId and d.sourceProductCode= :sourceProductCode")
	public List<GDSCDataModel> getGDSCDataModel(@Param("gdsProducerId") Long gdsProducerId,@Param("sourceProductCode") String sourceProductCode);
	
	@Query("select d from GDSCDataModel d where d.status= :status")
	public List<GDSCDataModel> getGDSCDataModelWithStatus(@Param("status") String status);
	
	
	@Query("select d from GDSCDataModel d where d.gdscId= :gdscId")
	public GDSCDataModel getGDSCDataModelWithGDSCId(@Param("gdscId") String gdscId);

}
