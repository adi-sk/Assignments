package com.zycus.integration.GDS.pojo;

import java.util.List;

public class QueueDetails {
	
	private List<QueueData> queueData;

	public List<QueueData> getQueueData() {
		return queueData;
	}

	public void setQueueData(List<QueueData> queueData) {
		this.queueData = queueData;
	}
	

}
