package com.zycus.integration.GDS.pojo;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

public class EventInfo
{

	@NotNull(message = "Mandatory and Cannot be null or Empty")
	private Long id;

	@Size(min = 1, max = 256)
	@NotNull(message = "Mandatory and Cannot be null or Empty")
	private String eventId;

	@Size(min = 1, max = 256)
	@NotNull(message = "Mandatory and Cannot be null or Empty")
	private String entityId;

	@Size(min = 1, max = 256)
	@NotNull(message = "Mandatory and Cannot be null or Empty")
	private String entityType;

	@Size(min = 1, max = 256)
	@NotNull(message = "Mandatory and Cannot be null or Empty")
	private String eventType;

	@Size(min = 1, max = 10)
	@NotNull(message = "Mandatory and Cannot be null or Empty")
	private String version;

	private String extraInfo;

	@Size(min = 1, max = 256)
	@NotNull(message = "Mandatory and Cannot be null or Empty")
	private String tenantId;

	@Size(min = 1, max = 256)
	@NotNull(message = "Mandatory and Cannot be null or Empty")
	private String businessRefId;

	@NotNull(message = "Mandatory and Cannot be null or Empty")
	private Long timeStamp;

	private String metadataVersion;

	public Long getId()
	{
		return id;
	}

	public void setId(Long id)
	{
		this.id = id;
	}

	public String getEventId()
	{
		return eventId;
	}

	public void setEventId(String eventId)
	{
		this.eventId = eventId;
	}

	public String getEntityId()
	{
		return entityId;
	}

	public void setEntityId(String entityId)
	{
		this.entityId = entityId;
	}

	public String getEntityType()
	{
		return entityType;
	}

	public void setEntityType(String entityType)
	{
		this.entityType = entityType;
	}

	public String getEventType()
	{
		return eventType;
	}

	public void setEventType(String eventType)
	{
		this.eventType = eventType;
	}

	public String getVersion()
	{
		return version;
	}

	public void setVersion(String version)
	{
		this.version = version;
	}

	public String getExtraInfo()
	{
		return extraInfo;
	}

	public void setExtraInfo(String extraInfo)
	{
		this.extraInfo = extraInfo;
	}

	public String getTenantId()
	{
		return tenantId;
	}

	public void setTenantId(String tenantId)
	{
		this.tenantId = tenantId;
	}

	public String getBusinessRefId()
	{
		return businessRefId;
	}

	public void setBusinessRefId(String businessRefId)
	{
		this.businessRefId = businessRefId;
	}

	public Long getTimeStamp()
	{
		return timeStamp;
	}

	public void setTimeStamp(Long timeStamp)
	{
		this.timeStamp = timeStamp;
	}

	public String getMetadataVersion()
	{
		return metadataVersion;
	}

	public void setMetadataVersion(String metadataVersion)
	{
		this.metadataVersion = metadataVersion;
	}
}
