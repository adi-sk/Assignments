package com.zycus.integration.GDS.exception;



import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.context.request.ServletWebRequest;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

import com.zycus.integration.GDS.enums.GDSCErrorEnum;
import com.zycus.integration.GDS.pojo.Acknowledge;


@ControllerAdvice
public class RestExcetionHandler extends ResponseEntityExceptionHandler {

	Logger logger = LoggerFactory.getLogger(RestExcetionHandler.class);

	/**
	 * Handle HttpMessageNotReadableException. Happens when request JSON is
	 * malformed.
	 *
	 * @param ex
	 *            HttpMessageNotReadableException
	 * @param headers
	 *            HttpHeaders
	 * @param status
	 *            HttpStatus
	 * @param request
	 *            WebRequest
	 * @return the ApiError object
	 */
	@Override
	protected ResponseEntity<Object> handleHttpMessageNotReadable(HttpMessageNotReadableException ex,
			HttpHeaders headers, HttpStatus status, WebRequest request) {
		ex.printStackTrace();
		ResponseEntity<Object> responseEntity = null;
		ServletWebRequest servletWebRequest = (ServletWebRequest) request;
		logger.info("{} to {}", servletWebRequest.getHttpMethod(), servletWebRequest.getRequest().getServletPath());

		Acknowledge ack=new Acknowledge();
		ack.setErrorCode(GDSCErrorEnum.BAD_JSON.getValue());
		ack.setErrorDescription(GDSCErrorEnum.BAD_JSON.getText());
		ack.setStackTrace("please check the request data");
		responseEntity = new ResponseEntity<Object>(ack, HttpStatus.BAD_REQUEST);
		return responseEntity;
	}
	
	


}
