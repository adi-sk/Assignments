package com.zycus.integration.GDS.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.Table;

@Entity
@Table(name = "RULE_CONFIGURATION")
public class RuleConfiguration {
	
	@Id
	@Column(name = "ID")
	private String id;
	
	@Column(name = "SOURCE_PRODUCT")
	private String sourceProduct;
	
	@Column(name = "ENTITY")
	private String entity;

	@Column(name = "DIRECTION")
	private String direction;
	
	@Column(name = "EVENT")
	private String event;

	@Column(name = "RULE_NAME")
	private String ruleName;
	
	@Lob
	@Column(name = "GDS_END_POINT")
	private String gdsEndPoint;
	
	@Lob
	@Column(name = "TOPIC")
	private String topic;
	
	@Lob
	@Column(name = "QUEUE")
	private String queue;
	
	@Lob
	@Column(name = "HTTP")
	private String http;

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getRuleName() {
		return ruleName;
	}

	public void setRuleName(String ruleName) {
		this.ruleName = ruleName;
	}

	public String getSourceProduct() {
		return sourceProduct;
	}

	public void setSourceProduct(String sourceProduct) {
		this.sourceProduct = sourceProduct;
	}

	public String getHttp() {
		return http;
	}

	public void setHttp(String http) {
		this.http = http;
	}

	public String getDirection() {
		return direction;
	}

	public void setDirection(String direction) {
		this.direction = direction;
	}

	public String getGdsEndPoint() {
		return gdsEndPoint;
	}

	public void setGdsEndPoint(String gdsEndPoint) {
		this.gdsEndPoint = gdsEndPoint;
	}

	public String getTopic() {
		return topic;
	}

	public void setTopic(String topic) {
		this.topic = topic;
	}

	public String getQueue() {
		return queue;
	}

	public void setQueue(String queue) {
		this.queue = queue;
	}

	public String getEntity() {
		return entity;
	}

	public void setEntity(String entity) {
		this.entity = entity;
	}

	public String getEvent() {
		return event;
	}

	public void setEvent(String event) {
		this.event = event;
	}

	@Override
	public String toString() {
		return "RuleConfiguration [id=" + id + ", sourceProduct=" + sourceProduct + ", entity=" + entity
				+ ", direction=" + direction + ", event=" + event + ", ruleName=" + ruleName + ", gdsEndPoint="
				+ gdsEndPoint + ", topic=" + topic + ", queue=" + queue + ", http=" + http + "]";
	}

}
