package com.zycus.integration.GDS.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;


@Entity
@Table(name = "RULE")
public class Rule {
	
	private String id;
	private String ruleName;
	private String productCode;
	private String entity;
	private String event;
	private String consumerCode;
	
	
	@Id
	@Column(name = "ID")
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	
	@Column(name = "RULE_NAME")
	public String getRuleName() {
		return ruleName;
	}
	public void setRuleName(String ruleName) {
		this.ruleName = ruleName;
	}
	
	@Column(name = "SOURCE_PRODUCT_CODE")
	public String getProductCode() {
		return productCode;
	}
	public void setProductCode(String productCode) {
		this.productCode = productCode;
	}
	
	@Column(name = "ENTITY")
	public String getEntity() {
		return entity;
	}
	public void setEntity(String entity) {
		this.entity = entity;
	}
	
	@Column(name = "EVENT")
	public String getEvent() {
		return event;
	}
	public void setEvent(String event) {
		this.event = event;
	}
	
	@Column(name = "CONSUMER_PRODUCT_CODE")
	public String getConsumerCode() {
		return consumerCode;
	}
	public void setConsumerCode(String consumerCode) {
		this.consumerCode = consumerCode;
	}
	@Override
	public String toString() {
		return "Rule [id=" + id + ", ruleName=" + ruleName + ", productCode=" + productCode + ", entity=" + entity
				+ ", event=" + event + ", consumerCode=" + consumerCode + "]";
	}

	
}
