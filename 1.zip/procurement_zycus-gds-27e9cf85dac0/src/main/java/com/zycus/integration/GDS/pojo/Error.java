package com.zycus.integration.GDS.pojo;

import javax.validation.constraints.NotNull;

import com.fasterxml.jackson.annotation.JsonInclude;

public class Error {

	@NotNull(message="Mandatory and Cannot be null or Empty")
	private String errorCode;
	
	@NotNull(message="Mandatory and Cannot be null or Empty")
	private String errorDescription;

	@JsonInclude(JsonInclude.Include.NON_NULL)
	private String action;
	
	private String stackTrace;

	public String getErrorCode() {
		return errorCode;
	}

	public String getErrorDescription() {
		return errorDescription;
	}

	public String getStackTrace() {
		return stackTrace;
	}

	public Error() {
		super();
	}
	public Error(String errorCode, String errorDescription, String stackTrace) {
		super();
		this.errorCode = errorCode;
		this.errorDescription = errorDescription;
		this.stackTrace = stackTrace;
	}

	public String getAction() {
		return action;
	}

	public Error(String errorCode, String errorDescription, String action, String stackTrace) {
		super();
		this.errorCode = errorCode;
		this.errorDescription = errorDescription;
		this.action = action;
		this.stackTrace = stackTrace;
	}

	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}

	public void setErrorDescription(String errorDescription) {
		this.errorDescription = errorDescription;
	}

	public void setAction(String action) {
		this.action = action;
	}

	public void setStackTrace(String stackTrace) {
		this.stackTrace = stackTrace;
	}

}
