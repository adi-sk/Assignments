
package com.zycus.integration.GDS.enums;
/**
 *punit.sukhija
 *
 */
public enum GDSCStatus {
	
	READY_TO_PROCESS("READY TO PROCESS"),
	SUCCESS("SUCCESS"),
	FAILED("FAILED"),
	PROCESSING("PROCESSING");
	
	private String value;
	
	private GDSCStatus(String value){
		this.value = value;
		
	}

	public String getValue() {
		return value;
	}

}
