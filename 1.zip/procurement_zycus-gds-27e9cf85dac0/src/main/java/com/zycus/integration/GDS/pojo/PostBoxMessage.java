package com.zycus.integration.GDS.pojo;

import javax.validation.constraints.NotNull;

public class PostBoxMessage {
	@NotNull(message="Mandatory and Cannot be null or Empty")
	private String eventId;
	
	@NotNull(message="Mandatory and Cannot be null or Empty")
	private String entityId;
	
	@NotNull(message="Mandatory and Cannot be null or Empty")
	private String eventType;
	
	@NotNull(message="Mandatory and Cannot be null or Empty")
	private String entityType;
	
	@NotNull(message="Mandatory and Cannot be null or Empty")
	private String messageType;
	
	@NotNull(message="Mandatory and Cannot be null or Empty")
	private String productResponse;
	
	@NotNull(message="Mandatory and Cannot be null or Empty")
	private String consumerId;
	
	@NotNull(message="Mandatory and Cannot be null or Empty")
	private String producerId;
	
	@NotNull(message="Mandatory and Cannot be null or Empty")
	private String gdscId;

	@NotNull(message="Mandatory and Cannot be null or Empty")
	private String tenantId;
	
	private String extraInfo;

	public String getEventId() {
		return eventId;
	}

	public void setEventId(String eventId) {
		this.eventId = eventId;
	}

	public String getEntityId() {
		return entityId;
	}

	public void setEntityId(String entityId) {
		this.entityId = entityId;
	}

	public String getEventType() {
		return eventType;
	}

	public void setEventType(String eventType) {
		this.eventType = eventType;
	}

	public String getEntityType() {
		return entityType;
	}

	public void setEntityType(String entityType) {
		this.entityType = entityType;
	}

	public String getMessageType() {
		return messageType;
	}

	public void setMessageType(String messageType) {
		this.messageType = messageType;
	}

	public String getProductResponse() {
		return productResponse;
	}

	public void setProductResponse(String productResponse) {
		this.productResponse = productResponse;
	}

	public String getConsumerId() {
		return consumerId;
	}

	public void setConsumerId(String consumerId) {
		this.consumerId = consumerId;
	}

	public String getProducerId() {
		return producerId;
	}

	public void setProducerId(String producerId) {
		this.producerId = producerId;
	}

	public String getExtraInfo() {
		return extraInfo;
	}

	public void setExtraInfo(String extraInfo) {
		this.extraInfo = extraInfo;
	}

	public String getGdscId() {
		return gdscId;
	}

	public void setGdscId(String gdscId) {
		this.gdscId = gdscId;
	}

	public String getTenantId() {
		return tenantId;
	}

	public void setTenantId(String tenantId) {
		this.tenantId = tenantId;
	}
	
}
