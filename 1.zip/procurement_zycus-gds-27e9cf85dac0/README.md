"# Central GDS to manage and deliver message between products" 
