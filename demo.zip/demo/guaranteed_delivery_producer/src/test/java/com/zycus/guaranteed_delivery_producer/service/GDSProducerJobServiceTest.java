package com.zycus.guaranteed_delivery_producer.service;

import java.sql.Connection;
import java.sql.SQLException;

import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.context.SpringBootTest.WebEnvironment;
import org.springframework.test.annotation.Rollback;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.transaction.annotation.Transactional;

import com.zycus.guaranteed_delivery_producer.dto.DBConnection;

@RunWith(SpringRunner.class)
@SpringBootTest(webEnvironment = WebEnvironment.RANDOM_PORT)
@Transactional
@Rollback
public class GDSProducerJobServiceTest {

	@Autowired
	private GDSProducerJobService gdsProducerJobService;
	
	@Autowired
	private GDSProducerCallBack gdsProduerCallBack; 
	
	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
		System.setProperty("env", "INTEGRATION_BANGALORE");
		System.setProperty("productName", "PRODUCT_1");
		System.setProperty("configSourceHost", "10.10.10.153");
		System.setProperty("gdsProductName", "GUARANTEED-DELIVERY");
	}
	
	@Test
	public void testCaptureEventDataJDBC() throws SQLException {
		Connection connection=gdsProduerCallBack.getConnection().getConnection();
		connection.setAutoCommit(false);
		gdsProducerJobService.captureEventData(gdsProduerCallBack.getConnection());
		connection.rollback();
	}
	
	@Test
	public void testCaptureEventDataJDBCError() {
		gdsProducerJobService.captureEventData(getJDBCDBConnectionObjectError());
	}
	
	@Test
	public void testsendCapturedEventDataJDBC() throws SQLException {
		Connection connection=gdsProduerCallBack.getConnection().getConnection();
		connection.setAutoCommit(false);
		gdsProducerJobService.sendCapturedEventData(gdsProduerCallBack.getConnection());
		connection.rollback();
	}

	@Test
	public void testsendCapturedEventDataJDBCError() {
		gdsProducerJobService.sendCapturedEventData(getJDBCDBConnectionObjectError());
	}
	
	private DBConnection getJDBCDBConnectionObjectError() {
		DBConnection dbconnection=new DBConnection();
		dbconnection.setConnection(null);
		return dbconnection;
	}
}
