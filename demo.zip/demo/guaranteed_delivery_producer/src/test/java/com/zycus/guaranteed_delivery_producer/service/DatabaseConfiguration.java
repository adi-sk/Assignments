package com.zycus.guaranteed_delivery_producer.service;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.zycus.guaranteed_delivery_producer.configuration.GDSProducerConfiguration;
import com.zycus.guaranteed_delivery_producer.exception.GDSProducerException;

@Configuration
public class DatabaseConfiguration {
	
	/*@Bean
	public GDSProducerConfiguration getGDSProducerConfiguration() throws GDSProducerException {
		return new GDSProducerConfiguration("EINVOICE", "http://10.30.30.86:8092", "oracle.jdbc.driver.OracleDriver", "jdbc:oracle:thin:@192.168.2.197:1521:ORCL", "GDS", "GDS","QRTZ_");
	}*/
	

	@Bean
	public GDSProducerConfiguration getGDSProducerConfiguration() throws GDSProducerException {
		return new GDSProducerConfiguration("EINVOICE", "http://10.30.30.86:8092","10.10.10.153",8500,"DEV","GDS");
	}
	/*@Bean
	public GDSProducerConfiguration getGDSProducerConfiguration1() throws GDSProducerException {
		return new GDSProducerConfiguration(productCode, gdsEndpoint, consulHost, consulPort, consulEnvironment, consulProductName, quartzStartUpDelay, cronExpression) 
	}*/
}