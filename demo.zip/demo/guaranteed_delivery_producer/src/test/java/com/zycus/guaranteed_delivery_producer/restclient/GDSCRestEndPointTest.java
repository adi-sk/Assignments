package com.zycus.guaranteed_delivery_producer.restclient;

import java.io.IOException;

import javax.ws.rs.core.Response;

import org.json.JSONException;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.junit4.SpringRunner;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.zycus.guaranteed_delivery_producer.dto.Acknowledge;
import com.zycus.guaranteed_delivery_producer.dto.GDSProducerRequest;
import com.zycus.guaranteed_delivery_producer.util.ObjectConversion;

@RunWith(SpringRunner.class)
public class GDSCRestEndPointTest {
	
	/*@Autowired
	private GDSProducerConfiguration gdsProducerConfiguration;*/
	
	@Test
	public void testUpdateCapturedEventData() throws JsonParseException, JsonMappingException, IOException, JSONException {
		GDSProducerRequest gdsProducerRequest = restDataGenerator();
		Response response = GDSCRestEndPoint.updateCapturedEventData(gdsProducerRequest,"http://192.168.250.166:8092");
		System.out.println(response.getEntity());
		Assert.assertEquals(200, response.getStatus());
		Acknowledge ack =ObjectConversion.convertCGDSResposeToAck((String) response.getEntity());
		Assert.assertNotNull(ack.getAcknowledge().getGdscId());
		Assert.assertNotNull(ack.getAcknowledge().getTimeStamp());
	}

	private GDSProducerRequest restDataGenerator() throws IOException, JsonParseException, JsonMappingException {
		String data="{\r\n" + 
				"    \"id\":\"12390\",\r\n" + 
				"    \"timeStamp\": 1512552319056,\r\n" + 
				"    \"productCode\": \"EPROC\",\r\n" + 
				"    \"additionalInfo\":null,\r\n" + 
				"    \"status\": \"SUCCESS\",\r\n" + 
				"    \"executionAt\": \"CAPTURING_EVENT_DATA\",\r\n" + 
				"    \"deliveryStatus\": null,\r\n" + 
				"    \"errorCode\": null,\r\n" + 
				"    \"errorDescription\": null,\r\n" + 
				"    \"capturedEventData\": {\r\n" + 
				"      \"eventInfo\": {\r\n" + 
				"        \"id\": 76,\r\n" + 
				"        \"eventId\": \"15641e61-4d35-42cf-8f93-d6fadbb468e8\",\r\n" + 
				"        \"entityId\": \"1\",\r\n" + 
				"        \"entityType\": \"REQUISITION\",\r\n" + 
				"        \"eventType\": \"EXTERNAL_SYSTEM\",\r\n" + 
				"        \"version\": \"V1\",\r\n" + 
				"        \"extraInfo\": null,\r\n" + 
				"        \"tenantId\": \"def68304-7e50-463c-95f5-7af9dcb4e600\",\r\n" + 
				"        \"businessRefId\": \"EINVOICE\",\r\n" + 
				"        \"timeStamp\": 1512552319056\r\n" + 
				"      },\r\n" + 
				"      \"messageSet\": [\r\n" + 
				"        {\r\n" + 
				"          \"type\": \"IConsole\",\r\n" + 
				"          \"data\": \"Data for ICONSOLE\"\r\n" + 
				"        }\r\n" + 
				"      ]\r\n" + 
				"    }\r\n" + 
				"  }";
		ObjectMapper objectMapper=new ObjectMapper();
		GDSProducerRequest gdsProducerRequest = objectMapper.readValue(data, GDSProducerRequest.class);
		System.out.println(objectMapper.writeValueAsString(gdsProducerRequest));
		return gdsProducerRequest;
	}
	
	public static void main(String[] args) {
		GDSCRestEndPointTest gdscRestEndPointTest=new GDSCRestEndPointTest();
		try {
			gdscRestEndPointTest.restDataGenerator();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
