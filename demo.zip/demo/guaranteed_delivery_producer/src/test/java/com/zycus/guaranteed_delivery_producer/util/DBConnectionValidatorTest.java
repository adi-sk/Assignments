package com.zycus.guaranteed_delivery_producer.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.context.SpringBootTest.WebEnvironment;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.transaction.annotation.Transactional;

import com.zycus.guaranteed_delivery_producer.dto.DBConnection;
import com.zycus.guaranteed_delivery_producer.exception.GDSProducerException;

@RunWith(SpringRunner.class)
@SpringBootTest(webEnvironment = WebEnvironment.RANDOM_PORT)
@Transactional
public class DBConnectionValidatorTest {

	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
		System.setProperty("env", "INTEGRATION_BANGALORE");
		System.setProperty("productName", "PRODUCT_1");
		System.setProperty("configSourceHost", "10.10.10.153");
		System.setProperty("gdsProductName", "GUARANTEED-DELIVERY");
	}

	@Test(expected=GDSProducerException.class)
	public void TestValidateDBConnection() throws GDSProducerException {
		DBConnectionValidator.validateDBConnection(null);
	}

	@Test
	public void TestValidateDBConnectionWithJDBC() throws GDSProducerException, ClassNotFoundException, SQLException {
		DBConnectionValidator.validateDBConnection(getJDBCDBConnectionObject());
	}

	@Test(expected=GDSProducerException.class)
	public void TestValidateDBConnectionWithJDBCError() throws GDSProducerException {
		DBConnectionValidator.validateDBConnection(getJDBCErrorDBConnectionObject());
	}

	private DBConnection getJDBCDBConnectionObject() throws ClassNotFoundException, SQLException {
		DBConnection dbConnection=new DBConnection();
			Class.forName("oracle.jdbc.driver.OracleDriver");
			Connection connection=DriverManager.getConnection("jdbc:oracle:thin:@192.168.2.197:1521:ORCL","GDS","GDS");  
			dbConnection.setConnection(connection);
			return dbConnection;
	
	}
	private DBConnection getJDBCErrorDBConnectionObject() {
		DBConnection dbConnection=new DBConnection();
		dbConnection.setConnection(null);
		return dbConnection;
	}
}
