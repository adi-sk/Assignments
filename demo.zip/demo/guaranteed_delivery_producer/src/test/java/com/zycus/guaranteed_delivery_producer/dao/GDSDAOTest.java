package com.zycus.guaranteed_delivery_producer.dao;

import java.util.Date;
import java.util.TimeZone;
import java.util.UUID;

import org.junit.Assert;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.context.SpringBootTest.WebEnvironment;
import org.springframework.test.annotation.Rollback;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.transaction.annotation.Transactional;

import com.zycus.guaranteed_delivery_producer.constant.GDSProducerStatus;
import com.zycus.guaranteed_delivery_producer.constant.ProducerExecutionAt;
import com.zycus.guaranteed_delivery_producer.dto.CapturedEventData;
import com.zycus.guaranteed_delivery_producer.dto.DBConnection;
import com.zycus.guaranteed_delivery_producer.dto.EventInfo;
import com.zycus.guaranteed_delivery_producer.enums.GDSProducerErrorEnum;
import com.zycus.guaranteed_delivery_producer.exception.GDSProducerException;
import com.zycus.guaranteed_delivery_producer.service.GDSProducerCallBack;

@RunWith(SpringRunner.class)
@SpringBootTest(webEnvironment = WebEnvironment.RANDOM_PORT)
@Transactional
@Rollback
public class GDSDAOTest {

	@Autowired
	private GDSDAO gdsdao;
	
	@Autowired
	private GDSProducerCallBack gdsProduerCallBack; 
	
	Long eventInfoId=368l;
	
	String eventId = "b6191cc9-9bd2-498f-84c1-b15c9f0badc9";
	
	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
		System.setProperty("env", "INTEGRATION_BANGALORE");
		System.setProperty("productName", "PRODUCT_1");
		System.setProperty("configSourceHost", "10.10.10.153");
		System.setProperty("gdsProductName", "GUARANTEED-DELIVERY");
	}
	
	@Test
	public void saveProducerEventJDBC(){
		try {
			gdsdao.saveProducerEvent(getEventInfo(), getJDBCDBConnectionObject());
		} catch (GDSProducerException e) {
			Assert.assertEquals(GDSProducerErrorEnum.EVENTINFO_PERSIST_FAILED.getValue(), e.getErrorCode());
			Assert.assertEquals(GDSProducerErrorEnum.EVENTINFO_PERSIST_FAILED.getText(), e.getErrorMessage());
		}
	}
	
	@Test
	public void testGetAllPendingEventToCaptureJDBC() {
		try {
			gdsdao.getAllPendingEventToCapture(getJDBCDBConnectionObject());
		} catch (GDSProducerException e) {
			Assert.assertEquals(GDSProducerErrorEnum.FETCH_OPERATION_FAILED.getValue(), e.getErrorCode());
			Assert.assertEquals(GDSProducerErrorEnum.FETCH_OPERATION_FAILED.getText(), e.getErrorMessage());
		}
	}
	
	@Test
	public void testUpdateCapturedEventDataJDBC() throws Exception{
		try {
			gdsdao.updateCapturedEventData(gdsProduerCallBack.captureEvent(getEventInfo()), getJDBCDBConnectionObject());
		} catch (GDSProducerException e) {
			Assert.assertEquals(GDSProducerErrorEnum.UPDATE_OPERATION_FAILED.getValue(), e.getErrorCode());
			Assert.assertEquals(GDSProducerErrorEnum.UPDATE_OPERATION_FAILED.getText(), e.getErrorMessage());
		}
	}

	@Test
	public void testUpdateCapturedEventDataMessageSetNullJDBC() throws Exception{
		CapturedEventData capturedEventData =  gdsProduerCallBack.captureEvent(getEventInfo());
		capturedEventData.setMessageSet(null);
		try {
			gdsdao.updateCapturedEventData(capturedEventData, getJDBCDBConnectionObject());
		} catch (GDSProducerException e) {
			Assert.assertEquals(GDSProducerErrorEnum.UPDATE_OPERATION_FAILED.getValue(), e.getErrorCode());
			Assert.assertEquals(GDSProducerErrorEnum.UPDATE_OPERATION_FAILED.getText(), e.getErrorMessage());
		}
	}
	
	@Test
	public void testGetAllEventPendingToDeliverToGDSCJDBC() {
		try {
			gdsdao.getAllEventPendingToDeliverToGDSC(getJDBCDBConnectionObject());
		} catch (GDSProducerException e) {
			Assert.assertEquals(GDSProducerErrorEnum.FETCH_OPERATION_FAILED.getValue(), e.getErrorCode());
			Assert.assertEquals(GDSProducerErrorEnum.FETCH_OPERATION_FAILED.getText(), e.getErrorMessage());
		}
	}

	@Test
	public void testUpdateExecutionAtJDBC() {
		try {
			gdsdao.updateExecutionAt(eventInfoId, ProducerExecutionAt.CAPTURING_EVENT_DATA,getJDBCDBConnectionObject());
		} catch (GDSProducerException e) {
			Assert.assertEquals(GDSProducerErrorEnum.UPDATE_OPERATION_FAILED.getValue(), e.getErrorCode());
			Assert.assertEquals(GDSProducerErrorEnum.UPDATE_OPERATION_FAILED.getText(), e.getErrorMessage());
		}
	}
	
	@Test
	public void testUpdateStatusJDBC(){
		try {
			gdsdao.updateStatus(eventInfoId, GDSProducerStatus.GDSPRODUCER_PROCESSING,getJDBCDBConnectionObject());
		} catch (GDSProducerException e) {
			Assert.assertEquals(GDSProducerErrorEnum.UPDATE_OPERATION_FAILED.getValue(), e.getErrorCode());
			Assert.assertEquals(GDSProducerErrorEnum.UPDATE_OPERATION_FAILED.getText(), e.getErrorMessage());
		}
	}
	
	@Test
	public void testUpdateErrorCodeAndDescriptionJDBC()  {
		try {
			gdsdao.updateErrorCodeAndDescription(eventInfoId,GDSProducerErrorEnum.CONVERTING_CAPTUREDEVENTDATA_TO_STRING_FAILED.getValue(),GDSProducerErrorEnum.CONVERTING_CAPTUREDEVENTDATA_TO_STRING_FAILED.getText(), getJDBCDBConnectionObject());
		} catch (GDSProducerException e) {
			Assert.assertEquals(GDSProducerErrorEnum.UPDATE_OPERATION_FAILED.getValue(), e.getErrorCode());
			Assert.assertEquals(GDSProducerErrorEnum.UPDATE_OPERATION_FAILED.getText(), e.getErrorMessage());
		}
	}
	
	@Test
	public void testUpdateGDSCIdJDBC()  {
		 try {
			gdsdao.updateGDSCId(eventId, "Test123", getJDBCDBConnectionObject());
		} catch (GDSProducerException e) {
			Assert.assertEquals(GDSProducerErrorEnum.UPDATE_OPERATION_FAILED.getValue(), e.getErrorCode());
			Assert.assertEquals(GDSProducerErrorEnum.UPDATE_OPERATION_FAILED.getText(), e.getErrorMessage());
		}
	}
	
	@Test
	public void testupdateExecutionAtWithStatusJDBC()  {
		try {
			gdsdao.updateExecutionAtWithStatus(eventInfoId, ProducerExecutionAt.CAPTURING_EVENT_DATA, GDSProducerStatus.GDSPRODUCER_PROCESSING, getJDBCDBConnectionObject());
		} catch (GDSProducerException e) {
			Assert.assertEquals(GDSProducerErrorEnum.UPDATE_OPERATION_FAILED.getValue(), e.getErrorCode());
			Assert.assertEquals(GDSProducerErrorEnum.UPDATE_OPERATION_FAILED.getText(), e.getErrorMessage());
		}
	}
	
	private DBConnection getJDBCDBConnectionObject() {
		DBConnection dbconnection=new DBConnection();
		dbconnection.setConnection(null);
		return dbconnection;
	}
	public EventInfo getEventInfo() {
		EventInfo eventInfo=new EventInfo();
		eventInfo.setEventId(UUID.randomUUID().toString());
		eventInfo.setEventType("SUBMITTED");
		eventInfo.setEntityId("1");
		eventInfo.setEntityType("INVOICE");
		eventInfo.setBusinessRefId("EINVOICE");
		eventInfo.setTenantId("def68304-7e50-463c-95f5-7af9dcb4e600");
		TimeZone.setDefault(TimeZone.getTimeZone("UTC"));
		eventInfo.setTimeStamp(new Date());
		eventInfo.setVersion("V1");
		eventInfo.setId(eventInfoId);
		return eventInfo;
	}
}
