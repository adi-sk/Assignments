package com.zycus.guaranteed_delivery_producer.util;

import java.io.IOException;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.zycus.guaranteed_delivery_producer.dto.CapturedEventData;
import com.zycus.guaranteed_delivery_producer.dto.GDSProducerRequest;
import com.zycus.guaranteed_delivery_producer.model.GDSProducerData;
/**
 * Util class for converting GDSProducerData(DB) Object.
 * @author narendra.m
 *
 */
public class GDSProducerDataUtil {
	/**
	 * Util class for converting GDSProducerData(DB) Object to GDSProducerRequest(DTO) for sending to CGDS
	 * @param gdsProducerData
	 * @param productCode
	 * @return
	 */
	public GDSProducerRequest convertGDSProducerDataToGDSProducerRequest(GDSProducerData gdsProducerData,String productCode) {
		GDSProducerRequest gdsProducerRequest= new GDSProducerRequest();
		gdsProducerRequest.setAdditionalInfo(gdsProducerData.getExtraInfo());
		gdsProducerRequest.setCapturedEventData(getCapturedEventData(gdsProducerData.getData()));
		gdsProducerRequest.setDeliveryStatus(gdsProducerData.getDeliveryStatus());
		gdsProducerRequest.setErrorCode(gdsProducerData.getErrorCode());
		gdsProducerRequest.setErrorDescription(gdsProducerData.getErrorDescription());
		gdsProducerRequest.setExecutionAt(gdsProducerData.getExecutionAt());
		gdsProducerRequest.setId(gdsProducerData.getId());
		gdsProducerRequest.setProductCode(productCode);
		gdsProducerRequest.setStatus(gdsProducerData.getStatus());
		gdsProducerRequest.setTimeStamp(gdsProducerData.getTimeStamp());
		return gdsProducerRequest;
	}
	
	/**
	 * Convert JSON String to CapturedEventData Object
	 * @param data - {@link String}
	 * @return {@link CapturedEventData} if data is not null else null
	 */
	public CapturedEventData getCapturedEventData(String data) {
		if(null == data) {
			return null;
		}
		try {
			ObjectMapper objectMapper=new ObjectMapper();
			CapturedEventData capturedEventData = objectMapper.readValue(data, CapturedEventData.class);
			return capturedEventData;
		}
		catch (IOException e) {
			return null;
		}
	}
}
