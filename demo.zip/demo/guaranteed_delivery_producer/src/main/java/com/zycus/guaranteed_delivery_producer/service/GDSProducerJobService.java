package com.zycus.guaranteed_delivery_producer.service;

import com.zycus.guaranteed_delivery_producer.dto.DBConnection;

public interface GDSProducerJobService {

	/**
	 * Gets all Event that need to capture CaptureEventData and makes GDSProducerCallBack to get CaptureEventData on EventInfo and updates the DB.
	 * @param dbConnection
	 */
	void captureEventData(DBConnection dbConnection);

	/**
	 * Get's all event that need to send to central GDS and Send via CGDS Rest End point.
	 * @param dbConnection
	 */
	void sendCapturedEventData(DBConnection dbConnection);

}
