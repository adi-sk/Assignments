package com.zycus.guaranteed_delivery_producer.dto;

import java.util.Date;

import javax.xml.bind.annotation.XmlRootElement;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonRootName;

@XmlRootElement(name="acknowledge")
@JsonRootName("acknowledge")
@JsonIgnoreProperties("acknowledge")
public class GDSCSucessResponseForProducer {

	private String gdscId;

	private Date timeStamp;

	public String getGdscId() {
		return gdscId;
	}

	public void setGdscId(String gdscId) {
		this.gdscId = gdscId;
	}

	public Date getTimeStamp() {
		return timeStamp;
	}

	public void setTimeStamp(Date timeStamp) {
		this.timeStamp = timeStamp;
	}

}
