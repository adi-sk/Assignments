package com.zycus.guaranteed_delivery_producer.util;

import java.util.ArrayList;
import java.util.List;

import com.zycus.guaranteed_delivery_producer.dto.EventInfo;

/**
 * Validate's EventInfo Object
 * 
 * @author narendra.m
 *
 */
public class EventInfoValidator {
	/**
	 * Validate EventInfo Object
	 * 
	 * @param eventInfo
	 * @return
	 */
	public static List<String> validateEventInfo(EventInfo eventInfo) {
		List<String> errorList = new ArrayList<String>();
		if (eventInfo == null) {
			errorList.add("eventInfo : Cannot be null)");
		} else {
			if (checkIfNullNEmpty(eventInfo.getEventId())) {
				errorList.add("eventInfo : (eventId : Cannot be null or Empty)");
			}
			if (checkIfNullNEmpty(eventInfo.getEntityId())) {
				errorList.add("eventInfo : (entityId : Cannot be null or Empty)");
			}
			if (checkIfNullNEmpty(eventInfo.getEntityType())) {
				errorList.add("eventInfo : (entityType : Cannot be null or Empty)");
			}
			if (checkIfNullNEmpty(eventInfo.getEventType())) {
				errorList.add("eventInfo : (eventType : Cannot be null or Empty)");
			}
			if (checkIfNullNEmpty(eventInfo.getTenantId())) {
				errorList.add("eventInfo : (tenantId : Cannot be null or Empty)");
			}
			if (checkIfNullNEmpty(eventInfo.getBusinessRefId())) {
				errorList.add("eventInfo : (businessRefId : Cannot be null or Empty)");
			}
			if (checkIfNullNEmpty(eventInfo.getVersion())) {
				errorList.add("eventInfo : (version : Cannot be null or Empty)");
			}
		}

		return errorList;
	}

	private static boolean checkIfNullNEmpty(String str) {
		return (str == null || str.isEmpty()) ? true : false;
	}
}
