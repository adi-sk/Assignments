package com.zycus.guaranteed_delivery_producer.enums;

import java.sql.Connection;

public enum DBConnectionErrorEnum {
	/**
	 * Represent's {@link DBConnection} Object is null
	 */
	DBCONNECTION_NULL {
		@Override
		public String getValue() {
			return "NR-GDSP-C-1000";
		}
		@Override
		public String getText() {
			return "DBConnection Object can't be Null";
		}
	},
	/**
	 * Represent's {@link Connection} Object is null if HibernateToUse is false
	 */
	DBCONNECTION_HIBERNATE_FALSE_CONNECTION_NULL {
		@Override
		public String getValue() {
			return "NR-GDSP-C-1002";
		}
		@Override
		public String getText() {
			return "DBConnection-> Connection Object can't be Null";
		}
	},
	;	
	
	public abstract String getText();
	public abstract String getValue();

}
