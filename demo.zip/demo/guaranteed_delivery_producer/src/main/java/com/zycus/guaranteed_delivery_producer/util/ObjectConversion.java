package com.zycus.guaranteed_delivery_producer.util;

import java.io.IOException;

import org.json.JSONException;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.zycus.guaranteed_delivery_producer.dto.Acknowledge;
/**
 * Util Class for converting any object to JSON String
 * @author narendra.m
 *
 */
public class ObjectConversion {

	/**
	 * Util Class for converting any object to JSON String
	 * @param anyObject
	 * @return {@link String}
	 * @throws JsonProcessingException
	 */
	public static String convertObjectToJSONString(Object anyObject) throws JsonProcessingException {
		ObjectMapper objectMapper=new ObjectMapper();
		String JsonString=objectMapper.writeValueAsString(anyObject);
		return JsonString;
	}

	public static Acknowledge convertCGDSResposeToAck(String jsonResponse) throws JsonParseException, JsonMappingException, IOException, JSONException {
		ObjectMapper objectMapper=new ObjectMapper();
		Acknowledge acknowledge = objectMapper.readValue(jsonResponse, Acknowledge.class);
		return acknowledge;
	}

}
