package com.zycus.guaranteed_delivery_producer.dto;

import java.util.Date;

public class GDSProducerRequest implements Comparable<GDSProducerRequest>{

	private long id;

	private Date timeStamp;

	private String productCode;

	private String additionalInfo;

	private String status;

	private String executionAt;

	private String deliveryStatus;

	private String errorCode;

	private String errorDescription;

	private CapturedEventData capturedEventData;

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public Date getTimeStamp() {
		return timeStamp;
	}

	public void setTimeStamp(Date timeStamp) {
		this.timeStamp = timeStamp;
	}

	public String getProductCode() {
		return productCode;
	}

	public void setProductCode(String productCode) {
		this.productCode = productCode;
	}

	public String getAdditionalInfo() {
		return additionalInfo;
	}

	public void setAdditionalInfo(String additionalInfo) {
		this.additionalInfo = additionalInfo;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getExecutionAt() {
		return executionAt;
	}

	public void setExecutionAt(String executionAt) {
		this.executionAt = executionAt;
	}

	public String getDeliveryStatus() {
		return deliveryStatus;
	}

	public void setDeliveryStatus(String deliveryStatus) {
		this.deliveryStatus = deliveryStatus;
	}

	public String getErrorCode() {
		return errorCode;
	}

	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}

	public String getErrorDescription() {
		return errorDescription;
	}

	public void setErrorDescription(String errorDescription) {
		this.errorDescription = errorDescription;
	}

	public CapturedEventData getCapturedEventData() {
		return capturedEventData;
	}

	public void setCapturedEventData(CapturedEventData capturedEventData) {
		this.capturedEventData = capturedEventData;
	}

	@Override
	public int compareTo(GDSProducerRequest gdsProducerRequest) {
		return ((Long)this.id).compareTo((Long)gdsProducerRequest.getId());
	}

}
