package com.zycus.guaranteed_delivery_producer.constant;

/**
 * This Static Constant's Represents the Request/Event Status. 
 * @author Narendra M
 * 
 *
 */
public interface GDSProducerStatus {

	/**
	 * Constant Represents Request in processing Status 
	 */
	String GDSPRODUCER_PROCESSING="PROCESSING";
	/**
	 * Constant Represents Request in Success Status 
	 */
	String GDSPRODUCER_SUCCESS="SUCCESS";
	
	/**
	 * Constant Represents Request in Failed Status 
	 */
	String GDSPRODUCER_FAILED="FAILED";

	/**
	 * Constant Represents Request Can't be Recovered
	 */
	String GDSPRODUCER_CANT_BE_RECOVERED="CANT_BE_RECOVERED";
	
}
