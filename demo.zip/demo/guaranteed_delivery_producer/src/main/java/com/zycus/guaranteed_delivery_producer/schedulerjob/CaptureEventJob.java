package com.zycus.guaranteed_delivery_producer.schedulerjob;

import java.util.Date;
import java.util.TreeSet;
import java.util.concurrent.Callable;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.zycus.guaranteed_delivery_producer.constant.BaseConstant;
import com.zycus.guaranteed_delivery_producer.constant.GDSProducerStatus;
import com.zycus.guaranteed_delivery_producer.constant.ProducerExecutionAt;
import com.zycus.guaranteed_delivery_producer.dto.CapturedEventData;
import com.zycus.guaranteed_delivery_producer.dto.DBConnection;
import com.zycus.guaranteed_delivery_producer.dto.EventInfo;
import com.zycus.guaranteed_delivery_producer.enums.GDSProducerErrorEnum;
import com.zycus.guaranteed_delivery_producer.exception.GDSProducerException;
import com.zycus.guaranteed_delivery_producer.service.GDSProducerCallBack;
import com.zycus.guaranteed_delivery_producer.service.GDSProducerService;
import com.zycus.guaranteed_delivery_producer.util.ClusterLeader;

public class CaptureEventJob implements Callable<String>{

	private static final Logger LOG = LoggerFactory.getLogger(CaptureEventJob.class);

	private TreeSet<EventInfo> eventInfoList; 
	private GDSProducerService gdsProducerService;
	private GDSProducerCallBack gdsProducerCallBack; 
	private ClusterLeader clusterLeader;
	private String keyOrder;
	private DBConnection dbConnection;

	public CaptureEventJob(TreeSet<EventInfo> eventInfoList, GDSProducerService gdsProducerService,
			GDSProducerCallBack gdsProducerCallBack, ClusterLeader clusterLeader, String keyOrder,DBConnection dbConnection) {
		super();
		this.eventInfoList = eventInfoList;
		this.gdsProducerService = gdsProducerService;
		this.gdsProducerCallBack = gdsProducerCallBack;
		this.clusterLeader = clusterLeader;
		this.keyOrder = keyOrder;
		this.dbConnection=dbConnection;
	}

	@Override
	public String call() throws Exception {
		if(acquireLock(keyOrder)) {
			for(EventInfo eventInfo:eventInfoList) {
				try {
					if(gdsProducerService.getStatusOfAnEvent(eventInfo.getId(), ProducerExecutionAt.CAPTURING_EVENT_DATA, GDSProducerStatus.GDSPRODUCER_SUCCESS, dbConnection)) {
						LOG.info("Capturing Event Data for Event id - "+eventInfo.getEventId());
						gdsProducerService.updateExecutionAtWithStatus(eventInfo.getId(), ProducerExecutionAt.CAPTURING_EVENT_DATA,GDSProducerStatus.GDSPRODUCER_PROCESSING, dbConnection);

						CapturedEventData capturedEventData = gdsProducerCallBack.captureEvent(eventInfo);//exception type need to be added
						if(capturedEventData==null) {
							throw new GDSProducerException(GDSProducerErrorEnum.GDS_PRODUCER_CAPTUREVENT_CANNOT_BE_NULL.getText(),GDSProducerErrorEnum.GDS_PRODUCER_CAPTUREVENT_CANNOT_BE_NULL.getValue());
						}
						eventInfo.setExtraInfo(capturedEventData.getEventInfo()==null?null:capturedEventData.getEventInfo().getExtraInfo());
						capturedEventData.setEventInfo(eventInfo);
						boolean dataCaptured = gdsProducerService.updateCapturedEventData(capturedEventData, dbConnection);
						if(dataCaptured) {
							gdsProducerService.updateStatus(eventInfo.getId(), GDSProducerStatus.GDSPRODUCER_SUCCESS, dbConnection);
						}else {
							gdsProducerService.updateStatus(eventInfo.getId(), GDSProducerStatus.GDSPRODUCER_FAILED, dbConnection);
							releaseAndDeleteLock(keyOrder);
							break;
						}
					}
				}catch(GDSProducerException e) {
					LOG.error("Unable to CaptureEventData for Event(EventId - "+ eventInfo.getEventId()+") {}",e);
					gdsProducerService.updateStatus(eventInfo.getId(), GDSProducerStatus.GDSPRODUCER_FAILED, dbConnection);
					gdsProducerCallBack.sendNotifcation("Unable to CaptureEventData {} "+e);
					releaseAndDeleteLock(keyOrder);
					break;
				}catch(Exception e) {
					LOG.error("Unable to CaptureEventData for Event(EventId - "+ eventInfo.getEventId()+") {}",e);
					gdsProducerService.updateStatus(eventInfo.getId(), GDSProducerStatus.GDSPRODUCER_FAILED, dbConnection);
					gdsProducerCallBack.sendNotifcation("Unable to CaptureEventData for Event(EventId - "+ eventInfo.getEventId()+") {} "+e);
					releaseAndDeleteLock(keyOrder);
					break;
				}

			}
			releaseAndDeleteLock(keyOrder);
			return keyOrder +BaseConstant.LOCK_ACQ_SUCCESS_MSG;
		}else {
			releaseLockOnTimeExceed(keyOrder);
			return keyOrder +BaseConstant.LOCK_ACQ_FAILED_MSG;
		}
	}

	private void releaseLockOnTimeExceed(String key) {
		String value = clusterLeader.getValueForKey(key);
		if(value!=null) {
			long time = Long.parseLong(value);
			Date date = new Date(time);
			Date date1= new Date();
			long diff = date1.getTime() - date.getTime();
			long diffHours = diff / (60 * 60 * 1000);
			long diffMinutes = diff / (60 * 1000) % 60 + diffHours*60;
			if(diffMinutes>BaseConstant.CONSUL_LOCK_EXPIRE_TIME) {
				LOG.info("Lock has been released after "+BaseConstant.CONSUL_LOCK_EXPIRE_TIME +" for key - "+key);
				releaseAndDeleteLock(key);
			}
		}
	}

	private void releaseAndDeleteLock(String key) {
		clusterLeader.releaseLock(key);
		clusterLeader.removeKey(key);
	}
	private boolean acquireLock(String keyOrder) {
		return clusterLeader.accquireLeadership(keyOrder);
	}

}
