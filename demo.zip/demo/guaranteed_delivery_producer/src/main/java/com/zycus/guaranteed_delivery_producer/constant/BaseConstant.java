package com.zycus.guaranteed_delivery_producer.constant;

public interface BaseConstant {
	public static final String HTTP = "http://";
	public static final String HTTP_TAG = "HTTP";
	public static final String TCP_TAG = "TCP";
	public static final String POST = "POST";
	public static final String PUT = "PUT";
	public static final String GET = "GET";
	public static final String REGISTER_API = "/v1/agent/service/register";
	public static final String DEREGISTER_API = "/v1/agent/service/deregister/";
	public static final String CONSUL_GET_SERVICE_API = "/v1/catalog/service/";
	public static final String UTF8_ENCODING = "UTF-8";
	public static final String SESSION_ACCQUISTION_URL = "/v1/session/create";
	public static final String SESSION_DELETION_URL = "/v1/session/destroy/%s";
	public static final String LOCK_ACQUISTION_URL = "/v1/kv/%s/%s/COMMON/LEADERSHIP/%s";
	public static final Integer CONSUL_LOCK_EXPIRE_TIME = 3;
	public String LOCK_ACQ_SUCCESS_MSG = " Lock Acquired & Processed SuccessFully";
	public String LOCK_ACQ_FAILED_MSG = " Lock Failed & Processed UnsuccessFully";
	
}
