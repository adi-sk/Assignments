package com.zycus.guaranteed_delivery_producer.restclient;

import javax.ws.rs.core.Response;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.HttpServerErrorException;
import org.springframework.web.client.ResourceAccessException;
import org.springframework.web.client.RestTemplate;

import com.zycus.guaranteed_delivery_producer.constant.GDSRestResponseConstant;
import com.zycus.guaranteed_delivery_producer.dao.impl.GDSProducerDataDAOImpl;
import com.zycus.guaranteed_delivery_producer.dto.DataPacket;
import com.zycus.guaranteed_delivery_producer.dto.GDSProducerRequest;

public class GDSCRestEndPoint {

	private static final Logger LOG = LoggerFactory.getLogger(GDSProducerDataDAOImpl.class);
	
	public static Response updateCapturedEventData(GDSProducerRequest gdsRequest,String endPoint) {
		
		String URL = endPoint+"/gds/postData";
		HttpMethod httpMethod =  HttpMethod.POST;
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);
		RestTemplate restTemplate = new RestTemplate();
		DataPacket dataPacket=new DataPacket();
		dataPacket.setDataPacket(gdsRequest);
		HttpEntity<DataPacket> request = new HttpEntity<DataPacket>(dataPacket,headers);
		ResponseEntity<String> response=null;
		try {
			response = restTemplate.exchange(URL,httpMethod, request, String.class);
			return Response.status(response.getStatusCode().value()).entity(response.getBody()).build();
			
		}catch(HttpServerErrorException e) {
			return Response.status(Response.Status.INTERNAL_SERVER_ERROR).entity(e.getResponseBodyAsString()).build();
		}catch(HttpClientErrorException e) {
			return Response.status(Response.Status.INTERNAL_SERVER_ERROR).entity(e.getResponseBodyAsString()).build();

		} catch (ResourceAccessException e) {
			LOG.error("Failed to send to CGDS due to {} ",e);
			return Response.status(GDSRestResponseConstant.SEND_CONNECTION_TIMEOUT).entity(e.getMessage()).build();
		}catch(Exception e) {
			LOG.error("Failed to send to CGDS due to {} ",e);
			return Response.status(GDSRestResponseConstant.OTHER_EXCEPTION).entity(e.getMessage().toString()).build();
		}
		
	}

}
