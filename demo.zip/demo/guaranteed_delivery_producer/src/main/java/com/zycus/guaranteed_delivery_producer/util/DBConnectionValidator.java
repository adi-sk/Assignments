package com.zycus.guaranteed_delivery_producer.util;

import com.zycus.guaranteed_delivery_producer.dto.DBConnection;
import com.zycus.guaranteed_delivery_producer.enums.DBConnectionErrorEnum;
import com.zycus.guaranteed_delivery_producer.exception.GDSProducerException;
/**
 * Validates DBConnection Object implemented by product in GDSProducerCallBack interface
 * @author narendra.m
 *
 */
public class DBConnectionValidator {

	public static void validateDBConnection(DBConnection dbConnection) throws GDSProducerException {
		if(null == dbConnection) {
			throw new GDSProducerException(DBConnectionErrorEnum.DBCONNECTION_NULL.getText(),DBConnectionErrorEnum.DBCONNECTION_NULL.getValue());
		}
		if(null == dbConnection.getConnection()) {
			throw new GDSProducerException(DBConnectionErrorEnum.DBCONNECTION_HIBERNATE_FALSE_CONNECTION_NULL.getText(),DBConnectionErrorEnum.DBCONNECTION_HIBERNATE_FALSE_CONNECTION_NULL.getValue());
		}
	}
}
