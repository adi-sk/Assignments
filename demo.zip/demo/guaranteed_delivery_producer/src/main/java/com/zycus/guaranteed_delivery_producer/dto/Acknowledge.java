package com.zycus.guaranteed_delivery_producer.dto;

public class Acknowledge {

	GDSResponse acknowledge;

	public GDSResponse getAcknowledge() {
		return acknowledge;
	}

	public void setAcknowledge(GDSResponse acknowledge) {
		this.acknowledge = acknowledge;
	}
	
}
