package com.zycus.guaranteed_delivery_producer.dao.impl;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.zycus.guaranteed_delivery_producer.dao.GDSDAO;
import com.zycus.guaranteed_delivery_producer.dto.CapturedEventData;
import com.zycus.guaranteed_delivery_producer.dto.DBConnection;
import com.zycus.guaranteed_delivery_producer.dto.EventInfo;
import com.zycus.guaranteed_delivery_producer.exception.GDSProducerException;
import com.zycus.guaranteed_delivery_producer.model.GDSProducerData;

@Repository
public class GDSDAOImpl extends GDSProducerDataDAOImpl implements GDSDAO {

	@Override
	public boolean saveProducerEvent(EventInfo eventInfo, DBConnection dbConnection) throws GDSProducerException {
		return saveProducerEvent(eventInfo, dbConnection.getConnection());
	}

	@Override
	public List<EventInfo> getAllPendingEventToCapture(DBConnection dbConnection) throws GDSProducerException {
		return getAllPendingEventToCapture(dbConnection.getConnection());
	}

	@Override
	public boolean updateCapturedEventData(CapturedEventData capturedEventData, DBConnection dbConnection)
			throws GDSProducerException {
		return updateCapturedEventData(capturedEventData, dbConnection.getConnection());
	}

	@Override
	public boolean updateGDSCId(String eventId, String gdscId, DBConnection dbConnection) throws GDSProducerException {
		return updateGDSCId(eventId, gdscId, dbConnection.getConnection());
	}

	@Override
	public List<GDSProducerData> getAllEventPendingToDeliverToGDSC(DBConnection dbConnection)
			throws GDSProducerException {
		return getAllEventPendingToDeliverToGDSC(dbConnection.getConnection());
	}

	@Override
	public boolean updateExecutionAt(Long reqId, String executionAt, DBConnection dbConnection)
			throws GDSProducerException {
		return updateExecutionAt(reqId, executionAt, dbConnection.getConnection());
	}

	@Override
	public boolean updateStatus(Long reqId, String status, DBConnection dbConnection) throws GDSProducerException {
		return updateStatus(reqId, status, dbConnection.getConnection());
	}

	@Override
	public boolean updateErrorCodeAndDescription(Long reqId, String errorCode, String stackTrace,
			DBConnection dbConnection) throws GDSProducerException {
		return updateErrorCodeAndDescription(reqId, errorCode, stackTrace, dbConnection.getConnection());
	}

	@Override
	public boolean updateExecutionAtWithStatus(Long reqId, String executionAt, String status, DBConnection dbConnection)
			throws GDSProducerException {
		return updateExecutionAtWithStatus(reqId, executionAt, status, dbConnection.getConnection());
	}

	@Override
	public boolean getStatusOfAnEvent(Long reqId, String executionAt, String status, DBConnection dbConnection)
			throws GDSProducerException {
		return getStatusOfAnEvent(reqId, executionAt, status, dbConnection.getConnection());
	}

}
