package com.zycus.guaranteed_delivery_producer.dto;

import java.util.Date;

public class GDSResponse {
	private String gdscId;

	private Date timeStamp;

	private String errorCode;
	
	private String errorDescription;
	
	private String stackTrace;

	public String getGdscId() {
		return gdscId;
	}

	public void setGdscId(String gdscId) {
		this.gdscId = gdscId;
	}

	public Date getTimeStamp() {
		return timeStamp;
	}

	public void setTimeStamp(Date timeStamp) {
		this.timeStamp = timeStamp;
	}

	public String getErrorCode() {
		return errorCode;
	}

	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}

	public String getErrorDescription() {
		return errorDescription;
	}

	public void setErrorDescription(String errorDescription) {
		this.errorDescription = errorDescription;
	}

	public String getStackTrace() {
		return stackTrace;
	}

	public void setStackTrace(String stackTrace) {
		this.stackTrace = stackTrace;
	}
	
}
