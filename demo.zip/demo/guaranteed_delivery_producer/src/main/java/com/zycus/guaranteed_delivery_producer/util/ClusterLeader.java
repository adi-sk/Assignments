
package com.zycus.guaranteed_delivery_producer.util;

import java.net.MalformedURLException;
import java.net.URISyntaxException;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpDelete;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPut;
import org.apache.http.client.utils.URIBuilder;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.util.EntityUtils;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.oreilly.servlet.Base64Decoder;
import com.zycus.guaranteed_delivery_producer.configuration.GDSProducerConfiguration;
import com.zycus.guaranteed_delivery_producer.constant.BaseConstant;

@Component
public class ClusterLeader {

	private static final Logger LOGGER = LoggerFactory.getLogger(ClusterLeader.class);

	//private String sessionId;
	private static Map<String, String> sessionIdKeyMap = new HashMap<String, String>();
	private boolean isLeader;

	@Autowired
	private GDSProducerConfiguration gdsProducerConfiguration;

	public boolean accquireLeadership(String key) {
		LOGGER.info("Running leadership election process for {}:",key);

		LOGGER.info("Key to be used as lock : {}",key ); 

		if(StringUtils.isEmpty(key)){
			LOGGER.error("Key provided as arguement is empty");
			return false;
		}
		LOGGER.info("Checking if current instance is leader");

		verifyLeadership(key);
		if (accquireSessionId(key)) {
			isLeader = accquireLock(key);
		}

		return isLeader;
	}

	public boolean removeKey(String key) {
		try {
			String url = getAccquireLockUrl(key);
			LOGGER.info("Attempting to remove key . URL : {}", url);
			HttpDelete httpPut = new HttpDelete(url);
			CloseableHttpResponse response = HttpClients.createDefault().execute(httpPut);
			int statusCode = response.getStatusLine().getStatusCode();

			if (statusCode == 200) {
				String responseValue = EntityUtils.toString(response.getEntity());
				LOGGER.info("Response obtained from consul for removing {} is {}", key, responseValue);
				return Boolean.parseBoolean(responseValue);
			}

			else {
				LOGGER.error("Non 200 response while removing key. Response code is : {}", statusCode);
				return false;
			}
		}
		catch (Exception e) {
			LOGGER.error("Error in removing key from consul", e);
			return false;
		}
	}
	public String getValueForKey(String key) {
		try {
			String url = getAccquireLockUrl(key);
			LOGGER.info("Attempting to get value for key . URL : {}", url);
			HttpGet httpPut = new HttpGet(url);
			CloseableHttpResponse response = HttpClients.createDefault().execute(httpPut);
			int statusCode = response.getStatusLine().getStatusCode();
			
			if (statusCode == 200) {
				JSONArray jsonArray = (JSONArray) new JSONParser().parse(EntityUtils.toString(response.getEntity()));
				JSONObject jsonObj = (JSONObject) jsonArray.get(0);
				String value = (String) jsonObj.get("Value");
				String responseValue = Base64Decoder.decode(value);
				
				LOGGER.info("Response obtained from consul for get Value for key {} is {}", key, responseValue);
				return responseValue;
			}
			
			else {
				LOGGER.error("Non 200 response while get value for key. Response code is : {}", statusCode);
				return null;
			}
		}
		catch (Exception e) {
			LOGGER.error("Error in gettting value for key from consul", e);
			return null;
		}
	}
	private void verifyLeadership(String key) {
		if (!isLeader) {
			LOGGER.info("No need for verifying leadership as instance is not leader.");
		} else {
			boolean check = verifyIfSessionisAssociatedWithLock(key);
			if (!check) {
				releaseLock(key);
				deleteSession(key);
				isLeader = false;
			}
		}
	}


	private boolean verifyIfSessionisAssociatedWithLock(String key) {
		try {
			LOGGER.info("Key to be used for verification : {}",key );

			String url = getLockStatusUrl(key);
			LOGGER.info("Attempting to check status of lock . URL : {}", url);
			HttpGet httpGet = new HttpGet(url);
			CloseableHttpResponse response =  HttpClients.createDefault().execute(httpGet);
			int statusCode = response.getStatusLine().getStatusCode();

			if (statusCode == 200) {
				JSONArray jsonArray = (JSONArray) new JSONParser().parse(EntityUtils.toString(response.getEntity()));
				JSONObject jsonObj = (JSONObject) jsonArray.get(0);
				String sessionIdAssocaiatedWithLock = (String) jsonObj.get("Session");

				if(StringUtils.isEmpty(sessionIdAssocaiatedWithLock)){
					LOGGER.info("No session was found to be associated with the lock");
					return false;
				}
				else{
					String sessionId=sessionIdKeyMap.get(key);
					boolean status =  sessionId.equalsIgnoreCase(sessionIdAssocaiatedWithLock);
					LOGGER.info("Instance still master : {} ",status);
					return status;
				}

			} else {
				LOGGER.error("Non 200 response while checking status of lock . Response code is : {}", statusCode);
				return false;
			}

		} catch (Exception e) {
			//LOGGER.error("Error in checking status of lock from consul", e);
			return false;
		}

	}


	public boolean isLeader() {
		return isLeader;
	}

	private void deleteSession(String key) {
		try {
			String url = getDeleteSessionUrl(key);
			LOGGER.info("Attempting to delete session . URL : {}", url);
			HttpPut httpPut = new HttpPut(url);
			CloseableHttpResponse response = HttpClients.createDefault().execute(httpPut);
			int statusCode = response.getStatusLine().getStatusCode();

			if (statusCode == 200) {
				String responseValue = EntityUtils.toString(response.getEntity());
				String sessionId=sessionIdKeyMap.get(key);
				LOGGER.info("Status of deleting session with id {} is {} ", sessionId, responseValue); 

			} else {
				LOGGER.error("Non 200 response while deleting session . Response code is : {}", statusCode);
			}

			sessionIdKeyMap.remove(key);

		} catch (Exception e) {
			LOGGER.error("Error in accquiring session from consul", e);
		}

	}

	private boolean accquireSessionId(String key) {

		boolean success = false;
		try {
			String url = getSessionUrl();
			LOGGER.info("Attempting to accquire session  . URL : {}", url);
			HttpPut httpPut = new HttpPut(url);
			CloseableHttpResponse response = HttpClients.createDefault().execute(httpPut);
			int statusCode = response.getStatusLine().getStatusCode();

			if (statusCode == 200 && response.getEntity()!=null) {
				JSONObject jsonObject = (JSONObject) new JSONParser().parse(EntityUtils.toString(response.getEntity()));
				String sessionId = (String) jsonObject.get("ID");
				LOGGER.info("Session accquired is : {}", sessionId);
				sessionIdKeyMap.put(key, sessionId);
				success = true;
			}

			else {
				LOGGER.error("Non 200 response while accquiring session . Response code is : {}", statusCode);
			}

		} catch (Exception e) {
			LOGGER.error("Error in accquiring session from consul", e);
		}

		return success;
	}

	private boolean accquireLock(String key) {

		try {
			String url = getAccquireLockUrl(key);
			LOGGER.info("Attempting to accquire lock . URL : {}", url);
			HttpPut httpPut = new HttpPut(url);
			httpPut.setEntity(new StringEntity(new Date().getTime()+""));
			CloseableHttpResponse response = HttpClients.createDefault().execute(httpPut);
			int statusCode = response.getStatusLine().getStatusCode();

			if (statusCode == 200) {
				String responseValue = EntityUtils.toString(response.getEntity());
				LOGGER.info("Response obtained from consul for accquiring {} is {}", key, responseValue);
				return Boolean.parseBoolean(responseValue);
			}

			else {
				LOGGER.error("Non 200 response while accquiring lock . Response code is : {}", statusCode);
				return false;
			}
		}
		catch (Exception e) {
			LOGGER.error("Error in accquiring lock from consul", e);
			return false;
		}

	}

	public boolean releaseLock(String key) {
		boolean success = false;
		LOGGER.info("Key to be released : {}",key ); 
		String sessionId=sessionIdKeyMap.get(key);
		if (StringUtils.isEmpty(sessionId)) {
			LOGGER.error("No session Id is present. No need to attempt release of lock");
		}

		else {
			if (isLeader) {
				if (releaseLockFromConsul(key)) {
					success = true;
					LOGGER.info("Lock successfully released");
				} else {
					LOGGER.error("Attempt to release lock was unsuccessful");
				}
			} else {
				LOGGER.info("Instance is not leader. Not attempting release of lock");
			}

		}
		return success;
	}

	private boolean releaseLockFromConsul(String key) {
		try {
			String url = getReleaseLockUrl(key);

			LOGGER.info("Attempting to release lock . URL : {}", url);
			HttpPut httpPut = new HttpPut(url);
			CloseableHttpResponse response = HttpClients.createDefault().execute(httpPut);
			int statusCode = response.getStatusLine().getStatusCode();

			if (statusCode == 200) {
				String responseValue = EntityUtils.toString(response.getEntity());
				LOGGER.info("Response obtained from consul for releasing {} is {}",key,
						responseValue);
				return Boolean.parseBoolean(responseValue);
			}

			else {
				LOGGER.error("Non 200 response while releasing lock . Response code is : {}", statusCode);
				return false;
			}
		}
		catch (Exception e) {
			LOGGER.error("Error in accquiring lock from consul", e);
			return false;
		}
	}

	private String getLockStatusUrl(String key) throws MalformedURLException, URISyntaxException {
		URIBuilder builder = getURIBuilder();
		String path = String.format(BaseConstant.LOCK_ACQUISTION_URL, gdsProducerConfiguration.getConsulEnvironment(),gdsProducerConfiguration.getConsulProductName(), key);
		builder.setPath(path);
		return builder.build().toURL().toString();
	}

	private String getReleaseLockUrl(String key) throws MalformedURLException, URISyntaxException {
		URIBuilder builder = getURIBuilder();
		String path = String.format(BaseConstant.LOCK_ACQUISTION_URL,gdsProducerConfiguration.getConsulEnvironment(),gdsProducerConfiguration.getConsulProductName(),key);
		builder.setPath(path);
		String sessionId=sessionIdKeyMap.get(key);
		builder.addParameter("release", sessionId);
		return builder.build().toURL().toString();
	}

	private String getAccquireLockUrl(String key) throws MalformedURLException, URISyntaxException {
		URIBuilder builder = getURIBuilder();
		String path = String.format(BaseConstant.LOCK_ACQUISTION_URL,gdsProducerConfiguration.getConsulEnvironment(),gdsProducerConfiguration.getConsulProductName(),key);
		builder.setPath(path);
		String sessionId=sessionIdKeyMap.get(key);
		builder.addParameter("acquire", sessionId);
		return builder.build().toURL().toString();
	}

	private String getSessionUrl() throws MalformedURLException, URISyntaxException {
		URIBuilder builder = getURIBuilder();
		builder.setPath(BaseConstant.SESSION_ACCQUISTION_URL);
		return builder.build().toURL().toString();
	}

	private String getDeleteSessionUrl(String key) throws MalformedURLException, URISyntaxException {
		URIBuilder uriBuilder = getURIBuilder();
		String sessionId=sessionIdKeyMap.get(key);
		String path = String.format(BaseConstant.SESSION_DELETION_URL, sessionId);
		uriBuilder.setPath(path);
		return uriBuilder.build().toURL().toString();
	}

	private URIBuilder getURIBuilder() {
		URIBuilder builder = new URIBuilder();
		builder.setScheme(BaseConstant.HTTP_TAG);
		builder.setHost(gdsProducerConfiguration.getConsulHost());
		builder.setPort(gdsProducerConfiguration.getConsulPort());
		return builder;
	}

}
