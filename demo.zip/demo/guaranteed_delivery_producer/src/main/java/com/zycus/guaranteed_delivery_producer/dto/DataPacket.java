package com.zycus.guaranteed_delivery_producer.dto;

public class DataPacket {

	GDSProducerRequest dataPacket;

	public GDSProducerRequest getDataPacket() {
		return dataPacket;
	}

	public void setDataPacket(GDSProducerRequest dataPacket) {
		this.dataPacket = dataPacket;
	}
	
}
