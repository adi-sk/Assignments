package com.zycus.guaranteed_delivery_producer.service;

import java.sql.Connection;


import com.zycus.guaranteed_delivery_producer.dto.CapturedEventData;
import com.zycus.guaranteed_delivery_producer.dto.DBConnection;
import com.zycus.guaranteed_delivery_producer.dto.EventInfo;

public interface GDSProducerCallBack {

	/**
	 * For the given EventInfo, Provides the required {@link CapturedEventData} details.
	 * @param eventInfo
	 * @return {@link CapturedEventData}
	 */
	public CapturedEventData captureEvent(EventInfo eventInfo) throws Exception;

	/**
	 * If Product has to set JDBC {@link Connection} Object.
	 * @return {@link DBConnection}
	 */
	public DBConnection getConnection() ;

	/**
	 * Used for sending notification to product.
	 * Guaranteed Delivery Producer calls this method for sending Notification to product.
	 * @param msg
	 */
	public void sendNotifcation(String msg);
}
