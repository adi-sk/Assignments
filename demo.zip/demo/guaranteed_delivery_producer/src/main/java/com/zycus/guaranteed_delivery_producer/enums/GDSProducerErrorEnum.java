package com.zycus.guaranteed_delivery_producer.enums;

/**
 * Represents possible error constant's while Processing Host Request/Event.
 * @author Narendra M
 * @version 1.0
 */
public enum GDSProducerErrorEnum {
	/**
	 * Represents Host Request's EventInfo validation Failed.
	 */
	EVENTINFO_VALIDATION_FAILED {
		@Override
		public String getValue() {
			return "NR-GDSP-C-2000";
		}
		@Override
		public String getText() {
			return "Unable to save EventInfo, Due to EventInfo(EventId,EntityId and TenantId) validation";
		}
	},
	/**
	 * saving of EventInfo Failed
	 */
	EVENTINFO_PERSIST_FAILED {
		@Override
		public String getValue() {
			return "NR-GDSP-S-2001";
		}
		@Override
		public String getText() {
			return "Unable to save EventInfo, Due to Connection or SessionFactory Problem,Please Check logs";
		}
	},
	/**
	 * Unable get Data from DB
	 */
	FETCH_OPERATION_FAILED {
		@Override
		public String getValue() {
			return "RE-GDSP-S-2002";
		}
		@Override
		public String getText() {
			return "Unable to Get Data, Due to Connection or SessionFactory Problem,Please Check logs";
		}
	},
	/**
	 * Update operation Failed
	 */
	UPDATE_OPERATION_FAILED {
		@Override
		public String getValue() {
			return "RE-GDSP-S-2003";
		}
		@Override
		public String getText() {
			return "Unable to Update Data, Due to Connection or SessionFactory Problem,Please Check logs";
		}
	},
	
	/**
	 * Converting CapturedEventData to String Failed
	 */
	CONVERTING_CAPTUREDEVENTDATA_TO_STRING_FAILED {
		@Override
		public String getValue() {
			return "RE-GDSP-S-2004";
		}
		@Override
		public String getText() {
			return "Unable to Convert CapturedEventData To String Using ObjectMapper Class(due to CapturedEventData is Null or JsonProcessingException)";
		}
	},
	
	/**
	 * Sent Data Successfully to CGDS But failed to change status of event.
	 */
	REST_SUCCESS_BUT_FAILED {
		@Override
		public String getValue() {
			return "RE-GDSP-S-2005";
		}
		@Override
		public String getText() {
			return "Unable to update Status to Success While Sending to CGDS ,Due to this Duplicate can be sent to CGDS";
		}
	},
	GDS_PRODUCER_CONFIGURATION_FAILED {
		@Override
		public String getValue() {
			return "RE-GDSP-S-2006";
		}
		@Override
		public String getText() {
			return "Please set all Mandatory properties for GDSProducerConfiguration class";
		}
	},
	GDS_PRODUCER_CAPTUREVENT_CANNOT_BE_NULL {
		@Override
		public String getValue() {
			return "RE-GDSP-S-2007";
		}
		@Override
		public String getText() {
			return "CapturedEventData cannot be null";
		}
	},
	GDS_ZSN_URL_NOT_SET_PROPERLY_IN_EXTRAINFO {
		@Override
		public String getValue() {
			return "RE-GDSP-S-2008";
		}
		@Override
		public String getText() {
			return "ZSN - Central GDS URL not set in extrainfo(URL : BASEURL)";
		}
	},
	;	
	
	public abstract String getText();
	public abstract String getValue();
	
}
