package com.zycus.guaranteed_delivery_producer.schedulerjob;

import java.util.Date;
import java.util.TreeSet;
import java.util.concurrent.Callable;

import javax.ws.rs.core.Response;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.zycus.guaranteed_delivery_producer.configuration.GDSProducerConfiguration;
import com.zycus.guaranteed_delivery_producer.constant.BaseConstant;
import com.zycus.guaranteed_delivery_producer.constant.GDSProducerStatus;
import com.zycus.guaranteed_delivery_producer.constant.GDSRestResponseConstant;
import com.zycus.guaranteed_delivery_producer.constant.ProducerExecutionAt;
import com.zycus.guaranteed_delivery_producer.dto.Acknowledge;
import com.zycus.guaranteed_delivery_producer.dto.DBConnection;
import com.zycus.guaranteed_delivery_producer.dto.EventInfo;
import com.zycus.guaranteed_delivery_producer.dto.GDSProducerRequest;
import com.zycus.guaranteed_delivery_producer.enums.GDSProducerErrorEnum;
import com.zycus.guaranteed_delivery_producer.exception.GDSProducerException;
import com.zycus.guaranteed_delivery_producer.restclient.GDSCRestEndPoint;
import com.zycus.guaranteed_delivery_producer.service.GDSProducerCallBack;
import com.zycus.guaranteed_delivery_producer.service.GDSProducerService;
import com.zycus.guaranteed_delivery_producer.util.ClusterLeader;
import com.zycus.guaranteed_delivery_producer.util.ObjectConversion;

public class SendToCGDSJob implements Callable<String>
{

	private static final Logger LOG = LoggerFactory.getLogger(CaptureEventJob.class);

	private TreeSet<GDSProducerRequest> gdsProducerRequests;
	private GDSProducerService          gdsProducerService;
	private GDSProducerCallBack         gdsProducerCallBack;
	private ClusterLeader               clusterLeader;
	private String                      keyOrder;
	private GDSProducerConfiguration    gdsProducerConfiguration;
	private DBConnection                dbConnection;

	public SendToCGDSJob(TreeSet<GDSProducerRequest> gdsProducerRequests, GDSProducerService gdsProducerService,
			GDSProducerCallBack gdsProducerCallBack, ClusterLeader clusterLeader, String keyOrder,
			GDSProducerConfiguration gdsProducerConfiguration, DBConnection dbConnection)
	{
		super();
		this.gdsProducerRequests = gdsProducerRequests;
		this.gdsProducerService = gdsProducerService;
		this.gdsProducerCallBack = gdsProducerCallBack;
		this.clusterLeader = clusterLeader;
		this.keyOrder = keyOrder;
		this.gdsProducerConfiguration = gdsProducerConfiguration;
		this.dbConnection = dbConnection;
	}

	@Override
	public String call() throws Exception
	{
		if (acquireLock(keyOrder))
		{
			for (GDSProducerRequest gdsProducerRequest : gdsProducerRequests)
			{
				String eventId = gdsProducerRequest.getCapturedEventData().getEventInfo().getEventId();
				LOG.info("Sending Producer Event with Event Id - " + eventId + " to CGDS");
				try
				{
					if (gdsProducerService
							.getStatusOfAnEvent(gdsProducerRequest.getId(), ProducerExecutionAt.SENDING_TO_CGDS,
									GDSProducerStatus.GDSPRODUCER_SUCCESS, dbConnection))
					{

						gdsProducerService.updateExecutionAtWithStatus(gdsProducerRequest.getId(),
								ProducerExecutionAt.SENDING_TO_CGDS, GDSProducerStatus.GDSPRODUCER_PROCESSING,
								dbConnection);
						String endPoint = getCentralGDSURL(gdsProducerRequest);
						Response response = GDSCRestEndPoint.updateCapturedEventData(gdsProducerRequest, endPoint);
						if (response.getStatus() == GDSRestResponseConstant.SUCCESS)
						{
							updateSuccess(dbConnection, gdsProducerRequest, response);
							LOG.info("Sent Producer Event with Event Id - " + eventId + " to CGDS Successfully");
						}
						else
						{
							LOG.info("Failed to Send Producer Event with Event Id - " + eventId + " to CGDS!!!");
							updateFailure(dbConnection, gdsProducerRequest, response);
							break;
						}
					}
				}
				catch (GDSProducerException e)
				{
					try
					{
						LOG.info("Failed to Send Producer Event with Event Id - " + eventId + " to CGDS!!!");
						LOG.error("Unable to Send Producer Event with Event Id - " + eventId + " to CGDS Due to {}", e);
						gdsProducerService
								.updateStatus(gdsProducerRequest.getId(), GDSProducerStatus.GDSPRODUCER_FAILED,
										dbConnection);
						break;
					}
					catch (Exception e1)
					{
						LOG.error("Unable to updateStatus() for Event(EventId - " + eventId + ") Due to {}", e1);
						gdsProducerCallBack.sendNotifcation(
								"Unable to updateStatus() for Event(EventId - " + eventId + ") Due to {} " + e1);
						break;
					}
				}
			}
			releaseAndDeleteLock(keyOrder);
			return keyOrder + BaseConstant.LOCK_ACQ_SUCCESS_MSG;
		}
		else
		{
			releaseLockOnTimeExceed(keyOrder);
			return keyOrder + BaseConstant.LOCK_ACQ_FAILED_MSG;
		}
	}

	private String getCentralGDSURL(GDSProducerRequest gdsProducerRequest) throws GDSProducerException
	{
		String endPoint = null;
		if (gdsProducerConfiguration.getProductCode().toUpperCase().contains("ZSN"))
		{
			EventInfo eventInfo = gdsProducerRequest.getCapturedEventData().getEventInfo();
			String URL = eventInfo.getExtraInfo();
			if (URL != null)
			{
				String URLkey = URL.substring(0, URL.indexOf(":")).trim();
				String httpUrl = URL.substring(URL.indexOf(":") + 1, URL.length()).trim();
				if ("URL".equalsIgnoreCase(URLkey) && !checkIfNullNEmpty(httpUrl))
				{
					endPoint = httpUrl;
				}
				else
				{
					throw new GDSProducerException(
							GDSProducerErrorEnum.GDS_ZSN_URL_NOT_SET_PROPERLY_IN_EXTRAINFO.getText() + " " + URL,
							GDSProducerErrorEnum.GDS_ZSN_URL_NOT_SET_PROPERLY_IN_EXTRAINFO.getValue());
				}
			}
			else
			{
				throw new GDSProducerException(
						GDSProducerErrorEnum.GDS_ZSN_URL_NOT_SET_PROPERLY_IN_EXTRAINFO.getText() + " " + URL,
						GDSProducerErrorEnum.GDS_ZSN_URL_NOT_SET_PROPERLY_IN_EXTRAINFO.getValue());
			}
		}
		else
		{
			endPoint = gdsProducerConfiguration.getGdsEndpoint();
		}
		return endPoint;
	}

	private void releaseLockOnTimeExceed(String key)
	{
		String value = clusterLeader.getValueForKey(key);
		if (value != null)
		{
			long time = Long.parseLong(value);
			Date date = new Date(time);
			Date date1 = new Date();
			long diff = date1.getTime() - date.getTime();
			long diffHours = diff / (60 * 60 * 1000);
			long diffMinutes = diff / (60 * 1000) % 60 + diffHours * 60;
			if (diffMinutes > BaseConstant.CONSUL_LOCK_EXPIRE_TIME)
			{
				LOG.info("Lock has been released after " + BaseConstant.CONSUL_LOCK_EXPIRE_TIME + " min for key - "
						+ key);
				releaseAndDeleteLock(key);
			}
		}
	}

	private void releaseAndDeleteLock(String key)
	{
		clusterLeader.releaseLock(key);
		clusterLeader.removeKey(key);
		//new GDSConsul().deletePropertyFromConsul(keyValueClient, key, gdsProducerConfiguration.getConsulEnvironment(), gdsProducerConfiguration.getConsulProductName());
	}

	private boolean acquireLock(String keyOrder)
	{
		return clusterLeader.accquireLeadership(keyOrder);
	}

	private boolean checkIfNullNEmpty(String str)
	{
		return (str == null || str.isEmpty()) ? true : false;
	}

	private void updateSuccess(DBConnection dbConnection, GDSProducerRequest gdsProducerRequest, Response response)
			throws GDSProducerException
	{
		long gdsProducerDataId = gdsProducerRequest.getId();
		String eventId = gdsProducerRequest.getCapturedEventData().getEventInfo().getEventId();
		try
		{
			Acknowledge ack = ObjectConversion.convertCGDSResposeToAck((String) response.getEntity());
			gdsProducerService.updateGDSCId(eventId, ack.getAcknowledge().getGdscId(), dbConnection);
			gdsProducerService.updateStatus(gdsProducerDataId, GDSProducerStatus.GDSPRODUCER_SUCCESS, dbConnection);
			gdsProducerService.updateErrorCodeAndDescription(gdsProducerDataId, "", "", dbConnection);
		}
		catch (GDSProducerException e)
		{
			LOG.error("Unable to save success {}", e);
			try
			{
				gdsProducerService.updateStatus(gdsProducerDataId, GDSProducerStatus.GDSPRODUCER_SUCCESS, dbConnection);
			}
			catch (GDSProducerException e3)
			{
				//GDSCID is not UPDATED
				LOG.error("Unable to Update Status SUCCESS for " + ProducerExecutionAt.SENDING_TO_CGDS + " for EventId "
						+ eventId + ",Due to {}", e3);
				gdsProducerCallBack.sendNotifcation(
						"Unable to Update Status success for " + ProducerExecutionAt.SENDING_TO_CGDS + " for EventId "
								+ eventId + ",Due to {} " + e3);
			}
		}
		catch (Exception e)
		{
			LOG.error("Unable to save success {}", e);
			//GDSCID is not UPDATED
			gdsProducerCallBack.sendNotifcation("Unable to getAllEventPendingToDeliverToGDSC() Due to {} " + e);
			gdsProducerService.updateErrorCodeAndDescription(gdsProducerRequest.getId(), response.getStatus() + "",
					response.getEntity().toString(), dbConnection);
			gdsProducerService
					.updateStatus(gdsProducerRequest.getId(), GDSProducerStatus.GDSPRODUCER_SUCCESS, dbConnection);
		}
	}

	private void updateFailure(DBConnection dbConnection, GDSProducerRequest gdsProducerRequest, Response response)
			throws GDSProducerException
	{
		long gdsProducerDataId = gdsProducerRequest.getId();
		try
		{
			if (response.getStatus() == GDSRestResponseConstant.URL_NOT_FOUND)
			{
				LOG.error("Failed due to {}", (String) response.getEntity());
				gdsProducerService.updateErrorCodeAndDescription(gdsProducerDataId, response.getStatus() + "",
						response.getEntity().toString(), dbConnection);
				gdsProducerService.updateStatus(gdsProducerDataId, GDSProducerStatus.GDSPRODUCER_FAILED, dbConnection);
				gdsProducerCallBack.sendNotifcation("Failed due to {} " + response.getEntity());
			}
			else if (response.getStatus() == GDSRestResponseConstant.SEND_CONNECTION_TIMEOUT)
			{
				LOG.error("Failed due to {}", (String) response.getEntity());
				gdsProducerService.updateErrorCodeAndDescription(gdsProducerDataId, response.getStatus() + "",
						response.getEntity().toString(), dbConnection);
				gdsProducerService.updateStatus(gdsProducerDataId, GDSProducerStatus.GDSPRODUCER_FAILED, dbConnection);
				gdsProducerCallBack.sendNotifcation("Failed due to {} " + response.getEntity());
			}
			else if (response.getStatus() == GDSRestResponseConstant.OTHER_EXCEPTION)
			{
				LOG.error("Failed due to {}", (String) response.getEntity());
				gdsProducerService.updateErrorCodeAndDescription(gdsProducerDataId, response.getStatus() + "",
						response.getEntity().toString(), dbConnection);
				gdsProducerService.updateStatus(gdsProducerDataId, GDSProducerStatus.GDSPRODUCER_FAILED, dbConnection);
				gdsProducerCallBack.sendNotifcation("Failed due to {} " + response.getEntity());
			}
			else
			{
				Acknowledge ack = ObjectConversion.convertCGDSResposeToAck((String) response.getEntity());
				gdsProducerService.updateErrorCodeAndDescription(gdsProducerDataId, response.getStatus() + "",
						ack.getAcknowledge().getStackTrace(), dbConnection);
				gdsProducerService.updateStatus(gdsProducerDataId, GDSProducerStatus.GDSPRODUCER_FAILED, dbConnection);
				gdsProducerCallBack.sendNotifcation("Failed due to {} " + response.getEntity());
			}
		}
		catch (Exception e)
		{
			LOG.error("Failed due to {}", e);
			gdsProducerService.updateErrorCodeAndDescription(gdsProducerDataId, response.getStatus() + "",
					response.getEntity().toString(), dbConnection);
			gdsProducerService.updateStatus(gdsProducerDataId, GDSProducerStatus.GDSPRODUCER_FAILED, dbConnection);
			gdsProducerCallBack.sendNotifcation("Failed due to {} " + e);
		}
	}
}
