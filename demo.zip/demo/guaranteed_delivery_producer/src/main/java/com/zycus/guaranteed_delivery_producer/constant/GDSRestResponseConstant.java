package com.zycus.guaranteed_delivery_producer.constant;

public interface GDSRestResponseConstant {

	/**
	 * Represents Rest Success Code
	 */
	int SUCCESS=200;
	
	/**
	 * Represents Rest Url not found
	 */
	int URL_NOT_FOUND=404;
	
	/**
	 * Represents Rest Url Connection Timeout
	 */
	int SEND_CONNECTION_TIMEOUT=408;
	
	/**
	 * Represents GDSRequest model Object conversion to String has Failed
	 */
	int OTHER_EXCEPTION=499;
	
}
