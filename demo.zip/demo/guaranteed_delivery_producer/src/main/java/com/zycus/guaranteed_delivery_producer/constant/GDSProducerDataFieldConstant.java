package com.zycus.guaranteed_delivery_producer.constant;

import com.zycus.guaranteed_delivery_producer.model.GDSProducerData;

/**
 * Respective field's of {@link GDSProducerData} in Data Base
 * @author narendra.m
 *
 */
public interface GDSProducerDataFieldConstant {

	String EVENT_ID = "EVENT_ID";
	String  ENTITY_ID = "ENTITY_ID";
	String ENTITY_TYPE = "ENTITY_TYPE";
	String EVENT_TYPE = "EVENT_TYPE";
	String VERSION = "VERSION";
	String EXTRA_INFO = "EXTRA_INFO";
	String TENANT_ID = "TENANT_ID";
	String BUSSINESS_REF_ID = "BUSSINESS_REF_ID";
	String TIMESTAMP = "TIMESTAMP";
	String DATA = "DATA";
	String GDSCID = "GDSCID";
	String STATUS = "STATUS";
	String EXECUTION_AT = "EXECUTION_AT";
	String DELIVERY_STATUS = "DELIVERY_STATUS";
	String ERROR_CODE = "ERROR_CODE";
	String ERROR_DESCRIPTION = "ERROR_DESCRIPTION";
	String ID = "ID";
	String METADATA_VERSION= "METADATA_VERSION";
}
