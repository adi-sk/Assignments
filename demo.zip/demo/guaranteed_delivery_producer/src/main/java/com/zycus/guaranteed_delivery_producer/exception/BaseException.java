package com.zycus.guaranteed_delivery_producer.exception;

public class BaseException extends Exception
{
	 private static final long serialVersionUID = -2771763021762347461L;
	    private String errorMessage;
	    private String errorCode;

    public BaseException(String errorMessage, String errorCode)
    {
        super(errorMessage);
        this.errorMessage = errorMessage;
        this.errorCode = errorCode;
    }

    public BaseException()
    {
    }

    public BaseException(String message)
    {
        super(message);
    }

    public BaseException(Throwable t)
    {
        super(t);
    }

    public String getErrorMessage()
    {
        return errorMessage;
    }

    public String getErrorCode()
    {
        return errorCode;
    }

    public String toString()
    {
        String s = getClass().getName();
        String message = getLocalizedMessage();
        return message == null ? s : (new StringBuilder()).append(s).append(" Code:").append(getErrorCode()).append(" : ").append(message).toString();
    }

}
