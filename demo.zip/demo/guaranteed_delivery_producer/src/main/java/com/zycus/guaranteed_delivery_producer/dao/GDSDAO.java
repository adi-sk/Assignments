package com.zycus.guaranteed_delivery_producer.dao;

import java.util.List;

import com.zycus.guaranteed_delivery_producer.dto.CapturedEventData;
import com.zycus.guaranteed_delivery_producer.dto.DBConnection;
import com.zycus.guaranteed_delivery_producer.dto.EventInfo;
import com.zycus.guaranteed_delivery_producer.exception.GDSProducerException;
import com.zycus.guaranteed_delivery_producer.model.GDSProducerData;

public interface GDSDAO extends GDSProducerDataDAO{

	/**
	 * Saves the product Events on DBConnection Object Information
	 * @param eventInfo
	 * @param dbConnection
	 * @return
	 * @throws GDSProducerException
	 */
	public boolean saveProducerEvent(EventInfo eventInfo , DBConnection dbConnection) throws GDSProducerException;
	
	/**
	 * Gets All Events that need to get CapturedEventData
	 * @param dbConnection
	 * @return
	 * @throws GDSProducerException
	 */
	public List<EventInfo> getAllPendingEventToCapture(DBConnection dbConnection) throws GDSProducerException;
	
	/**
	 * Update's CapturedEventData.
	 * @param capturedEventData
	 * @param dbConnection
	 * @return
	 * @throws GDSProducerException
	 */
	public boolean updateCapturedEventData(CapturedEventData capturedEventData,DBConnection dbConnection) throws GDSProducerException;
	
	/**
	 * Update's GDSCID which comes from central GDS 
	 * @param eventId
	 * @param gdscId
	 * @param dbConnection
	 * @return
	 * @throws GDSProducerException
	 */
	public boolean updateGDSCId(String eventId, String gdscId,DBConnection dbConnection) throws GDSProducerException;
	
	/**
	 * Get all Events that need to sent to Central guaranteed Delivery System.
	 * @param dbConnection
	 * @return
	 * @throws GDSProducerException
	 */
	public List<GDSProducerData> getAllEventPendingToDeliverToGDSC(DBConnection dbConnection) throws GDSProducerException;

	/**
	 * Update's ExecutionAt of the Event.
	 * @param reqId
	 * @param executionAt
	 * @param dbConnection
	 * @return
	 * @throws GDSProducerException
	 */
	public boolean updateExecutionAt(Long reqId, String executionAt, DBConnection dbConnection) throws GDSProducerException;

	/**
	 * Update's status of the Event.
	 * @param reqId
	 * @param status
	 * @param dbConnection
	 * @return
	 * @throws GDSProducerException
	 */
	public boolean updateStatus(Long reqId, String status, DBConnection dbConnection) throws GDSProducerException;

	/**
	 * Update's errorCode and errorDescription of the Event.
	 * @param reqId
	 * @param errorCode
	 * @param errorDescription
	 * @param dbConnection
	 * @return
	 * @throws GDSProducerException
	 */
	public boolean updateErrorCodeAndDescription(Long reqId, String errorCode, String errorDescription,DBConnection dbConnection)throws GDSProducerException;

	/**
	 * Update's ExecutionAt And status of event at the same time.
	 * @param reqId
	 * @param executionAt
	 * @param status
	 * @param dbConnection
	 * @return
	 * @throws GDSProducerException
	 */
	public boolean updateExecutionAtWithStatus(Long reqId, String executionAt, String status, DBConnection dbConnection) throws GDSProducerException;
	
	public boolean getStatusOfAnEvent(Long reqId, String executionAt, String status, DBConnection dbConnection) throws GDSProducerException;

}
