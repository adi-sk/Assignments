package com.zycus.guaranteed_delivery_producer.dto;

import java.util.List;

public class CapturedEventData {

	private EventInfo eventInfo;
	
	private List<GDSMessage> messageSet;

	public EventInfo getEventInfo() {
		return eventInfo;
	}

	public void setEventInfo(EventInfo eventInfo) {
		this.eventInfo = eventInfo;
	}

	public List<GDSMessage> getMessageSet() {
		return messageSet;
	}

	public void setMessageSet(List<GDSMessage> messageSet) {
		this.messageSet = messageSet;
	}
	
}
