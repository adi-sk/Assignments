package com.zycus.guaranteed_delivery_consumer.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

import javax.transaction.Transactional;

import org.junit.Assert;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.context.SpringBootTest.WebEnvironment;
import org.springframework.test.context.junit4.SpringRunner;

import com.zycus.guaranteed_delivery_consumer.Exception.GDSConsumerException;
import com.zycus.guaranteed_delivery_consumer.dto.DBConnection;
import com.zycus.guaranteed_delivery_consumer.enums.DBConnectionErrorEnum;

@RunWith(SpringRunner.class)
@SpringBootTest(webEnvironment = WebEnvironment.RANDOM_PORT)
@Transactional
public class DBConnectionValidatorTest {

	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
		System.setProperty("env", "INTEGRATION_BANGALORE");
		System.setProperty("productName", "PRODUCT_1");
		System.setProperty("configSourceHost", "10.10.10.153");
		System.setProperty("gdsProductName", "GUARANTEED-DELIVERY");
	}

	@Test
	public void TestValidateDBConnection(){
		try {
			DBConnectionValidator.validateDBConnection(null);
		} catch (GDSConsumerException e) {
			Assert.assertEquals(DBConnectionErrorEnum.DBCONNECTION_NULL.getText(), e.getErrorMessage());
			Assert.assertEquals(DBConnectionErrorEnum.DBCONNECTION_NULL.getValue(), e.getErrorCode());
		}
	}

	@Test
	public void TestValidateDBConnectionWithJDBC() throws GDSConsumerException, ClassNotFoundException, SQLException {
		DBConnectionValidator.validateDBConnection(getJDBCDBConnectionObject());
	}

	@Test
	public void TestValidateDBConnectionWithJDBCError() {
		try {
			DBConnectionValidator.validateDBConnection(getJDBCErrorDBConnectionObject());
		} catch (GDSConsumerException e) {
			Assert.assertEquals(DBConnectionErrorEnum.DBCONNECTION_HIBERNATE_FALSE_CONNECTION_NULL.getText(), e.getErrorMessage());
			Assert.assertEquals(DBConnectionErrorEnum.DBCONNECTION_HIBERNATE_FALSE_CONNECTION_NULL.getValue(), e.getErrorCode());
		}
	}


	private DBConnection getJDBCDBConnectionObject() throws ClassNotFoundException, SQLException {
		DBConnection dbConnection=new DBConnection();
			Class.forName("oracle.jdbc.driver.OracleDriver");
			Connection connection=DriverManager.getConnection("jdbc:oracle:thin:@192.168.2.197:1521:ORCL","GDS","GDS");  
			dbConnection.setConnection(connection);
			return dbConnection;
	
	}
	private DBConnection getJDBCErrorDBConnectionObject() {
		DBConnection dbConnection=new DBConnection();
		dbConnection.setConnection(null);
		return dbConnection;
	}
}
