package com.zycus.guaranteed_delivery_consumer.service;

import java.sql.Connection;
import java.sql.DriverManager;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.zycus.guaranteed_delivery_consumer.dto.CallBackResponse;
import com.zycus.guaranteed_delivery_consumer.dto.DBConnection;
import com.zycus.guaranteed_delivery_consumer.enums.CallBackEnum;
import com.zycus.guaranteed_delivery_consumer.model.ConsumerProductDataDispatchModel;

@Service
public class ConsumerProductCallBackImpl implements ConsumerProductCallBack {

	private static final Logger LOG = LoggerFactory.getLogger(ConsumerProductCallBackImpl.class);
	
	@Override
	public CallBackResponse OnMessage(ConsumerProductDataDispatchModel data) {
		LOG.info("Received Event for Id - "+data.getGdscConsumerId());
		
		return new CallBackResponse(CallBackEnum.SUCCESS, "json String");
	}

	@Override
	public DBConnection getConnection() {
		DBConnection dbConnection=new DBConnection();
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			Connection connection=DriverManager.getConnection("jdbc:oracle:thin:@192.168.2.197:1521:ORCL","GDS","GDS");  
			dbConnection.setConnection(connection);
			return dbConnection;
		} catch (Exception e) {
			LOG.error("Unable to create Connection Object Due to {} ",e);
		}  
		return null;
	}

	@Override
	public void sendNotifcation(String msg) {
		LOG.info("Message "+msg);
	}

}
