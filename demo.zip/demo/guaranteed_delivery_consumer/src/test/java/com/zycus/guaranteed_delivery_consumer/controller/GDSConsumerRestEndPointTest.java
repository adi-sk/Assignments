package com.zycus.guaranteed_delivery_consumer.controller;

import java.util.Date;

import javax.transaction.Transactional;

import org.junit.Assert;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.context.SpringBootTest.WebEnvironment;
import org.springframework.http.MediaType;
import org.springframework.mock.web.MockHttpServletResponse;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.request.MockHttpServletRequestBuilder;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultHandlers;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;
import org.springframework.test.web.servlet.setup.DefaultMockMvcBuilder;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.zycus.guaranteed_delivery_consumer.App;
import com.zycus.guaranteed_delivery_consumer.dto.GDSCConsumerRequest;
import com.zycus.guaranteed_delivery_consumer.dto.GDSConsumerFailedResponse;
import com.zycus.guaranteed_delivery_consumer.dto.GDSConsumerSuccessResponse;
import com.zycus.guaranteed_delivery_consumer.enums.GDSConsumerErrorEnum;
import com.zycus.guaranteed_delivery_consumer.service.DatabaseConfiguration;

import uk.co.jemos.podam.api.PodamFactory;
import uk.co.jemos.podam.api.PodamFactoryImpl; 

@RunWith(SpringRunner.class)
@SpringBootTest(webEnvironment = WebEnvironment.RANDOM_PORT,classes = {App.class, DatabaseConfiguration.class})
@Transactional
public class GDSConsumerRestEndPointTest {

	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
		System.setProperty("env", "INTEGRATION_BANGALORE");
		System.setProperty("productName", "PRODUCT_1");
		System.setProperty("configSourceHost", "10.10.10.153");
		System.setProperty("gdsProductName", "GUARANTEED-DELIVERY");
	}
	@Before
	public void setup() {
		DefaultMockMvcBuilder builder = MockMvcBuilders.webAppContextSetup(this.wac);
		this.mockMvc = builder.build(); 
	}

	@Autowired
	private WebApplicationContext wac; 
	
	private MockMvc mockMvc; 

	
	@Test
	public void testUpdateCapturedEventDataSuccessResponseRest() throws Exception {
		PodamFactory podam=new PodamFactoryImpl();
		GDSCConsumerRequest gdscConsumerRequest=podam.manufacturePojo(GDSCConsumerRequest.class);
		gdscConsumerRequest.setTimeStamp(new Date());
		gdscConsumerRequest.getEventInfo().setTimeStamp(new Date());
		
		ObjectMapper mapper=new ObjectMapper();	
	    String requestBody = mapper.writeValueAsString(gdscConsumerRequest);
	    System.out.println(requestBody);
	    MockHttpServletRequestBuilder builder = MockMvcRequestBuilders
	            .post("/gds/postConsumerData")
	            .accept(MediaType.APPLICATION_JSON)
	            .content(requestBody)
	            .contentType(MediaType.APPLICATION_JSON);
	   
	    this.mockMvc.perform(builder).andExpect(MockMvcResultMatchers.status().isOk())
		.andDo(MockMvcResultHandlers.print());
	    
	    MvcResult res = this.mockMvc.perform(builder).andReturn();
	    MockHttpServletResponse response= res.getResponse();
	    String responseString = response.getContentAsString();
	    GDSConsumerSuccessResponse gdsConsumerSuccessResponse = mapper.readValue(responseString, GDSConsumerSuccessResponse.class);
	    Assert.assertNotNull(gdsConsumerSuccessResponse.getGdsConsumerId());
	    Assert.assertNotNull(gdsConsumerSuccessResponse.getTimeStamp());
	   
	}
	@Test
	public void testUpdateCapturedEventDataFailiureResponseRest() throws Exception {
		PodamFactory podam=new PodamFactoryImpl();
		GDSCConsumerRequest gdscConsumerRequest=podam.manufacturePojo(GDSCConsumerRequest.class);
		gdscConsumerRequest.setTimeStamp(new Date());
		gdscConsumerRequest.setEventInfo(null);
		
		ObjectMapper mapper=new ObjectMapper();	
		String requestBody = mapper.writeValueAsString(gdscConsumerRequest);
		
		MockHttpServletRequestBuilder builder = MockMvcRequestBuilders
				.post("/gds/postConsumerData")
				.accept(MediaType.APPLICATION_JSON)
				.content(requestBody)
				.contentType(MediaType.APPLICATION_JSON);
		
		this.mockMvc.perform(builder).andExpect(MockMvcResultMatchers.status().isInternalServerError())
		.andDo(MockMvcResultHandlers.print());
		
		MvcResult res = this.mockMvc.perform(builder).andReturn();
		MockHttpServletResponse response= res.getResponse();
		String responseString = response.getContentAsString();
		GDSConsumerFailedResponse gdsConsumerFailedResponse = mapper.readValue(responseString, GDSConsumerFailedResponse.class);
		Assert.assertNotNull(gdsConsumerFailedResponse.getErrorCode());
		Assert.assertEquals(GDSConsumerErrorEnum.GDS_CONSUMER_VALIDATION_FAILED.getValue(), gdsConsumerFailedResponse.getErrorCode());
		
		Assert.assertNotNull(gdsConsumerFailedResponse.getExecutionAt());
		Assert.assertNotNull(gdsConsumerFailedResponse.getStackTrace());
		
	}

}
