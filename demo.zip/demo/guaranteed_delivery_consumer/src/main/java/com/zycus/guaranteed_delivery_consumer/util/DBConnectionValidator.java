package com.zycus.guaranteed_delivery_consumer.util;

import com.zycus.guaranteed_delivery_consumer.Exception.GDSConsumerException;
import com.zycus.guaranteed_delivery_consumer.dto.DBConnection;
import com.zycus.guaranteed_delivery_consumer.enums.DBConnectionErrorEnum;
/**
 * Validates DBConnection Object implemented by product in GDSProducerCallBack interface
 * @author narendra.m
 *
 */
public class DBConnectionValidator {

	public static void validateDBConnection(DBConnection dbConnection) throws GDSConsumerException {
		if(null == dbConnection) {
			throw new GDSConsumerException(DBConnectionErrorEnum.DBCONNECTION_NULL.getText(),DBConnectionErrorEnum.DBCONNECTION_NULL.getValue());
		}
		if(null == dbConnection.getConnection()) {
			throw new GDSConsumerException(DBConnectionErrorEnum.DBCONNECTION_HIBERNATE_FALSE_CONNECTION_NULL.getText(),DBConnectionErrorEnum.DBCONNECTION_HIBERNATE_FALSE_CONNECTION_NULL.getValue());
		}
	}
}
