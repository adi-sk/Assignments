package com.zycus.guaranteed_delivery_consumer.model;

public class ConsumerProductDataDispatchModel implements Comparable<ConsumerProductDataDispatchModel>{

	private long gdscConsumerId;
	
	private String sourceProductCode;
	
	private String messageToDispatch;
	
	private String eventId;
	
	private String entityId;
	
	private String entityType;
	
	private String eventType;
	
	private String version;
	
	private String tenantId;
	
	private String bussinesRefId;

	private String messageType;

	private String consumerProductCode;
	
	private String gdscId;
	
	private String extraInfo;

	private long gdsProducerId;

	private String metadataVersion;

	public long getGdscConsumerId() {
		return gdscConsumerId;
	}

	public void setGdscConsumerId(long gdscConsumerId) {
		this.gdscConsumerId = gdscConsumerId;
	}

	public String getSourceProductCode() {
		return sourceProductCode;
	}

	public void setSourceProductCode(String sourceProductCode) {
		this.sourceProductCode = sourceProductCode;
	}

	public String getMessageToDispatch() {
		return messageToDispatch;
	}

	public void setMessageToDispatch(String messageToDispatch) {
		this.messageToDispatch = messageToDispatch;
	}

	public String getEventId() {
		return eventId;
	}

	public void setEventId(String eventId) {
		this.eventId = eventId;
	}

	public String getEntityId() {
		return entityId;
	}

	public void setEntityId(String entityId) {
		this.entityId = entityId;
	}

	public String getEntityType() {
		return entityType;
	}

	public void setEntityType(String entityType) {
		this.entityType = entityType;
	}

	public String getEventType() {
		return eventType;
	}

	public void setEventType(String eventType) {
		this.eventType = eventType;
	}

	public String getVersion() {
		return version;
	}

	public void setVersion(String version) {
		this.version = version;
	}

	public String getTenantId() {
		return tenantId;
	}

	public void setTenantId(String tenantId) {
		this.tenantId = tenantId;
	}

	public String getBussinesRefId() {
		return bussinesRefId;
	}

	public void setBussinesRefId(String bussinesRefId) {
		this.bussinesRefId = bussinesRefId;
	}

	public String getMessageType() {
		return messageType;
	}

	public void setMessageType(String messageType) {
		this.messageType = messageType;
	}

	@Override
	public int compareTo(ConsumerProductDataDispatchModel consumerProductDataDispatchModel) {
		return ((Long)this.gdscConsumerId).compareTo((Long)consumerProductDataDispatchModel.getGdscConsumerId());
	}

	public String getConsumerProductCode() {
		return consumerProductCode;
	}

	public void setConsumerProductCode(String consumerProductCode) {
		this.consumerProductCode = consumerProductCode;
	}

	public String getGdscId() {
		return gdscId;
	}

	public void setGdscId(String gdscId) {
		this.gdscId = gdscId;
	}

	public long getGdsProducerId() {
		return gdsProducerId;
	}

	public void setGdsProducerId(long gdsProducerId) {
		this.gdsProducerId = gdsProducerId;
	}

	public String getExtraInfo() {
		return extraInfo;
	}

	public void setExtraInfo(String extraInfo) {
		this.extraInfo = extraInfo;
	}

	public String getMetadataVersion()
	{
		return metadataVersion;
	}

	public void setMetadataVersion(String metadataVersion)
	{
		this.metadataVersion = metadataVersion;
	}
}
