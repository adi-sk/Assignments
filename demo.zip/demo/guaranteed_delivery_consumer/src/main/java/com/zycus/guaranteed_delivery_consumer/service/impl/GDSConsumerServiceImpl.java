package com.zycus.guaranteed_delivery_consumer.service.impl;

import java.sql.Connection;
import java.util.Date;
import java.util.List;
import java.util.TimeZone;

import javax.ws.rs.core.Response;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.zycus.guaranteed_delivery_consumer.Exception.GDSConsumerException;
import com.zycus.guaranteed_delivery_consumer.configuration.GDSConsumerConfiguration;
import com.zycus.guaranteed_delivery_consumer.constant.ConsumerExecutionAt;
import com.zycus.guaranteed_delivery_consumer.constant.GDSConsumerRestConstant;
import com.zycus.guaranteed_delivery_consumer.constant.GDSConsumerStatus;
import com.zycus.guaranteed_delivery_consumer.constant.GDSRestResponseConstant;
import com.zycus.guaranteed_delivery_consumer.dao.GDSConsumerDAO;
import com.zycus.guaranteed_delivery_consumer.dto.CallBackResponse;
import com.zycus.guaranteed_delivery_consumer.dto.DBConnection;
import com.zycus.guaranteed_delivery_consumer.dto.GDSCConsumerRequest;
import com.zycus.guaranteed_delivery_consumer.dto.GDSConsumerSuccessResponse;
import com.zycus.guaranteed_delivery_consumer.dto.GDSPostBoxMessage;
import com.zycus.guaranteed_delivery_consumer.dto.PostBoxMessage;
import com.zycus.guaranteed_delivery_consumer.enums.GDSConsumerErrorEnum;
import com.zycus.guaranteed_delivery_consumer.model.ConsumerProductDataDispatchModel;
import com.zycus.guaranteed_delivery_consumer.restClient.GDSCRestEndPoint;
import com.zycus.guaranteed_delivery_consumer.service.ConsumerProductCallBack;
import com.zycus.guaranteed_delivery_consumer.service.GDSConsumerService;
import com.zycus.guaranteed_delivery_consumer.util.DBConnectionValidator;

@Service
public class GDSConsumerServiceImpl implements GDSConsumerService {

	private static final Logger LOG = LoggerFactory.getLogger(GDSConsumerServiceImpl.class);

	@Autowired
	private GDSConsumerDAO gdsConsumerDAO;

	@Autowired
	private ConsumerProductCallBack consumerProductCallBack;

	@Autowired
	private GDSConsumerConfiguration gdsConsumerConfiguration;

	@Override
	public GDSConsumerSuccessResponse updateCapturedEventData(GDSCConsumerRequest gdscRequest) throws GDSConsumerException {
		DBConnection dbConnection = consumerProductCallBack.getConnection();
		DBConnectionValidator.validateDBConnection(dbConnection);
		//check duplicate
		Long duplicateGdsConsumerId = checkDuplicate(gdscRequest.getDeliveryId(), gdscRequest.getGdsProducerId(), gdscRequest.getGdscId());
		if(duplicateGdsConsumerId==null) {
			Long gdsConsumerId = gdsConsumerDAO.updateCapturedEventData(gdscRequest,dbConnection);
			if(null == gdsConsumerId) {
				throw new GDSConsumerException(GDSConsumerErrorEnum.GDS_CONSUMER_ID_NULL.getText(),GDSConsumerErrorEnum.GDS_CONSUMER_ID_NULL.getValue());
			}else {
				GDSConsumerSuccessResponse gdsConsumerSuccessResponse=new GDSConsumerSuccessResponse();
				gdsConsumerSuccessResponse.setGdsConsumerId(String.valueOf(gdsConsumerId));
				gdsConsumerSuccessResponse.setDuplicate(GDSConsumerRestConstant.DUPLICATE_NO);
				TimeZone.setDefault(TimeZone.getTimeZone("UTC"));
				Date productResponseDate= new Date();
				gdsConsumerSuccessResponse.setTimeStamp(productResponseDate);
				gdsConsumerDAO.updateProductResponseDate(gdsConsumerId,dbConnection,productResponseDate);
				closeConnection(dbConnection);
				return gdsConsumerSuccessResponse;
			}
		}else {
			GDSConsumerSuccessResponse gdsConsumerSuccessResponse=new GDSConsumerSuccessResponse();
			gdsConsumerSuccessResponse.setGdsConsumerId(String.valueOf(duplicateGdsConsumerId));
			gdsConsumerSuccessResponse.setDuplicate(GDSConsumerRestConstant.DUPLICATE_YES);
			TimeZone.setDefault(TimeZone.getTimeZone("UTC"));
			Date productResponseDate= new Date();
			gdsConsumerSuccessResponse.setTimeStamp(productResponseDate);
			gdsConsumerDAO.updateProductResponseDate(duplicateGdsConsumerId,dbConnection,productResponseDate);
			closeConnection(dbConnection);
			return gdsConsumerSuccessResponse;
		}
	}
	
	private void closeConnection(DBConnection dbConnection) {
		if(dbConnection.isConnectionCloseRequired()) {
			try{
				Connection con = dbConnection.getConnection();
				con.close();
			}catch (Exception e) {
				LOG.error("Unable to close Connection due to {}", e);
			}
		}
	}
	@Override
	public boolean updateEventConsumptionSuccess(long gdsConsumerId, DBConnection dbConnection) throws GDSConsumerException {
		return gdsConsumerDAO.updateEventDispatchStatus(gdsConsumerId, dbConnection, GDSConsumerStatus.GDSCONSUMER_SUCCESS);
	}

	@Override
	public boolean updateEventConsumptionFailed(long gdsConsumerId, DBConnection dbConnection) throws GDSConsumerException {
		return gdsConsumerDAO.updateEventDispatchStatus(gdsConsumerId, dbConnection, GDSConsumerStatus.GDSCONSUMER_FAILED);
	}

	@Override
	public boolean updateEventConsumptionParked(long gdsConsumerId, DBConnection dbConnection) throws GDSConsumerException {
		return gdsConsumerDAO.updateEventDispatchStatus(gdsConsumerId, dbConnection, GDSConsumerStatus.GDSCONSUMER_PARKED);
	}

	@Override
	public List<ConsumerProductDataDispatchModel> getPendingDispath(DBConnection dbConnection) throws GDSConsumerException {
		return gdsConsumerDAO.getPendingDispath(dbConnection);
	}

	@Override
	public boolean updateConsumerEventExecutionAtDispatchAndStatusInProgressing(long gdsConsumerId,DBConnection dbConnection) throws GDSConsumerException {
		return gdsConsumerDAO.updateConsumerEventExecutionAtDispatchAndStatusInProgressing(gdsConsumerId,GDSConsumerStatus.GDSCONSUMER_PROCESSING,ConsumerExecutionAt.DISPATCH_EVENT_MESSAGE,dbConnection);
	}

	@Override
	public boolean updateErrorCodeErrorDescriptionStackTrace(long gdsConsumerId, String errorCode, String errorDescription,String stackTrace,DBConnection dbConnection) throws GDSConsumerException {
		return gdsConsumerDAO.updateErrorCodeErrorDescriptionStackTrace(gdsConsumerId,errorCode,errorDescription,stackTrace,dbConnection);
	}

	@Override
	public Long checkDuplicate(Long deliveryId, long producerId, String gdscId) throws GDSConsumerException {
		DBConnection dbConnection = consumerProductCallBack.getConnection();
		DBConnectionValidator.validateDBConnection(dbConnection);
		Long consumerId = gdsConsumerDAO.checkDuplicate(deliveryId,producerId,gdscId,dbConnection);
		closeConnection(dbConnection);
		return consumerId;
	}

	@Override
	public boolean updateProductResponse(long consumerId, CallBackResponse response,DBConnection dbConnection) throws GDSConsumerException {
		ObjectMapper mapper=new ObjectMapper();
		String responseData;
		try {
			responseData = mapper.writeValueAsString(response);
			return gdsConsumerDAO.updateProductResponse(consumerId,responseData,dbConnection);
		} catch (JsonProcessingException e) {
			throw new GDSConsumerException(GDSConsumerErrorEnum.UNABLE_TO_CONVERT_PRODUCT_RESPONSE.getText(),GDSConsumerErrorEnum.UNABLE_TO_CONVERT_PRODUCT_RESPONSE.getValue());
		}
	}

	@Override
	public boolean updateCentralGDSCallBackResponse(long consumerId, String response,DBConnection dbConnection) throws GDSConsumerException {
		return gdsConsumerDAO.updateCentralGDSCallBackResponse(consumerId,response,dbConnection);
	}

	@Override
	public void centralGDSCallBack(DBConnection dbConnection, ConsumerProductDataDispatchModel model,CallBackResponse responseData) throws GDSConsumerException {
		long gdsConsumerId = model.getGdscConsumerId();
		try {
			gdsConsumerDAO.updateConsumerEventExecutionAtDispatchAndStatusInProgressing(gdsConsumerId,GDSConsumerStatus.GDSCONSUMER_PROCESSING,ConsumerExecutionAt.PRODUCT_CALL_BACK,dbConnection);
			GDSPostBoxMessage gdsPostBoxMessage = getGDSPostBoxMessage(model, responseData);
			Response response = GDSCRestEndPoint.cgdsCallBack(gdsPostBoxMessage, gdsConsumerConfiguration.getGdsEndPoint());
			if(response.getStatus()==GDSRestResponseConstant.SUCCESS && response.getEntity()!=null) {
				updateEventConsumptionSuccess(gdsConsumerId, dbConnection);
				updateCentralGDSCallBackResponse(gdsConsumerId,response.getEntity().toString(),dbConnection);
				LOG.info("Sent Consumer call back response to CGDS for Event with Event Id - "+model.getEventId()+" Successfully");
			}else {
				LOG.info("Failed to Send Consumer call back response to CGDS for Event with Event Id - "+model.getEventId()+" to CGDS!!!");
				callBackFailedUpdateTable(dbConnection, gdsConsumerId, response);
			}
		}
		catch (GDSConsumerException e) {
			LOG.error("Unable to callBack for Consumer Id -"+gdsConsumerId+" with Event Id - "+model.getEventId()+" to CGDS, Due to {}", e);
			updateCallBackFailed(dbConnection, gdsConsumerId,e.getErrorCode(),e.getErrorMessage(), e.getErrorMessage());
		}catch (Exception e) {
			LOG.error("Unable to callBack for Consumer Id -"+gdsConsumerId+" with Event Id - "+model.getEventId()+" to CGDS, Due to {}", e);
			updateCallBackFailed(dbConnection, gdsConsumerId,GDSConsumerErrorEnum.OTHER_EXCEPTION_AT_CALLBACK.getValue(),GDSConsumerErrorEnum.OTHER_EXCEPTION_AT_CALLBACK.getText(), e.getMessage());
		}
	}

	private void callBackFailedUpdateTable(DBConnection dbConnection, long gdsConsumerId, Response response)
			throws GDSConsumerException {
		String errorCode=null;
		String errorDescription=null;
		if(response.getStatus()==GDSRestResponseConstant.SUCCESS && response.getEntity()==null) {
			errorCode = GDSConsumerErrorEnum.ACK_FROM_CGDS_NULL.getValue();
			errorDescription = GDSConsumerErrorEnum.ACK_FROM_CGDS_NULL.getText();
		}else if(response.getStatus()==500) {
			errorCode = GDSConsumerErrorEnum.INTERNAL_SERVER_ERROR.getValue();
			errorDescription = GDSConsumerErrorEnum.INTERNAL_SERVER_ERROR.getText();
		}else if(response.getStatus()==GDSRestResponseConstant.SEND_CONNECTION_TIMEOUT) {
			errorCode = GDSConsumerErrorEnum.REST_CONNECTION_TIMEOUT.getValue();
			errorDescription = GDSConsumerErrorEnum.REST_CONNECTION_TIMEOUT.getText();
		}else if(response.getStatus()==GDSRestResponseConstant.OTHER_EXCEPTION) {
			errorCode = GDSConsumerErrorEnum.REST_OTHER_EXCEPTION.getValue();
			errorDescription = GDSConsumerErrorEnum.REST_OTHER_EXCEPTION.getText();
		}
		updateEventConsumptionFailed(gdsConsumerId, dbConnection);
		updateErrorCodeErrorDescriptionStackTrace(gdsConsumerId,errorCode,errorDescription,(response.getEntity()==null?null:response.getEntity().toString()), dbConnection);
	}

	@Override
	public List<ConsumerProductDataDispatchModel> getPendingForCallBack(DBConnection dbConnection)
			throws GDSConsumerException {
		return gdsConsumerDAO.getPendingForCallBack(dbConnection);
	}
	private GDSPostBoxMessage getGDSPostBoxMessage(ConsumerProductDataDispatchModel model, CallBackResponse responseData) {
		GDSPostBoxMessage gdsPostBoxMessage=new GDSPostBoxMessage();
		gdsPostBoxMessage.setGdsSource(gdsConsumerConfiguration.getProductCode());
		gdsPostBoxMessage.setGdsDestination(model.getSourceProductCode());
		gdsPostBoxMessage.setGdsMessageType("GDS");
		gdsPostBoxMessage.setSourceId(model.getSourceProductCode());
		gdsPostBoxMessage.setDestinationId(model.getConsumerProductCode());
		PostBoxMessage message=new PostBoxMessage();
		message.setEventId(model.getEventId());
		message.setEntityId(model.getEntityId());
		message.setEventType(model.getEventType());
		message.setEntityType(model.getEntityType());
		message.setMessageType(model.getMessageType());
		message.setProductResponse(responseData.getCallBackResponse());
		message.setGdscId(model.getGdscId());
		message.setConsumerId(model.getGdscConsumerId()+"");
		message.setProducerId(model.getGdsProducerId()+"");
		message.setTenantId(model.getTenantId());
		gdsPostBoxMessage.setMessage(message);
		gdsPostBoxMessage.setErrors(responseData.getErrors());
		return gdsPostBoxMessage;
	}

	private void updateCallBackFailed(DBConnection dbConnection, long gdsConsumerId,String errorCode,String errorDescription,String stackTrace) throws GDSConsumerException {
		updateEventConsumptionFailed(gdsConsumerId, dbConnection);
		updateErrorCodeErrorDescriptionStackTrace(gdsConsumerId,errorCode,errorDescription,stackTrace, dbConnection);
	}

}
