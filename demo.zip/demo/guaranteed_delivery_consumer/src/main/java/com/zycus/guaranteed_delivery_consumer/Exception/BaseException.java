package com.zycus.guaranteed_delivery_consumer.Exception;

import com.zycus.guaranteed_delivery_consumer.enums.GDSConsumerErrorEnum;

public class BaseException extends Exception
{
	 private static final long serialVersionUID = -2771763021762347461L;
	    private String errorMessage;
	    private String errorCode;

    public BaseException(String errorMessage, String errorCode)
    {
        super(errorMessage);
        this.errorMessage = errorMessage;
        this.errorCode = errorCode;
    }

    public BaseException(String errorMessage, String errorCode, Throwable cause)
    {
        super(errorMessage, cause);
        this.errorMessage = errorMessage;
        this.errorCode = errorCode;
    }

    public BaseException(GDSConsumerErrorEnum exceptionEnum, String errorMessage, Throwable cause)
    {
        super((new StringBuilder()).append(exceptionEnum.getText()).append(":").append(errorMessage).toString(), cause);
        this.errorMessage = (new StringBuilder()).append(exceptionEnum.getText()).append(":").append(errorMessage).toString();
        errorCode = exceptionEnum.getValue();
    }

    public String getErrorMessage()
    {
        return errorMessage;
    }

    public String getErrorCode()
    {
        return errorCode;
    }

    public String toString()
    {
        String s = getClass().getName();
        String message = getLocalizedMessage();
        return message == null ? s : (new StringBuilder()).append(s).append(" Code:").append(getErrorCode()).append(" : ").append(message).toString();
    }

}
