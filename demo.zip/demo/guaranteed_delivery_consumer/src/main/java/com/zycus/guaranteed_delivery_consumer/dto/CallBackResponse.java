package com.zycus.guaranteed_delivery_consumer.dto;

import com.zycus.guaranteed_delivery_consumer.enums.CallBackEnum;

public class CallBackResponse {

	private CallBackEnum status;
	
	private String callBackResponse;
	
	private Errors errors;

	public CallBackEnum getStatus() {
		return status;
	}

	public String getCallBackResponse() {
		return callBackResponse;
	}
	
	public CallBackResponse() {
		super();
	}
	
	public CallBackResponse(CallBackEnum status, String callBackResponse) {
		super();
		this.status = status;
		this.callBackResponse = callBackResponse;
	}

	public Errors getErrors() {
		return errors;
	}

	public void setErrors(Errors errors) {
		this.errors = errors;
	}

}
