package com.zycus.guaranteed_delivery_consumer.enums;

public enum CallBackEnum {

	SUCCESS,FAILED,PARKED;
}
