package com.zycus.guaranteed_delivery_consumer.schedulerjob;

import java.sql.Connection;

import org.quartz.DisallowConcurrentExecution;
import org.quartz.Job;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import org.quartz.PersistJobDataAfterExecution;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.zycus.guaranteed_delivery_consumer.Exception.GDSConsumerException;
import com.zycus.guaranteed_delivery_consumer.dto.DBConnection;
import com.zycus.guaranteed_delivery_consumer.service.ConsumerProductCallBack;
import com.zycus.guaranteed_delivery_consumer.service.GDSConsumerSchedulerJobService;
import com.zycus.guaranteed_delivery_consumer.util.DBConnectionValidator;

@Component
@PersistJobDataAfterExecution
@DisallowConcurrentExecution
public class GDSConsumerScheduler implements Job {

	private static final Logger LOG = LoggerFactory.getLogger(GDSConsumerScheduler.class);

	@Autowired
	private ConsumerProductCallBack consumerProductCallBack;

	@Autowired
	private GDSConsumerSchedulerJobService gdsConsumerSchedulerJobService;
	
	@Override
	public void execute(JobExecutionContext context) throws JobExecutionException {

		LOG.info("Starting Scheduler.... ");

		DBConnection dbConnection = null;
		try {
			dbConnection = consumerProductCallBack.getConnection();
			DBConnectionValidator.validateDBConnection(dbConnection);
		}catch(GDSConsumerException e) {
			LOG.error("Unable to get DBConnection Due to {}", e);
			consumerProductCallBack.sendNotifcation("Unable to get DBConnection Due to {}"+e);
			return;
		}catch (Exception e) {
			LOG.error("Unable to get DBConnection Due to {}", e);
			consumerProductCallBack.sendNotifcation("Unable to get DBConnection Due to {}"+e);
			return;
		}

		//dispatch
		gdsConsumerSchedulerJobService.dispatchMessageToProduct(dbConnection);
		
		//retry for call Back to CGDS 
		gdsConsumerSchedulerJobService.callBackToCentralGDS(dbConnection);

		if(dbConnection.isConnectionCloseRequired()) {
			try{
				Connection con = dbConnection.getConnection();
				con.close();
				LOG.info("Connection closed successfully ");
			}catch (Exception e) {
				LOG.error("Unable to close Connection due to {}", e);
			}
		}
	}

}
