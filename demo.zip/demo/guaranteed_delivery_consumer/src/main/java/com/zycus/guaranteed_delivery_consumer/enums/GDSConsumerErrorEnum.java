package com.zycus.guaranteed_delivery_consumer.enums;

import com.zycus.guaranteed_delivery_consumer.dto.GDSCConsumerRequest;

/**
 * Represents possible error constant's while Processing Host Request/Event.
 * @author Narendra M
 * @version 1.0
 */
public enum GDSConsumerErrorEnum {
	/**
	 * Represents Central GDS's {@link GDSCConsumerRequest} saving to DB has been failed.
	 */
	GDSCCONSUMERREQUEST_PERSIST_FAILED {
		@Override
		public String getValue() {
			return "NR-GDSC-S-2000";
		}
		@Override
		public String getText() {
			return "Unable to save Central GDS's GDSCConsumerRequest, Due to Connection or SessionFactory Problem,Please Check logs";
		}
	},
	UPDATE_OPERATION_FAILED {
		@Override
		public String getValue() {
			return "NR-GDSC-S-2001";
		}
		@Override
		public String getText() {
			return "Unable to Update GDSCConsumerRequest due to SQLException";
		}
	},
	FETCH_OPERATION_FAILED {
		@Override
		public String getValue() {
			return "NR-GDSC-S-2002";
		}
		@Override
		public String getText() {
			return "Unable to Fetch Data from Consumer Table";
		}
	},
	GDS_CONSUMER_ID_NULL {
		@Override
		public String getValue() {
			return "NR-GDSC-S-2003";
		}
		@Override
		public String getText() {
			return "Failed to generate GDSConsumerId";
		}
	},
	INVALID_GDS_CONSUMER_ID {
		@Override
		public String getValue() {
			return "NR-GDSC-S-2004";
		}
		@Override
		public String getText() {
			return "Invalid GDS Consumer ID";
		}
	},
	GDS_CONSUMER_VALIDATION_FAILED {
		@Override
		public String getValue() {
			return "NR-GDSC-S-2005";
		}
		@Override
		public String getText() {
			return "GDSCConsumerRequest Validation Failed, Please find logs for more information";
		}
	},
	OTHER_EXCEPTION_AT_DISPATCH {
		@Override
		public String getValue() {
			return "NR-GDSC-C-2006";
		}
		@Override
		public String getText() {
			return "Exception thrown by product";
		}
	},
	GDS_CONSUMER_CONFIGURATION_FAILED {
		@Override
		public String getValue() {
			return "RE-GDSC-S-2007";
		}
		@Override
		public String getText() {
			return "Please set all Mandatory properties for GDSConsumerConfiguration class";
		}
	},
	OTHER_EXCEPTION_AT_CALLBACK {
		@Override
		public String getValue() {
			return "RE-GDSC-S-2008";
		}
		@Override
		public String getText() {
			return "Exception thrown by Central GDS";
		}
	},
	UNABLE_TO_CONVERT_PRODUCT_RESPONSE {
		@Override
		public String getValue() {
			return "RE-GDSC-S-2009";
		}
		@Override
		public String getText() {
			return "Failed to convert Product Response to JSON object";
		}
	},
	REST_CONNECTION_TIMEOUT {
		@Override
		public String getValue() {
			return "RE-GDSC-S-2010";
		}
		@Override
		public String getText() {
			return "Connection Time Out. Unable to reach Central GDS!!!";
		}
	},
	REST_OTHER_EXCEPTION {
		@Override
		public String getValue() {
			return "RE-GDSC-S-2011";
		}
		@Override
		public String getText() {
			return "Unable send data to Central GDS!!!";
		}
	},
	INTERNAL_SERVER_ERROR {
		@Override
		public String getValue() {
			return "RE-GDSC-S-2012";
		}
		@Override
		public String getText() {
			return "Exception occured internally at Consumer";
		}
	},
	ACK_FROM_CGDS_NULL{
		@Override
		public String getValue() {
			return "RE-GDSC-S-2013";
		}
		@Override
		public String getText() {
			return "Response from Central GDS cannot be Null";
		}
	},
	UNABLE_TO_CLOSE_OPEN_CURSORS{
		@Override
		public String getValue() {
			return "RE-GDSC-S-2014";
		}
		@Override
		public String getText() {
			return "Unable to close open cursors";
		}
	},
	;	

	public abstract String getText();
	public abstract String getValue();

}
