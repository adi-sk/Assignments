package com.zycus.guaranteed_delivery_consumer.service;

import com.zycus.guaranteed_delivery_consumer.dto.DBConnection;

public interface GDSConsumerSchedulerJobService {

	public void dispatchMessageToProduct(DBConnection dbConnection);

	public void callBackToCentralGDS(DBConnection dbConnection);
}
