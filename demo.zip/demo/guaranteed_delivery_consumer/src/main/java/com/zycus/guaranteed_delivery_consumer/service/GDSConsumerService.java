package com.zycus.guaranteed_delivery_consumer.service;

import java.util.List;

import com.zycus.guaranteed_delivery_consumer.Exception.GDSConsumerException;
import com.zycus.guaranteed_delivery_consumer.dto.CallBackResponse;
import com.zycus.guaranteed_delivery_consumer.dto.DBConnection;
import com.zycus.guaranteed_delivery_consumer.model.ConsumerProductDataDispatchModel;

public interface GDSConsumerService extends GDSConsumerRestEndPoint {

	public boolean updateEventConsumptionSuccess(long gdsConsumerId,DBConnection dbConnection) throws GDSConsumerException;

	public boolean updateEventConsumptionFailed(long gdsConsumerId,DBConnection dbConnection) throws GDSConsumerException;

	public boolean updateEventConsumptionParked(long gdsConsumerId,DBConnection dbConnection) throws GDSConsumerException;

	public List<ConsumerProductDataDispatchModel> getPendingDispath(DBConnection dbConnection) throws GDSConsumerException;

	public boolean updateConsumerEventExecutionAtDispatchAndStatusInProgressing(long gdsConsumerId,DBConnection dbConnection) throws GDSConsumerException;

	public boolean updateErrorCodeErrorDescriptionStackTrace(long gdsConsumerId,String errorCode,String errorDescription,String stackTrace, DBConnection dbConnection) throws GDSConsumerException;
	
	public Long checkDuplicate(Long deliveryId, long producerId, String gdscId) throws GDSConsumerException;
	
	public boolean updateProductResponse(long consumerId,CallBackResponse response,DBConnection dbConnection) throws GDSConsumerException;
	
	public void centralGDSCallBack(DBConnection dbConnection,ConsumerProductDataDispatchModel model,CallBackResponse response) throws GDSConsumerException;

	boolean updateCentralGDSCallBackResponse(long consumerId, String response, DBConnection dbConnection) throws GDSConsumerException;

	public List<ConsumerProductDataDispatchModel> getPendingForCallBack(DBConnection dbConnection) throws GDSConsumerException; 

}
