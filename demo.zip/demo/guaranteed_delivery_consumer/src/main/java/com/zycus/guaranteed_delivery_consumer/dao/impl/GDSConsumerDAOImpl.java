package com.zycus.guaranteed_delivery_consumer.dao.impl;

import java.util.Date;
import java.util.List;

import org.springframework.stereotype.Repository;

import com.zycus.guaranteed_delivery_consumer.Exception.GDSConsumerException;
import com.zycus.guaranteed_delivery_consumer.dao.GDSConsumerDAO;
import com.zycus.guaranteed_delivery_consumer.dto.DBConnection;
import com.zycus.guaranteed_delivery_consumer.dto.GDSCConsumerRequest;
import com.zycus.guaranteed_delivery_consumer.model.ConsumerProductDataDispatchModel;

@Repository
public class GDSConsumerDAOImpl extends GDSConsumerDataDAOImpl implements GDSConsumerDAO {

	@Override
	public Long updateCapturedEventData(GDSCConsumerRequest gdscRequest, DBConnection dbConnection) throws GDSConsumerException {
		return updateCapturedEventData(gdscRequest,dbConnection.getConnection());
	}

	@Override
	public List<ConsumerProductDataDispatchModel> getPendingDispath(DBConnection dbConnection) throws GDSConsumerException {
		return getPendingDispath(dbConnection.getConnection());
	}

	@Override
	public boolean updateEventDispatchStatus(long gdsConsumerId, DBConnection dbConnection, String status) throws GDSConsumerException {
		return updateEventDispatchStatus(gdsConsumerId,dbConnection.getConnection(),status);
	}

	@Override
	public boolean updateConsumerEventExecutionAtDispatchAndStatusInProgressing(long gdsConsumerId, String status, String executionAt, DBConnection dbConnection) throws GDSConsumerException {
		return updateConsumerEventStatusAndExecutaionAt(gdsConsumerId,status,executionAt,dbConnection.getConnection());
	}

	@Override
	public boolean updateProductResponseDate(Long gdsConsumerId, DBConnection dbConnection, Date productResponseDate) throws GDSConsumerException {
		return updateProductResponseDate(gdsConsumerId,dbConnection.getConnection(),productResponseDate);
	}

	@Override
	public boolean updateErrorCodeErrorDescriptionStackTrace(long gdsConsumerId, String errorCode, String errorDescription,String stackTrace,DBConnection dbConnection) throws GDSConsumerException {
		return updateErrorCodeAndErrorDescription(gdsConsumerId,errorCode,errorDescription,stackTrace,dbConnection.getConnection());
	}

	@Override
	public Long checkDuplicate(Long deliveryId, long producerId, String gdscId,DBConnection dbConnection) throws GDSConsumerException {
		return checkDuplicate(deliveryId,producerId,gdscId,dbConnection.getConnection());
	}

	@Override
	public boolean updateProductResponse(long consumerId, String response,DBConnection dbConnection) throws GDSConsumerException {
		return updateProductResponse(consumerId,response,dbConnection.getConnection());
	}

	@Override
	public boolean updateCentralGDSCallBackResponse(long consumerId, String response, DBConnection dbConnection) throws GDSConsumerException {
		return updateCentralGDSCallBackResponse(consumerId,response,dbConnection.getConnection());
	}

	@Override
	public List<ConsumerProductDataDispatchModel> getPendingForCallBack(DBConnection dbConnection) throws GDSConsumerException {
		return getPendingForCallBack(dbConnection.getConnection());
	}

	@Override
	public String getProductResponse(long gdsConsumerId, DBConnection dbConnection) throws GDSConsumerException {
		return getProductResponse(gdsConsumerId,dbConnection.getConnection());
	}

}
