package com.zycus.guaranteed_delivery_consumer.util;

import java.util.ArrayList;
import java.util.List;

import com.zycus.guaranteed_delivery_consumer.dto.EventInfo;
import com.zycus.guaranteed_delivery_consumer.dto.GDSCConsumerRequest;

public class GDSCConsumerRequestValidator {

	public static List<String> validateGDSCConsumerRequest(GDSCConsumerRequest gdsRequest) {
		List<String> errorList = new ArrayList<String>();
		if (gdsRequest == null) {
			errorList.add("GDSCConsumerRequest : Cannot be null");
		} else {
			if (checkIfNullNEmpty(gdsRequest.getGdscId())) {
				errorList.add("GDSCConsumerRequest : (gdscId : Cannot be null or Empty)");
			}
			if (checkIfNullNEmpty(gdsRequest.getSourceProductCode())) {
				errorList.add("GDSCConsumerRequest : (sourceProductCode : Cannot be null or Empty)");
			}
			if (checkIfNullNEmpty(gdsRequest.getMessageToDispatch())) {
				errorList.add("GDSCConsumerRequest : (messageToDispatch : Cannot be null or Empty)");
			}
			if (checkIfNullNEmpty(gdsRequest.getMessageType())) {
				errorList.add("GDSCConsumerRequest : (messageType : Cannot be null or Empty)");
			}
			if (gdsRequest.getDeliveryId() == null) {
				errorList.add("GDSCConsumerRequest : (deliveryId : Cannot be null)");
			}
			EventInfo eventInfo = gdsRequest.getEventInfo();
			if (eventInfo == null) {
				errorList.add("eventInfo : Cannot be null)");
			} else {
				if (checkIfNullNEmpty(eventInfo.getEventId())) {
					errorList.add("eventInfo : (eventId : Cannot be null or Empty)");
				}
				if (checkIfNullNEmpty(eventInfo.getEntityId())) {
					errorList.add("eventInfo : (entityId : Cannot be null or Empty)");
				}
				if (checkIfNullNEmpty(eventInfo.getEntityType())) {
					errorList.add("eventInfo : (entityType : Cannot be null or Empty)");
				}
				if (checkIfNullNEmpty(eventInfo.getEventType())) {
					errorList.add("eventInfo : (eventType : Cannot be null or Empty)");
				}
				if (checkIfNullNEmpty(eventInfo.getTenantId())) {
					errorList.add("eventInfo : (tenantId : Cannot be null or Empty)");
				}
			}
		}
		return errorList;
	}

	private static boolean checkIfNullNEmpty(String str) {
		return (str == null || str.isEmpty()) ? true : false;
	}
}
