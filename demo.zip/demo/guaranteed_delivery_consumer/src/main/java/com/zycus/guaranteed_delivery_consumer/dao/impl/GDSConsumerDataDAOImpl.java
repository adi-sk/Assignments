package com.zycus.guaranteed_delivery_consumer.dao.impl;

import static com.zycus.guaranteed_delivery_consumer.constant.GDSConsumerDataFieldConstant.*;
import static com.zycus.guaranteed_delivery_consumer.constant.JDBCSqlConstant.CHECK_DUPICATE;
import static com.zycus.guaranteed_delivery_consumer.constant.JDBCSqlConstant.GET_PENDING_DISPATCH;
import static com.zycus.guaranteed_delivery_consumer.constant.JDBCSqlConstant.GET_PENDING_FOR_CALL_BACK;
import static com.zycus.guaranteed_delivery_consumer.constant.JDBCSqlConstant.GET_PRODUCT_RESPONSE;
import static com.zycus.guaranteed_delivery_consumer.constant.JDBCSqlConstant.GET_SEQUENCE_ORACLE;
import static com.zycus.guaranteed_delivery_consumer.constant.JDBCSqlConstant.GET_SEQUENCE_MSSQL;
import static com.zycus.guaranteed_delivery_consumer.constant.JDBCSqlConstant.SAVE_CONSUMER_DATA;
import static com.zycus.guaranteed_delivery_consumer.constant.JDBCSqlConstant.UPDATE_CGDS_CALL_BACK_RESPONSE;
import static com.zycus.guaranteed_delivery_consumer.constant.JDBCSqlConstant.UPDATE_ERRORCODE_AND_ERRORDESCRIPTION;
import static com.zycus.guaranteed_delivery_consumer.constant.JDBCSqlConstant.UPDATE_EXECUTION_AT;
import static com.zycus.guaranteed_delivery_consumer.constant.JDBCSqlConstant.UPDATE_PRODUCT_RESPONSE;
import static com.zycus.guaranteed_delivery_consumer.constant.JDBCSqlConstant.UPDATE_PRODUCT_RESPONSE_DATE;
import static com.zycus.guaranteed_delivery_consumer.constant.JDBCSqlConstant.UPDATE_STATUS;
import static com.zycus.guaranteed_delivery_consumer.constant.JDBCSqlConstant.UPDATE_STATUS_AND_EXECUTION_AT;

import java.sql.Clob;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.TimeZone;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.zycus.guaranteed_delivery_consumer.Exception.GDSConsumerException;
import com.zycus.guaranteed_delivery_consumer.constant.ConsumerExecutionAt;
import com.zycus.guaranteed_delivery_consumer.dao.GDSConsumerDataDAO;
import com.zycus.guaranteed_delivery_consumer.dto.GDSCConsumerRequest;
import com.zycus.guaranteed_delivery_consumer.enums.GDSConsumerErrorEnum;
import com.zycus.guaranteed_delivery_consumer.model.ConsumerProductDataDispatchModel;

public class GDSConsumerDataDAOImpl implements GDSConsumerDataDAO {

	private static final Logger LOG = LoggerFactory.getLogger(GDSConsumerDataDAOImpl.class);

	@Override
	public Long updateCapturedEventData(GDSCConsumerRequest gdscRequest, Connection connection) throws GDSConsumerException {
		PreparedStatement pst = null;
		ResultSet rs = null;
		PreparedStatement ps = null;
		try {
			pst = getSequence(connection);
			rs = pst.executeQuery();
			if(rs.next()) {
				long gdsConsumerId = rs.getLong(1);
				ps = connection.prepareStatement(SAVE_CONSUMER_DATA);
				TimeZone.setDefault(TimeZone.getTimeZone("UTC"));
				ps.setLong(1, gdsConsumerId);
				ps.setTimestamp(2, getCurrentTimeStamp(new Date()));
				ps.setLong(3, gdscRequest.getDeliveryId());
				ps.setLong(4, gdscRequest.getGdsProducerId());
				ps.setString(5, gdscRequest.getGdscId());
				ps.setTimestamp(6, gdscRequest.getTimeStamp()==null?null:getCurrentTimeStamp(gdscRequest.getTimeStamp()));
				ps.setString(7, gdscRequest.getConsumerProductCode());
				ps.setString(8, gdscRequest.getSourceProductCode());
				ps.setString(9, gdscRequest.getMessageToDispatch());
				ps.setString(10, gdscRequest.getMessageType());
				ps.setString(11, gdscRequest.getAddtionalInfo());
				ps.setLong(12, gdscRequest.getEventInfo().getId());
				ps.setString(13, gdscRequest.getEventInfo().getEventId());
				ps.setString(14, gdscRequest.getEventInfo().getEntityId());

				ps.setString(15, gdscRequest.getEventInfo().getEntityType());
				ps.setString(16, gdscRequest.getEventInfo().getEventType());
				ps.setString(17, gdscRequest.getEventInfo().getVersion());
				ps.setString(18, gdscRequest.getEventInfo().getExtraInfo());
				ps.setString(19, gdscRequest.getEventInfo().getTenantId());
				ps.setString(20, gdscRequest.getEventInfo().getBusinessRefId());
				ps.setTimestamp(21, gdscRequest.getEventInfo().getTimeStamp()==null?null:getCurrentTimeStamp(gdscRequest.getEventInfo().getTimeStamp()));
				ps.setTimestamp(22, getCurrentTimeStamp(new Date()));
				ps.setString(23, ConsumerExecutionAt.EVENT_RECEIVED);
				ps.setString(24, gdscRequest.getEventInfo().getMetadataVersion());
				int flag = ps.executeUpdate();
				boolean status = isSavedOrUpdatedSuccessfully(flag);
				if(status) {
					return gdsConsumerId;
				}

			}
		} catch (Exception e) {
			LOG.error("Unable to insert GDSConsumerRequest Data to Table {}", e);
			throw new GDSConsumerException(GDSConsumerErrorEnum.GDSCCONSUMERREQUEST_PERSIST_FAILED.getText(),GDSConsumerErrorEnum.GDSCCONSUMERREQUEST_PERSIST_FAILED.getValue());
		}finally {
			closeCursors(pst, rs);
			closeCursors(ps);
		}

		return null;
	}

	private PreparedStatement getSequence(Connection connection) throws SQLException {
		PreparedStatement pst;
		if(connection.getMetaData().getURL().contains("sqlserver")) {
			pst = connection.prepareStatement(GET_SEQUENCE_MSSQL);
		}else {
			pst = connection.prepareStatement(GET_SEQUENCE_ORACLE);
		}
		return pst;
	}

	@Override
	public List<ConsumerProductDataDispatchModel> getPendingDispath(Connection connection) throws GDSConsumerException {
		PreparedStatement ps = null;
		ResultSet resultSet = null;
		try {
			LOG.info(GET_PENDING_DISPATCH);
			ps = connection.prepareStatement(GET_PENDING_DISPATCH);
			resultSet = ps.executeQuery();
			List<ConsumerProductDataDispatchModel> dispatchData=new ArrayList<ConsumerProductDataDispatchModel>();
			while (resultSet.next()) {
				ConsumerProductDataDispatchModel data=new ConsumerProductDataDispatchModel();
				//GDSC_CONSUMER_ID,SOURCE_PRODUCT_CODE,MESSAGE_TO_DISPATCH,EVENT_ID,ENTITY_ID,ENTITY_TYPE,EVENT_TYPE,VERSION,TENANT_ID,BUSSINESS_REF_ID,MESSAGE_TYPE
				data.setGdscConsumerId(resultSet.getLong(GDSC_CONSUMER_ID));
				data.setEntityId(resultSet.getString(ENTITY_ID));
				data.setEntityType(resultSet.getString(ENTITY_TYPE));
				data.setEventId(resultSet.getString(EVENT_ID));
				data.setEventType(resultSet.getString(EVENT_TYPE));
				data.setMessageToDispatch(resultSet.getString(MESSAGE_TO_DISPATCH));
				data.setMessageType(resultSet.getString(MESSAGE_TYPE));
				data.setSourceProductCode(resultSet.getString(SOURCE_PRODUCT_CODE));
				data.setTenantId(resultSet.getString(TENANT_ID));
				data.setVersion(resultSet.getString(VERSION));
				data.setBussinesRefId(resultSet.getString(BUSSINESS_REF_ID));
				data.setConsumerProductCode(resultSet.getString(CONSUMER_PRODUCT_CODE));
				data.setGdsProducerId(resultSet.getLong(GDS_PRODUCER_ID));
				data.setGdscId(resultSet.getString(GDSCID));
				data.setMetadataVersion(resultSet.getString(METADATA_VERSION));
				data.setExtraInfo(resultSet.getString(EXTRA_INFO));
				dispatchData.add(data);
			}
			return dispatchData;
		}catch (Exception e) {
			LOG.error("Unable to fetch Data From Table {}", e);
			throw new GDSConsumerException(GDSConsumerErrorEnum.FETCH_OPERATION_FAILED.getText(),GDSConsumerErrorEnum.FETCH_OPERATION_FAILED.getValue());
		}finally {
			closeCursors(ps, resultSet);
		}
	}

	@Override
	public boolean updateEventDispatchStatus(long gdsConsumerId, Connection connection, String status) throws GDSConsumerException {
		PreparedStatement ps=null;
		try {
			ps = connection.prepareStatement(UPDATE_STATUS);
			TimeZone.setDefault(TimeZone.getTimeZone("UTC"));
			ps.setString(1, status);
			ps.setTimestamp(2, getCurrentTimeStamp(new Date()));
			ps.setLong(3, gdsConsumerId);
			int flag = ps.executeUpdate();
			return isSavedOrUpdatedSuccessfully(flag);
		}catch (GDSConsumerException e) {
			throw e;
		}catch (Exception e) {
			LOG.error("Unable to Update status to Table {}", e);
			throw new GDSConsumerException(GDSConsumerErrorEnum.UPDATE_OPERATION_FAILED.getText(),GDSConsumerErrorEnum.UPDATE_OPERATION_FAILED.getValue());
		}finally {
			closeCursors(ps);
		}
	}

	@Override
	public boolean updateEventConsumptionExecutaionAt(long gdsConsumerId, Connection connection, String executionAt) throws GDSConsumerException {
		PreparedStatement ps=null;
		try {
			ps = connection.prepareStatement(UPDATE_EXECUTION_AT);
			ps.setString(1, executionAt);
			ps.setLong(2, gdsConsumerId);
			int flag = ps.executeUpdate();
			return isSavedOrUpdatedSuccessfully(flag);
		}catch (GDSConsumerException e) {
			throw e;
		}catch (Exception e) {
			LOG.error("Unable to Update ExecutionAt to Table {}", e);
			throw new GDSConsumerException(GDSConsumerErrorEnum.UPDATE_OPERATION_FAILED.getText(),GDSConsumerErrorEnum.UPDATE_OPERATION_FAILED.getValue());
		}finally {
			closeCursors(ps);
		}
	}

	@Override
	public boolean updateConsumerEventStatusAndExecutaionAt(long gdsConsumerId, String status, String executionAt, Connection connection) throws GDSConsumerException {
		PreparedStatement ps=null;
		try {
			ps = connection.prepareStatement(UPDATE_STATUS_AND_EXECUTION_AT);
			ps.setString(1, status);
			ps.setString(2, executionAt);
			ps.setLong(3, gdsConsumerId);
			int flag = ps.executeUpdate();
			return isSavedOrUpdatedSuccessfully(flag);
		}catch (GDSConsumerException e) {
			throw e;
		}catch (Exception e) {
			LOG.error("Unable to Update ExecutionAt to Table {}", e);
			throw new GDSConsumerException(GDSConsumerErrorEnum.UPDATE_OPERATION_FAILED.getText(),GDSConsumerErrorEnum.UPDATE_OPERATION_FAILED.getValue());
		}finally {
			closeCursors(ps);
		}
	}

	@Override
	public boolean updateProductResponseDate(long gdsConsumerId, Connection connection, Date productResponseDate) throws GDSConsumerException {
		PreparedStatement ps=null;
		try {
			ps = connection.prepareStatement(UPDATE_PRODUCT_RESPONSE_DATE);
			ps.setTimestamp(1, getCurrentTimeStamp(productResponseDate));
			ps.setLong(2, gdsConsumerId);
			int flag = ps.executeUpdate();
			return isSavedOrUpdatedSuccessfully(flag);
		}catch (GDSConsumerException e) {
			throw e;
		}catch (Exception e) {
			LOG.error("Unable to Update ProductResponseDate to Table {}", e);
			throw new GDSConsumerException(GDSConsumerErrorEnum.UPDATE_OPERATION_FAILED.getText(),GDSConsumerErrorEnum.UPDATE_OPERATION_FAILED.getValue());
		}finally {
			closeCursors(ps);
		}
	}

	@Override
	public boolean updateErrorCodeAndErrorDescription(long gdsConsumerId, String errorCode, String errorDescription,String stackTrace, Connection connection) throws GDSConsumerException {
		PreparedStatement ps=null;
		try {
			ps = connection.prepareStatement(UPDATE_ERRORCODE_AND_ERRORDESCRIPTION);
			ps.setString(1,errorCode);
			ps.setString(2, errorDescription);
			Clob clob = connection.createClob();
			clob.setString(1, stackTrace);
			ps.setClob(3,clob);
			ps.setLong(4, gdsConsumerId);
			int flag = ps.executeUpdate();
			return isSavedOrUpdatedSuccessfully(flag);
		}catch (GDSConsumerException e) {
			throw e;
		}catch (Exception e) {
			LOG.error("Unable to Update Error_Code and Error Description to Table {}", e);
			throw new GDSConsumerException(GDSConsumerErrorEnum.UPDATE_OPERATION_FAILED.getText(),GDSConsumerErrorEnum.UPDATE_OPERATION_FAILED.getValue());
		}finally {
			closeCursors(ps);
		}
	}

	@Override
	public Long checkDuplicate(Long deliveryId, long producerId, String gdscId, Connection connection) throws GDSConsumerException {
		PreparedStatement ps = null;
		ResultSet resultSet = null;
		try {
			LOG.info(CHECK_DUPICATE);
			ps = connection.prepareStatement(CHECK_DUPICATE);
			ps.setLong(1,deliveryId);
			ps.setString(2, gdscId);
			ps.setLong(3, producerId);
			resultSet = ps.executeQuery();
			if(resultSet.next()) {
				Long consumerId = resultSet.getLong(GDSC_CONSUMER_ID);
				return consumerId;
			}
			return null;
		}catch (Exception e) {
			LOG.error("Unable to fetch Data From Table {}", e);
			throw new GDSConsumerException(GDSConsumerErrorEnum.FETCH_OPERATION_FAILED.getText(),GDSConsumerErrorEnum.FETCH_OPERATION_FAILED.getValue());
		}finally {
			closeCursors(ps,resultSet);
		}
	}

	private java.sql.Timestamp getCurrentTimeStamp(Date date) {
		if(null==date)
			return null;
		return new java.sql.Timestamp(date.getTime());
	}

	private boolean isSavedOrUpdatedSuccessfully(int flag) throws GDSConsumerException {
		if(flag>0) {
			return true;
		}
		throw new GDSConsumerException(GDSConsumerErrorEnum.INVALID_GDS_CONSUMER_ID.getText(),GDSConsumerErrorEnum.INVALID_GDS_CONSUMER_ID.getValue());
	}

	@Override
	public boolean updateProductResponse(long gdsConsumerId, String productResponse,Connection connection) throws GDSConsumerException {

		PreparedStatement ps = null;
		try {
			ps = connection.prepareStatement(UPDATE_PRODUCT_RESPONSE);
			Clob clob = connection.createClob();
			clob.setString(1, productResponse);
			ps.setClob(1,clob);
			ps.setLong(2, gdsConsumerId);
			int flag = ps.executeUpdate();
			return isSavedOrUpdatedSuccessfully(flag);
		}catch (GDSConsumerException e) {
			throw e;
		}catch (Exception e) {
			LOG.error("Unable to save product response to Table {}", e);
			throw new GDSConsumerException(GDSConsumerErrorEnum.UPDATE_OPERATION_FAILED.getText(),GDSConsumerErrorEnum.UPDATE_OPERATION_FAILED.getValue());
		}finally {
			closeCursors(ps);
		}
	}

	@Override
	public boolean updateCentralGDSCallBackResponse(long gdsConsumerId, String cgdsAck, Connection connection)
			throws GDSConsumerException {
		PreparedStatement ps =null;
		try {
			ps = connection.prepareStatement(UPDATE_CGDS_CALL_BACK_RESPONSE);
			Clob clob = connection.createClob();
			clob.setString(1, cgdsAck);
			ps.setClob(1,clob);
			ps.setLong(2, gdsConsumerId);
			int flag = ps.executeUpdate();
			return isSavedOrUpdatedSuccessfully(flag);
		}catch (GDSConsumerException e) {
			throw e;
		}catch (Exception e) {
			LOG.error("Unable to save product response to Table {}", e);
			throw new GDSConsumerException(GDSConsumerErrorEnum.UPDATE_OPERATION_FAILED.getText(),GDSConsumerErrorEnum.UPDATE_OPERATION_FAILED.getValue());
		}finally {
			closeCursors(ps);
		}
	}

	@Override
	public List<ConsumerProductDataDispatchModel> getPendingForCallBack(Connection connection) throws GDSConsumerException {
		PreparedStatement ps = null;
		ResultSet resultSet = null;
		try {
			LOG.info(GET_PENDING_FOR_CALL_BACK);
			ps = connection.prepareStatement(GET_PENDING_FOR_CALL_BACK);
			resultSet = ps.executeQuery();
			List<ConsumerProductDataDispatchModel> dispatchData=new ArrayList<ConsumerProductDataDispatchModel>();
			while (resultSet.next()) {
				ConsumerProductDataDispatchModel data=new ConsumerProductDataDispatchModel();
				//GDSC_CONSUMER_ID,SOURCE_PRODUCT_CODE,MESSAGE_TO_DISPATCH,EVENT_ID,ENTITY_ID,ENTITY_TYPE,EVENT_TYPE,VERSION,TENANT_ID,BUSSINESS_REF_ID,MESSAGE_TYPE
				data.setGdscConsumerId(resultSet.getLong(GDSC_CONSUMER_ID));
				data.setEntityId(resultSet.getString(ENTITY_ID));
				data.setEntityType(resultSet.getString(ENTITY_TYPE));
				data.setEventId(resultSet.getString(EVENT_ID));
				data.setEventType(resultSet.getString(EVENT_TYPE));
				data.setMessageToDispatch(resultSet.getString(MESSAGE_TO_DISPATCH));
				data.setMessageType(resultSet.getString(MESSAGE_TYPE));
				data.setSourceProductCode(resultSet.getString(SOURCE_PRODUCT_CODE));
				data.setTenantId(resultSet.getString(TENANT_ID));
				data.setVersion(resultSet.getString(VERSION));
				data.setBussinesRefId(resultSet.getString(BUSSINESS_REF_ID));
				data.setConsumerProductCode(resultSet.getString(CONSUMER_PRODUCT_CODE));
				data.setGdsProducerId(resultSet.getLong(GDS_PRODUCER_ID));
				data.setGdscId(resultSet.getString(GDSCID));
				data.setMetadataVersion(resultSet.getString(METADATA_VERSION));
				dispatchData.add(data);
			}
			return dispatchData;
		}catch (Exception e) {
			LOG.error("Unable to fetch Data From Table {}", e);
			throw new GDSConsumerException(GDSConsumerErrorEnum.FETCH_OPERATION_FAILED.getText(),GDSConsumerErrorEnum.FETCH_OPERATION_FAILED.getValue());
		}finally {
			closeCursors(ps, resultSet);

		}
	}

	@Override
	public String getProductResponse(long gdsConsumerId, Connection connection) throws GDSConsumerException {
		PreparedStatement ps = null;
		ResultSet resultSet = null;
		try {
			LOG.info(GET_PRODUCT_RESPONSE);
			ps = connection.prepareStatement(GET_PRODUCT_RESPONSE);
			ps.setLong(1,gdsConsumerId);
			resultSet = ps.executeQuery();
			if(resultSet.next()) {
				String response =resultSet.getString(PRODUCT_RESPONSE);
				return response;
			}
			return null;
		}catch (Exception e) {
			LOG.error("Unable to fetch Data From Table {}", e);
			throw new GDSConsumerException(GDSConsumerErrorEnum.FETCH_OPERATION_FAILED.getText(),GDSConsumerErrorEnum.FETCH_OPERATION_FAILED.getValue());
		}finally {
			closeCursors(ps, resultSet);

		}
	}

	private void closeCursors(PreparedStatement ps) {
		try {
			if(ps!=null) {
				ps.close();
			}
		} catch (SQLException e) {
			LOG.error("Unable to close open cursors due to {}", e);
		}
	}
	private void closeCursors(PreparedStatement ps, ResultSet resultSet) {
		try {
			if(resultSet !=null) {
				resultSet.close();
			}
			if(ps!=null) {
				ps.close();
			}
		} catch (SQLException e) {
			LOG.error("Unable to close open cursors due to {}", e);
		}finally {
			if(ps!=null) {
				try {
					ps.close();
				} catch (SQLException e) {
					LOG.error("Unable to close open cursors due to {}", e);
				}
			}
		}
	}

}
