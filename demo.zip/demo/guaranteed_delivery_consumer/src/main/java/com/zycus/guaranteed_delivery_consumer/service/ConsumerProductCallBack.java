package com.zycus.guaranteed_delivery_consumer.service;

import java.sql.Connection;

import com.zycus.guaranteed_delivery_consumer.dto.CallBackResponse;
import com.zycus.guaranteed_delivery_consumer.dto.DBConnection;
import com.zycus.guaranteed_delivery_consumer.model.ConsumerProductDataDispatchModel;

public interface ConsumerProductCallBack {

	/**
	 * Consumer Product has to override this method and it need to consume the ConsumerProductDataDispatchModel data on successful consume return true else return false.
	 * @param data
	 * @return boolean
	 */
	public CallBackResponse OnMessage(ConsumerProductDataDispatchModel data);

	/**
	 * consumer Product has to set JDBC {@link Connection} Object.
	 * @return {@link DBConnection}
	 */
	public DBConnection getConnection();

	/**
	 * Used for sending notification to product.
	 * Guaranteed Delivery consumer calls this method for sending Notification to product.
	 * @param msg
	 */
	public void sendNotifcation(String msg);
}
