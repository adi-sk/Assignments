package com.zycus.guaranteed_delivery_consumer.service.impl;

import java.util.HashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.TreeSet;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.zycus.guaranteed_delivery_consumer.Exception.GDSConsumerException;
import com.zycus.guaranteed_delivery_consumer.configuration.GDSConsumerConfiguration;
import com.zycus.guaranteed_delivery_consumer.dao.GDSConsumerDAO;
import com.zycus.guaranteed_delivery_consumer.dto.CallBackResponse;
import com.zycus.guaranteed_delivery_consumer.dto.DBConnection;
import com.zycus.guaranteed_delivery_consumer.enums.CallBackEnum;
import com.zycus.guaranteed_delivery_consumer.enums.GDSConsumerErrorEnum;
import com.zycus.guaranteed_delivery_consumer.model.ConsumerProductDataDispatchModel;
import com.zycus.guaranteed_delivery_consumer.service.ConsumerProductCallBack;
import com.zycus.guaranteed_delivery_consumer.service.GDSConsumerSchedulerJobService;
import com.zycus.guaranteed_delivery_consumer.service.GDSConsumerService;

@Service
public class GDSConsumerSchedulerJobServiceImpl implements GDSConsumerSchedulerJobService {

	private static final Logger LOG = LoggerFactory.getLogger(GDSConsumerSchedulerJobServiceImpl.class);

	@Autowired
	private GDSConsumerService gdsConsumerService;

	@Autowired
	private ConsumerProductCallBack consumerProductCallBack;

	@Autowired
	private GDSConsumerConfiguration gdsConsumerConfiguration;

	@Autowired
	private GDSConsumerDAO gdsConsumerDAO;

	@Override
	public void dispatchMessageToProduct(DBConnection dbConnection) {

		try {
			LOG.info("Getting pending consumer Event's for dispatch...");
			List<ConsumerProductDataDispatchModel> consumerProductDataDispatchModels = gdsConsumerService.getPendingDispath(dbConnection);
			if(consumerProductDataDispatchModels.isEmpty()) {
				LOG.info("No consumer Event's pending for dispatch.");
			}else {
				Map<String, TreeSet<ConsumerProductDataDispatchModel>> chunks=new HashMap<String, TreeSet<ConsumerProductDataDispatchModel>>();
				LinkedHashSet<String> keyOrders=new LinkedHashSet<String>();

				//create chunks
				createChunks(consumerProductDataDispatchModels, chunks, keyOrders);

				//send to product
				sendToProduct(dbConnection, chunks, keyOrders);
			}
		} catch (GDSConsumerException e) {
			LOG.error("Unable to dispatch Messages to Product {}", e);
			consumerProductCallBack.sendNotifcation("Unable to dispatch Messages to Product {}"+ e);
		}

	}

	private void sendToProduct(DBConnection dbConnection, Map<String, TreeSet<ConsumerProductDataDispatchModel>> chunks, LinkedHashSet<String> keyOrders) throws GDSConsumerException {
		LOG.info("Sending event's to consumer's ConsumerProductCallBack->OnMessage() method...");
		boolean proceedWithRemainingSameEvent=gdsConsumerConfiguration.getProceedWithRemainingSameEvent(); 
		for(String keyOrder : keyOrders) {
			for(ConsumerProductDataDispatchModel consumerProductDataDispatchModel:chunks.get(keyOrder)) {
				long gdsConsumerId = consumerProductDataDispatchModel.getGdscConsumerId();
				LOG.info("Dispatching consumer Id - "+gdsConsumerId+" with Event Id - "+consumerProductDataDispatchModel.getEventId()+"  to product");
				try {
					boolean dispatchflag = gdsConsumerService.updateConsumerEventExecutionAtDispatchAndStatusInProgressing(gdsConsumerId, dbConnection);
					if(dispatchflag) {
						CallBackResponse response = consumerProductCallBack.OnMessage(consumerProductDataDispatchModel);
						if(response!=null && response.getStatus()==CallBackEnum.SUCCESS) {
							LOG.info("Dispatching consumer Id - "+gdsConsumerId+" with Event Id - "+consumerProductDataDispatchModel.getEventId()+"  to product successful");
							gdsConsumerService.updateProductResponse(gdsConsumerId, response, dbConnection);
							gdsConsumerService.updateEventConsumptionSuccess(gdsConsumerId, dbConnection);
							centralGDSCallBack(dbConnection, consumerProductDataDispatchModel, gdsConsumerId, response);
						}else {
							if(response.getStatus()==CallBackEnum.PARKED) {
								LOG.info("Dispatching consumer Id - "+gdsConsumerId+" with Event Id - "+consumerProductDataDispatchModel.getEventId()+"  to product has been Parked");
								gdsConsumerService.updateEventConsumptionParked(gdsConsumerId, dbConnection);
							}else {
								LOG.info("Dispatching consumer Id - "+gdsConsumerId+" with Event Id - "+consumerProductDataDispatchModel.getEventId()+"  to product has been failed");
								gdsConsumerService.updateEventConsumptionFailed(gdsConsumerId, dbConnection);
							}
							gdsConsumerService.updateProductResponse(gdsConsumerId, response, dbConnection);
							if(!proceedWithRemainingSameEvent) {
								break;
							}
						}
					}
				}
				catch (GDSConsumerException e) {
					LOG.error("Unable to dispatch Messages with Consumer Id -"+gdsConsumerId+" with Event Id - "+consumerProductDataDispatchModel.getEventId()+" to Product, Due to {}", e);
					updateDispatchFailed(dbConnection, gdsConsumerId, e,e.getErrorCode(), e.getErrorMessage());
					if(!proceedWithRemainingSameEvent) {
						break;
					}
				}catch (Exception e) {
					LOG.error("Unable to dispatch Messages with Consumer Id -"+gdsConsumerId+" with Event Id - "+consumerProductDataDispatchModel.getEventId()+" to Product, Due to {}", e);
					updateDispatchFailed(dbConnection, gdsConsumerId, e,GDSConsumerErrorEnum.OTHER_EXCEPTION_AT_DISPATCH.getValue(), e.getMessage());
					if(!proceedWithRemainingSameEvent) {
						break;
					}
				}	
			}
		}
		LOG.info("End of event's to consumer's ConsumerProductCallBack->OnMessage() method.");
	}

	private void centralGDSCallBack(DBConnection dbConnection, ConsumerProductDataDispatchModel consumerProductDataDispatchModel, long gdsConsumerId,
			CallBackResponse response) {
		try {
			gdsConsumerService.centralGDSCallBack(dbConnection, consumerProductDataDispatchModel, response);
		}catch (Exception e) {
			LOG.error("Unable to make Call back to CGDS for Consumer Id -"+gdsConsumerId+" with Event Id - "+consumerProductDataDispatchModel.getEventId()+", Due to {}", e);
		}
	}

	private void createChunks(List<ConsumerProductDataDispatchModel> consumerProductDataDispatchModels,
			Map<String, TreeSet<ConsumerProductDataDispatchModel>> chunks, LinkedHashSet<String> keyOrders) {
		LOG.info("Creating chunks to Consumer for dispatching...");
		for(ConsumerProductDataDispatchModel consumerProductDataDispatchModel : consumerProductDataDispatchModels) {
			String key = getKey(consumerProductDataDispatchModel);
			TreeSet<ConsumerProductDataDispatchModel> chunk=chunks.get(key);
			keyOrders.add(key);

			//Creating new chunk if key not present else add to previous existing
			if(chunk==null) {
				TreeSet<ConsumerProductDataDispatchModel> treeConsumerProductDataDispatchModel= new TreeSet<ConsumerProductDataDispatchModel>();
				treeConsumerProductDataDispatchModel.add(consumerProductDataDispatchModel);
				chunks.put(key,treeConsumerProductDataDispatchModel);
			}else {
				chunk.add(consumerProductDataDispatchModel);
			}
		}
	}

	public String getKey(ConsumerProductDataDispatchModel consumerProductDataDispatchModel) {
		return consumerProductDataDispatchModel.getEntityType()+""+consumerProductDataDispatchModel.getEntityId(); 
	}

	private void updateDispatchFailed(DBConnection dbConnection, long gdsConsumerId, Exception e,String errorCode,String errorDescription) throws GDSConsumerException {
		gdsConsumerService.updateEventConsumptionFailed(gdsConsumerId, dbConnection);
		gdsConsumerService.updateErrorCodeErrorDescriptionStackTrace(gdsConsumerId,errorCode,errorDescription,e.getMessage(), dbConnection);
		consumerProductCallBack.sendNotifcation("Unable to dispatch Messages for Consumer Id - "+gdsConsumerId+" to Product {}"+ e);
	}

	@Override
	public void callBackToCentralGDS(DBConnection dbConnection) {
		try {
			LOG.info("Getting pending consumer Event's for Call Back...");
			List<ConsumerProductDataDispatchModel> consumerProductDataDispatchModels = gdsConsumerService.getPendingForCallBack(dbConnection);
			if(consumerProductDataDispatchModels.isEmpty()) {
				LOG.info("No consumer Event's pending for Call Back.");
			}else {
				Map<String, TreeSet<ConsumerProductDataDispatchModel>> chunks=new HashMap<String, TreeSet<ConsumerProductDataDispatchModel>>();
				LinkedHashSet<String> keyOrders=new LinkedHashSet<String>();

				//create chunks
				createChunks(consumerProductDataDispatchModels, chunks, keyOrders);

				//send to product
				makeCallBackToCGDS(dbConnection, chunks, keyOrders);
			}
		} catch (GDSConsumerException e) {
			LOG.error("Unable to make Call Back to CGDS {}", e);
			consumerProductCallBack.sendNotifcation("Unable to make Call Back to CGDS {}"+ e);
		}

	}

	private void makeCallBackToCGDS(DBConnection dbConnection, Map<String, TreeSet<ConsumerProductDataDispatchModel>> chunks, LinkedHashSet<String> keyOrders) throws GDSConsumerException {
		LOG.info("Sending event's to CGDS CallBack...");
		for(String keyOrder : keyOrders) {
			for(ConsumerProductDataDispatchModel consumerProductDataDispatchModel:chunks.get(keyOrder)) {
				long gdsConsumerId = consumerProductDataDispatchModel.getGdscConsumerId();
				LOG.info("Call Back for consumer Id - "+gdsConsumerId+" with Event Id - "+consumerProductDataDispatchModel.getEventId()+"  to CGDS");
				try {
					String responseData = gdsConsumerDAO.getProductResponse(gdsConsumerId,dbConnection);
					ObjectMapper mapper = new ObjectMapper();
					CallBackResponse response = mapper.readValue(responseData, CallBackResponse.class); 
					if(response!=null) {
						gdsConsumerService.centralGDSCallBack(dbConnection, consumerProductDataDispatchModel, response);
					}else {
						gdsConsumerService.updateEventConsumptionFailed(gdsConsumerId, dbConnection);
					}
				}catch (GDSConsumerException e) {
					updateCallBackFailed(dbConnection, gdsConsumerId, e,GDSConsumerErrorEnum.OTHER_EXCEPTION_AT_DISPATCH.getValue(), e.getMessage());
				}catch (Exception e) {
					LOG.error("Unable to make Call Back to CGDS for Consumer Id -"+gdsConsumerId+" with Event Id - "+consumerProductDataDispatchModel.getEventId()+", Due to {}", e);
				}
			}
		}
		LOG.info("End of event's for Call Back to Central GDS.");
	}
	private void updateCallBackFailed(DBConnection dbConnection, long gdsConsumerId, Exception e,String errorCode,String errorDescription) throws GDSConsumerException {
		gdsConsumerService.updateEventConsumptionFailed(gdsConsumerId, dbConnection);
		gdsConsumerService.updateErrorCodeErrorDescriptionStackTrace(gdsConsumerId,errorCode,errorDescription,e.getMessage(), dbConnection);
		consumerProductCallBack.sendNotifcation("Unable to make Call Back for Consumer Id - "+gdsConsumerId+" to Product {}"+ e);
	}
}
