package com.zycus.guaranteed_delivery_consumer.enums;

public enum GDSConsumerRestErrorEnum {

	GDSCCONSUMERREST_OTHER_EXCEPTION {
		@Override
		public String getValue() {
			return "NR-GDSC-S-3000";
		}
		@Override
		public String getText() {
			return "Unable to save Central GDS's GDSCConsumerRequest";
		}
	},;	
	
	public abstract String getText();
	public abstract String getValue();
}
