package com.zycus.guaranteed_delivery_consumer.dao;

import java.util.Date;
import java.util.List;

import com.zycus.guaranteed_delivery_consumer.Exception.GDSConsumerException;
import com.zycus.guaranteed_delivery_consumer.dto.DBConnection;
import com.zycus.guaranteed_delivery_consumer.dto.GDSCConsumerRequest;
import com.zycus.guaranteed_delivery_consumer.model.ConsumerProductDataDispatchModel;

public interface GDSConsumerDAO extends GDSConsumerDataDAO {

	public Long updateCapturedEventData(GDSCConsumerRequest gdscRequest, DBConnection dbConnection) throws GDSConsumerException;
	
	public List<ConsumerProductDataDispatchModel> getPendingDispath(DBConnection dbConnection) throws GDSConsumerException;
	
	public boolean updateEventDispatchStatus(long gdsConsumerId,DBConnection dbconnection,String status) throws GDSConsumerException;
	
	public boolean updateConsumerEventExecutionAtDispatchAndStatusInProgressing(long gdsConsumerId,String status, String executionAt, DBConnection dbConnection) throws GDSConsumerException ;

	public boolean updateProductResponseDate(Long gdsConsumerId, DBConnection dbConnection, Date productResponseDate) throws GDSConsumerException;

	public boolean updateErrorCodeErrorDescriptionStackTrace(long gdsConsumerId, String errorCode, String errorDescription,String stackTrace, DBConnection dbConnection) throws GDSConsumerException;

	public Long checkDuplicate(Long deliveryId, long producerId, String gdscId, DBConnection dbConnection) throws GDSConsumerException;

	public boolean updateProductResponse(long consumerId, String response, DBConnection dbConnection) throws GDSConsumerException;

	public boolean updateCentralGDSCallBackResponse(long consumerId, String response, DBConnection dbConnection) throws GDSConsumerException;

	public List<ConsumerProductDataDispatchModel> getPendingForCallBack(DBConnection dbConnection) throws GDSConsumerException;

	public String getProductResponse(long gdsConsumerId, DBConnection dbConnection)throws GDSConsumerException;
}
