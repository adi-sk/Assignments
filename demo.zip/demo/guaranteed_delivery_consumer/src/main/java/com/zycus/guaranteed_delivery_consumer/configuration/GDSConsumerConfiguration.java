package com.zycus.guaranteed_delivery_consumer.configuration;

import javax.sql.DataSource;

import com.zycus.guaranteed_delivery_consumer.Exception.GDSConsumerException;
import com.zycus.guaranteed_delivery_consumer.enums.GDSConsumerErrorEnum;

public class GDSConsumerConfiguration {

	private boolean proceedWithRemainingSameEvent;

	private Integer quartzStartUpDelay;

	private String cronExpression;

	private String driverClass;

	private String dbUrl;

	private String dbUserName;

	private String dbPassword;
	
	private String productCode;
	
	private String gdsEndPoint;

	private String quartzTablePrefix;

	private String threadCount;

	private DataSource dataSource;

	public Integer getQuartzStartUpDelay() {
		return quartzStartUpDelay;
	}

	public String getCronExpression() {
		return cronExpression;
	}

	public String getDriverClass() {
		return driverClass;
	}

	public String getDbUrl() {
		return dbUrl;
	}

	public String getDbUserName() {
		return dbUserName;
	}

	public String getDbPassword() {
		return dbPassword;
	}

	private boolean checkIfNullNEmpty(String str) {
		return (str == null || str.isEmpty()) ? true : false;
	}

	public Boolean getProceedWithRemainingSameEvent() {
		return proceedWithRemainingSameEvent;
	}

	public String getProductCode() {
		return productCode;
	}

	public String getGdsEndPoint() {
		return gdsEndPoint;
	}

	public GDSConsumerConfiguration( String driverClass, String dbUrl,
			String dbUserName, String dbPassword,String productCode, String gdsEndpoint,Integer quartzStartUpDelay, String cronExpression, boolean proceedWithRemainingSameEvent) throws GDSConsumerException {
		this(driverClass, dbUrl, dbUserName, dbPassword,productCode,gdsEndpoint);
		this.cronExpression = cronExpression;
		this.quartzStartUpDelay = quartzStartUpDelay;
		this.proceedWithRemainingSameEvent = proceedWithRemainingSameEvent;

		if (checkIfNullNEmpty(driverClass) || checkIfNullNEmpty(dbUrl) || checkIfNullNEmpty(dbUserName)
				|| checkIfNullNEmpty(dbPassword) || quartzStartUpDelay == null || checkIfNullNEmpty(cronExpression) || checkIfNullNEmpty(productCode) || checkIfNullNEmpty(gdsEndpoint)) {
			throw new GDSConsumerException(GDSConsumerErrorEnum.GDS_CONSUMER_CONFIGURATION_FAILED.getText(),
					GDSConsumerErrorEnum.GDS_CONSUMER_CONFIGURATION_FAILED.getValue());
		}
	}

	public GDSConsumerConfiguration(String driverClass, String dbUrl, String dbUserName, String dbPassword,String productCode, String gdsEndPoint )
			throws GDSConsumerException {
		super();
		this.driverClass = driverClass;
		this.dbUrl = dbUrl;
		this.dbUserName = dbUserName;
		this.dbPassword = dbPassword;
		this.productCode = productCode;
		this.gdsEndPoint = gdsEndPoint;
		if (checkIfNullNEmpty(driverClass) || checkIfNullNEmpty(dbUrl) || checkIfNullNEmpty(dbUserName)
				|| checkIfNullNEmpty(dbPassword) || checkIfNullNEmpty(productCode) || checkIfNullNEmpty(gdsEndPoint)) {
			throw new GDSConsumerException(GDSConsumerErrorEnum.GDS_CONSUMER_CONFIGURATION_FAILED.getText(),
					GDSConsumerErrorEnum.GDS_CONSUMER_CONFIGURATION_FAILED.getValue());
		}
	}
	public GDSConsumerConfiguration(String driverClass, String dbUrl, String dbUserName, String dbPassword,String productCode, String gdsEndPoint,String quartzTablePrefix )
			throws GDSConsumerException {
		super();
		this.driverClass = driverClass;
		this.dbUrl = dbUrl;
		this.dbUserName = dbUserName;
		this.dbPassword = dbPassword;
		this.productCode = productCode;
		this.gdsEndPoint = gdsEndPoint;
		this.quartzTablePrefix = quartzTablePrefix;
		if (checkIfNullNEmpty(driverClass) || checkIfNullNEmpty(dbUrl) || checkIfNullNEmpty(dbUserName)
				|| checkIfNullNEmpty(dbPassword) || checkIfNullNEmpty(productCode) || checkIfNullNEmpty(gdsEndPoint) || checkIfNullNEmpty(quartzTablePrefix)) {
			throw new GDSConsumerException(GDSConsumerErrorEnum.GDS_CONSUMER_CONFIGURATION_FAILED.getText(),
					GDSConsumerErrorEnum.GDS_CONSUMER_CONFIGURATION_FAILED.getValue());
		}
	}
	
	public GDSConsumerConfiguration( String driverClass, String dbUrl,
			String dbUserName, String dbPassword,String productCode, String gdsEndpoint,String quartzTablePrefix,Integer quartzStartUpDelay, String cronExpression, boolean proceedWithRemainingSameEvent) throws GDSConsumerException {
		this(driverClass, dbUrl, dbUserName, dbPassword,productCode,gdsEndpoint,quartzTablePrefix);
		this.cronExpression = cronExpression;
		this.quartzStartUpDelay = quartzStartUpDelay;
		this.proceedWithRemainingSameEvent = proceedWithRemainingSameEvent;

		if (checkIfNullNEmpty(driverClass) || checkIfNullNEmpty(dbUrl) || checkIfNullNEmpty(dbUserName)
				|| checkIfNullNEmpty(dbPassword) || quartzStartUpDelay == null || checkIfNullNEmpty(cronExpression) || checkIfNullNEmpty(productCode) || checkIfNullNEmpty(gdsEndpoint)|| checkIfNullNEmpty(quartzTablePrefix)) {
			throw new GDSConsumerException(GDSConsumerErrorEnum.GDS_CONSUMER_CONFIGURATION_FAILED.getText(),
					GDSConsumerErrorEnum.GDS_CONSUMER_CONFIGURATION_FAILED.getValue());
		}
	}
	
	public GDSConsumerConfiguration( String driverClass, String dbUrl,
			String dbUserName, String dbPassword,String productCode, String gdsEndpoint,String quartzTablePrefix,Integer quartzStartUpDelay, String cronExpression, boolean proceedWithRemainingSameEvent,String threadCount) throws GDSConsumerException {
		this(driverClass, dbUrl, dbUserName, dbPassword,productCode,gdsEndpoint,quartzTablePrefix);
		this.cronExpression = cronExpression;
		this.quartzStartUpDelay = quartzStartUpDelay;
		this.proceedWithRemainingSameEvent = proceedWithRemainingSameEvent;
		this.threadCount = threadCount;

		if (checkIfNullNEmpty(driverClass) || checkIfNullNEmpty(dbUrl) || checkIfNullNEmpty(dbUserName)
				|| checkIfNullNEmpty(dbPassword) || quartzStartUpDelay == null || checkIfNullNEmpty(cronExpression) || checkIfNullNEmpty(productCode) || checkIfNullNEmpty(gdsEndpoint)|| checkIfNullNEmpty(quartzTablePrefix)||checkIfNullNEmpty(threadCount)) {
			throw new GDSConsumerException(GDSConsumerErrorEnum.GDS_CONSUMER_CONFIGURATION_FAILED.getText(),
					GDSConsumerErrorEnum.GDS_CONSUMER_CONFIGURATION_FAILED.getValue());
		}
	}
	
	// new configuration with datasource
	public GDSConsumerConfiguration(DataSource dataSource,String productCode, String gdsEndPoint,Integer quartzStartUpDelay, String cronExpression, boolean proceedWithRemainingSameEvent) throws GDSConsumerException {
		this(dataSource,productCode,gdsEndPoint);
		this.cronExpression = cronExpression;
		this.quartzStartUpDelay = quartzStartUpDelay;
		this.proceedWithRemainingSameEvent = proceedWithRemainingSameEvent;

		if (quartzStartUpDelay == null || checkIfNullNEmpty(cronExpression)) {
			throw new GDSConsumerException(GDSConsumerErrorEnum.GDS_CONSUMER_CONFIGURATION_FAILED.getText(),
					GDSConsumerErrorEnum.GDS_CONSUMER_CONFIGURATION_FAILED.getValue());
		}
	}

	public GDSConsumerConfiguration(DataSource dataSource,String productCode, String gdsEndPoint )
			throws GDSConsumerException {
		super();
		this.dataSource = dataSource;
		this.productCode = productCode;
		this.gdsEndPoint = gdsEndPoint;
		if (dataSource==null || checkIfNullNEmpty(productCode) || checkIfNullNEmpty(gdsEndPoint)) {
			throw new GDSConsumerException(GDSConsumerErrorEnum.GDS_CONSUMER_CONFIGURATION_FAILED.getText(),
					GDSConsumerErrorEnum.GDS_CONSUMER_CONFIGURATION_FAILED.getValue());
		}
	}
	public GDSConsumerConfiguration(DataSource dataSource,String productCode, String gdsEndPoint,String quartzTablePrefix )
			throws GDSConsumerException {
		this(dataSource,productCode,gdsEndPoint);
		this.quartzTablePrefix = quartzTablePrefix;
		if (checkIfNullNEmpty(quartzTablePrefix)) {
			throw new GDSConsumerException(GDSConsumerErrorEnum.GDS_CONSUMER_CONFIGURATION_FAILED.getText(),
					GDSConsumerErrorEnum.GDS_CONSUMER_CONFIGURATION_FAILED.getValue());
		}
	}
	
	public GDSConsumerConfiguration(DataSource dataSource,String productCode, String gdsEndpoint,String quartzTablePrefix,Integer quartzStartUpDelay, String cronExpression, boolean proceedWithRemainingSameEvent) throws GDSConsumerException {
		this(dataSource,productCode,gdsEndpoint,quartzTablePrefix);
		this.cronExpression = cronExpression;
		this.quartzStartUpDelay = quartzStartUpDelay;
		this.proceedWithRemainingSameEvent = proceedWithRemainingSameEvent;

		if (quartzStartUpDelay == null || checkIfNullNEmpty(cronExpression) || checkIfNullNEmpty(quartzTablePrefix)) {
			throw new GDSConsumerException(GDSConsumerErrorEnum.GDS_CONSUMER_CONFIGURATION_FAILED.getText(),
					GDSConsumerErrorEnum.GDS_CONSUMER_CONFIGURATION_FAILED.getValue());
		}
	}
	
	public GDSConsumerConfiguration( DataSource dataSource,String productCode, String gdsEndpoint,String quartzTablePrefix,Integer quartzStartUpDelay, String cronExpression, boolean proceedWithRemainingSameEvent,String threadCount) throws GDSConsumerException {
		this(dataSource,productCode,gdsEndpoint,quartzTablePrefix);
		this.cronExpression = cronExpression;
		this.quartzStartUpDelay = quartzStartUpDelay;
		this.proceedWithRemainingSameEvent = proceedWithRemainingSameEvent;
		this.threadCount = threadCount;

		if (quartzStartUpDelay == null || checkIfNullNEmpty(cronExpression)||checkIfNullNEmpty(threadCount)) {
			throw new GDSConsumerException(GDSConsumerErrorEnum.GDS_CONSUMER_CONFIGURATION_FAILED.getText(),
					GDSConsumerErrorEnum.GDS_CONSUMER_CONFIGURATION_FAILED.getValue());
		}
	}
	public void validateBean() throws GDSConsumerException {
		if (productCode == null || gdsEndPoint == null || (dataSource==null && (driverClass == null || dbUrl == null || dbUserName == null || dbPassword == null))) {
			throw new GDSConsumerException(GDSConsumerErrorEnum.GDS_CONSUMER_CONFIGURATION_FAILED.getText(),
					GDSConsumerErrorEnum.GDS_CONSUMER_CONFIGURATION_FAILED.getValue());
		}
	}

	public String getQuartzTablePrefix() {
		return quartzTablePrefix;
	}

	public String getThreadCount() {
		return threadCount;
	}

	public DataSource getDataSource() {
		return dataSource;
	}

}
