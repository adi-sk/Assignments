package com.zycus.guaranteed_delivery_consumer.dto;

import java.util.Date;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

public class GDSCConsumerRequest {

	@NotNull(message="Cannot be null or Empty")
	private long gdsProducerId; 
	
	@Size(min=1,max=256)
	@NotNull(message="Cannot be null or Empty")
	private String gdscId;
	
	private Date timeStamp;
	
	@NotNull(message="Cannot be null or Empty")
	private String sourceProductCode;
	
	private String addtionalInfo;
	
	@NotNull(message="Cannot be null or Empty")
	private String messageToDispatch;
	
	@NotNull(message="Cannot be null or Empty")
	private String messageType;
	
	@NotNull(message="Cannot be null or Empty")
	private Long deliveryId;
	
	@NotNull(message="Cannot be null or Empty")
	private EventInfo eventInfo;
	
	private String consumerProductCode;

	public long getGdsProducerId() {
		return gdsProducerId;
	}

	public void setGdsProducerId(long gdsProducerId) {
		this.gdsProducerId = gdsProducerId;
	}

	public String getGdscId() {
		return gdscId;
	}

	public void setGdscId(String gdscId) {
		this.gdscId = gdscId;
	}

	public Date getTimeStamp() {
		return timeStamp;
	}

	public void setTimeStamp(Date timeStamp) {
		this.timeStamp = timeStamp;
	}

	public String getSourceProductCode() {
		return sourceProductCode;
	}

	public void setSourceProductCode(String sourceProductCode) {
		this.sourceProductCode = sourceProductCode;
	}

	public String getAddtionalInfo() {
		return addtionalInfo;
	}

	public void setAddtionalInfo(String addtionalInfo) {
		this.addtionalInfo = addtionalInfo;
	}

	public String getMessageToDispatch() {
		return messageToDispatch;
	}

	public void setMessageToDispatch(String messageToDispatch) {
		this.messageToDispatch = messageToDispatch;
	}

	public String getMessageType() {
		return messageType;
	}

	public void setMessageType(String messageType) {
		this.messageType = messageType;
	}

	public Long getDeliveryId() {
		return deliveryId;
	}

	public void setDeliveryId(Long deliveryId) {
		this.deliveryId = deliveryId;
	}

	public EventInfo getEventInfo() {
		return eventInfo;
	}

	public void setEventInfo(EventInfo eventInfo) {
		this.eventInfo = eventInfo;
	}

	public String getConsumerProductCode() {
		return consumerProductCode;
	}

	public void setConsumerProductCode(String consumerProductCode) {
		this.consumerProductCode = consumerProductCode;
	}

}
