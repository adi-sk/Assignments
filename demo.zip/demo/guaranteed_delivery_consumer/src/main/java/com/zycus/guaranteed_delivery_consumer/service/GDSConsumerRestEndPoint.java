package com.zycus.guaranteed_delivery_consumer.service;

import com.zycus.guaranteed_delivery_consumer.Exception.GDSConsumerException;
import com.zycus.guaranteed_delivery_consumer.dto.GDSCConsumerRequest;
import com.zycus.guaranteed_delivery_consumer.dto.GDSConsumerSuccessResponse;

public interface GDSConsumerRestEndPoint {

	public GDSConsumerSuccessResponse updateCapturedEventData(GDSCConsumerRequest gdscRequest) throws GDSConsumerException;
	
}
