package com.zycus.guaranteed_delivery_consumer.dto;

import java.util.Date;

public class GDSConsumerSuccessResponse {

	private String gdsConsumerId;
	
	private Date timeStamp;

	private String duplicate;
	
	public String getGdsConsumerId() {
		return gdsConsumerId;
	}

	public void setGdsConsumerId(String gdsConsumerId) {
		this.gdsConsumerId = gdsConsumerId;
	}

	public Date getTimeStamp() {
		return timeStamp;
	}

	public void setTimeStamp(Date timeStamp) {
		this.timeStamp = timeStamp;
	}

	public String getDuplicate() {
		return duplicate;
	}

	public void setDuplicate(String duplicate) {
		this.duplicate = duplicate;
	}
	
}
