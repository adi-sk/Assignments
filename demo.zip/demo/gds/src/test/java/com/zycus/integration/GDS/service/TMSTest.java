/*package com.zycus.integration.GDS.service;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.context.SpringBootTest.WebEnvironment;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.transaction.annotation.Transactional;

import com.zycus.integration.GDS.exception.GDSCException;
import com.zycus.integration.GDS.util.GDSCUtil;

@RunWith(SpringRunner.class)
@SpringBootTest(webEnvironment = WebEnvironment.RANDOM_PORT)
@Transactional
public class TMSTest {

	@Test
	public void test1() throws GDSCException {
		System.out.println(GDSCUtil.getEndpointTMS("def68304-7e50-463c-95f5-7af9dcb4e600", "EINVOICE", "integration.api@zycus.com", "Pass@123"));
		//System.out.println(GDSCUtil.getEndpointTMS("def68304-7e50-463c-95f5-7af9dcb4e600", "EINVOICE", "eproc-api@zycus.com", "f53099db7a7a5a3a88a5ee295498863"));
	}
}
*/