package com.zycus.integration.GDS.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.zycus.integration.consul_service_discovery_client.ConsulServiceDiscoveryAgent;
import com.zycus.integration.consul_service_discovery_client.exception.ServiceNameNotFoundException;

public class ConsulServiceDiscoveryTest {

	public static void main(String[] args) throws JsonProcessingException {
		/*ObjectMapper mapper=new ObjectMapper();
		GDSPostBoxMessage gdsPostBoxMessage=new GDSPostBoxMessage();
		gdsPostBoxMessage.setDestinationId("EPROC");
		
		PostBoxMessage postBoxMessage=new PostBoxMessage();
		postBoxMessage.setConsumerId("TRYEYEY");
		gdsPostBoxMessage.setMessage(postBoxMessage);
		
		Error error=new Error("123","123","123");
		Errors errors=new Errors();
		List<Error> errorList=new ArrayList<>();
		errorList.add(error);
		errors.setError(errorList);
		gdsPostBoxMessage.setErrors(errors);
		
		System.out.println(mapper.writeValueAsString(gdsPostBoxMessage));*/
		String url;
		try {
			//url = ConsulServiceDiscoveryAgent.getServiceUrl("http://192.168.11.241:8500/v1/health/service", "sample-app", "f5313e86-25ab-4823-8760-3ff564544922", "fce3b8ff-bbc6-b913-214b-df91ebb61799");
			url = ConsulServiceDiscoveryAgent.getServiceUrl("http://192.168.11.241:8500/v1/health/service/", "einvoice-service", "def68304-7e50-463c-95f5-7af9dcb4e600", "fce3b8ff-bbc6-b913-214b-df91ebb61799");
			System.out.println(url);
		} catch (ServiceNameNotFoundException e) {
			e.printStackTrace();
		}
	}
	
	
}
