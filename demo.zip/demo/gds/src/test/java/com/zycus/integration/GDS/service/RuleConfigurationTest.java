package com.zycus.integration.GDS.service;

import java.io.IOException;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.zycus.integration.GDS.pojo.RuleData;
import com.zycus.integration.GDS.pojo.RuleDetails;

public class RuleConfigurationTest {

	public static void main(String[] args) {
		String str = "{\r\n" + 
				"	\"ruleData\": [\r\n" + 
				"		{\r\n" + 
				"			\"targetProductCode\": \"ICONSOLE\",\r\n" + 
				"			\"messageType\": \"TYPEA\",\r\n" + 
				"			\"isTMS\": false,\r\n" + 
				"			\"isConsulKey\": false,\r\n" + 
				"			\"url\": \"http://10.30.30.86:8082/producerconsumerAdoption\",\r\n" + 
				"			\"callBack\": \"http://10.30.30.86:8090\"\r\n" + 
				"		}\r\n" + 
				"	]\r\n" + 
				"}";

		ObjectMapper mapper = new ObjectMapper();
		try {
			RuleDetails ruleDetails = mapper.readValue(str, RuleDetails.class);
			for (RuleData ruleData : ruleDetails.getRuleData()) {
				System.out.println(ruleData.getMessageType());
				System.out.println(ruleData.getCallBack());
			}

		} catch (IOException e) {
			e.printStackTrace();
		}
	}

}
