package com.zycus.integration.GDS.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.zycus.integration.GDS.model.GDSErrorModel;

@Repository
public abstract interface GDSErrorModelRepository extends JpaRepository<GDSErrorModel , Long>{

	@Query("select j from GDSErrorModel j where j.postBoxId = :postBoxId ORDER BY j.errorId ASC")
	public List<GDSErrorModel> getAllErrorListOnPostBoxId(@Param("postBoxId") long postBoxId);

}
