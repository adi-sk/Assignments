package com.zycus.integration.GDS.pojo;

import java.util.List;

import javax.validation.constraints.NotNull;

import com.fasterxml.jackson.annotation.JsonRootName;

@JsonRootName("errors")
public class Errors {
	
	private boolean shouldRetry;
	
	@NotNull(message="Mandatory and Cannot be null or Empty")
	private List<Error> error;

	public List<Error> getError() {
		return error;
	}

	public void setError(List<Error> error) {
		this.error = error;
	}

	public boolean isShouldRetry() {
		return shouldRetry;
	}

	public void setShouldRetry(boolean shouldRetry) {
		this.shouldRetry = shouldRetry;
	}

}
