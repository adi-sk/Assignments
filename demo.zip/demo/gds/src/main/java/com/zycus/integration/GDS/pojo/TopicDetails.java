package com.zycus.integration.GDS.pojo;

import java.util.List;

public class TopicDetails {
	
	private List<TopicData> topicData;

	public List<TopicData> getTopicData() {
		return topicData;
	}

	public void setTopicData(List<TopicData> topicData) {
		this.topicData = topicData;
	}
	

}
