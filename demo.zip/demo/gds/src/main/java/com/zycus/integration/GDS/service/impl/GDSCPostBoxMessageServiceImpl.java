package com.zycus.integration.GDS.service.impl;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import javax.ws.rs.core.Response;

import org.apache.commons.lang.exception.ExceptionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.zycus.integration.GDS.constant.DeliveryTypeConstant;
import com.zycus.integration.GDS.constant.GDSRestResponseConstant;
import com.zycus.integration.GDS.enums.GDSCErrorEnum;
import com.zycus.integration.GDS.enums.GDSCPostBoxExecutionAtEnum;
import com.zycus.integration.GDS.enums.GDSCPostBoxStatus;
import com.zycus.integration.GDS.exception.GDSCException;
import com.zycus.integration.GDS.model.GDSErrorModel;
import com.zycus.integration.GDS.model.GDSPostBoxMessageModel;
import com.zycus.integration.GDS.model.RuleConfiguration;
import com.zycus.integration.GDS.pojo.Ack;
import com.zycus.integration.GDS.pojo.Error;
import com.zycus.integration.GDS.pojo.Errors;
import com.zycus.integration.GDS.pojo.GDSPostBoxMessage;
import com.zycus.integration.GDS.pojo.PostBoxMessage;
import com.zycus.integration.GDS.pojo.RuleData;
import com.zycus.integration.GDS.pojo.RuleDetails;
import com.zycus.integration.GDS.repository.GDSCPostBoxMessageRepository;
import com.zycus.integration.GDS.repository.GDSErrorModelRepository;
import com.zycus.integration.GDS.repository.RuleConfigurationRepository;
import com.zycus.integration.GDS.restClient.GDSCRestEndPoint;
import com.zycus.integration.GDS.service.GDSCPostBoxMessageService;
import com.zycus.integration.GDS.util.GDSCUtil;
import com.zycus.integration.GDS.util.JsonUtil;

@Service
public class GDSCPostBoxMessageServiceImpl implements GDSCPostBoxMessageService {

	private final Logger LOG = LoggerFactory.getLogger(this.getClass().getName());
	@Autowired
	private GDSCPostBoxMessageRepository gdscPostBoxMessageRepository;

	@Autowired
	private GDSErrorModelRepository gdsErrorModelRepository;

	@Autowired
	private RuleConfigurationRepository ruleConfigurationRepository;

	@Value(value = "${SERVICE_URL}")
	private String SERVICE_URL;

	@Value(value = "${ACL_TOKEN}")
	private String ACL_TOKEN;

	@Override
	public Ack capturePostBoxMessage(GDSPostBoxMessage message) throws GDSCException {
		PostBoxMessage pbmessage = message.getMessage();
		GDSPostBoxMessageModel duplicateModel = gdscPostBoxMessageRepository.getDuplicateData(pbmessage.getConsumerId(),
				pbmessage.getProducerId(), pbmessage.getGdscId());
		if (duplicateModel != null) {
			return successAck(duplicateModel);
		} else {
			GDSPostBoxMessageModel model = convertPostBoxPojoToModel(message);
			try {
				List<RuleConfiguration> rules = ruleConfigurationRepository.getRuleConfiguration(
						message.getGdsDestination(), message.getMessage().getEntityType(),
						message.getMessage().getEventType());
				if (rules.isEmpty()) {
					throw new GDSCException(GDSCErrorEnum.RULE_NOT_CONFIGURED.getValue(),
							GDSCErrorEnum.RULE_NOT_CONFIGURED.getText(), new Exception());
				} else {
					RuleConfiguration ruleConfig = rules.get(0);
					getEndpointbasedOnType(message, model, ruleConfig);
				}

			} catch (GDSCException e) {
				LOG.error("Unable to send to Producer, Due to {},", e);
				throw e;
			}
			return successAck(model);
		}
	}

	private void getEndpointbasedOnType(GDSPostBoxMessage message, GDSPostBoxMessageModel model,
			RuleConfiguration ruleConfig) {
		String type = message.getGdsMessageType();
		String endPoint = null;
		switch (type) {
		case DeliveryTypeConstant.GDS:
			endPoint = ruleConfig.getGdsEndPoint();
			break;
		case DeliveryTypeConstant.HTTP:
			endPoint = ruleConfig.getHttp();
			break;
		case DeliveryTypeConstant.QUEUE:
			endPoint = ruleConfig.getQueue();
			break;
		case DeliveryTypeConstant.TOPIC:
			endPoint = ruleConfig.getTopic();
			break;

		}
		if (endPoint != null) {
			gdscPostBoxMessageRepository.save(model);
			saveErrorInfo(message.getErrors(), model.getPostBoxId());
			try {
				fetchCallBackEndPoint(message, endPoint, model);
			} catch (GDSCException e) {
				updateErrorCodeAndDescription(model, e);
			}
		}
	}

	private void updateErrorCodeAndDescription(GDSPostBoxMessageModel model, GDSCException e) {
		model.setErrorCode(e.getErrorCode());
		model.setErrorDescription(e.getErrorMessage());
		model.setStacktrace(ExceptionUtils.getFullStackTrace(e));
		gdscPostBoxMessageRepository.save(model);
	}

	private Ack successAck(GDSPostBoxMessageModel model) {
		Ack ack = new Ack();
		ack.setStatus("SUCCESS");
		ack.setReferenceId(model.getConsumerId() + "*" + model.getGdscId() + "*" + model.getPostBoxId() + "");
		LOG.info(" Response : " + JsonUtil.serializeString(ack));
		return ack;
	}

	private void saveErrorInfo(Errors errors, long postBoxId) {
		List<GDSErrorModel> listError = new ArrayList<>();
		if (errors != null && errors.getError() != null && !errors.getError().isEmpty()) {
			for (Error error : errors.getError()) {
				listError.add(convertErrorToErrorModel(error, errors.isShouldRetry(), postBoxId));
			}
		}
		gdsErrorModelRepository.save(listError);
	}

	private GDSErrorModel convertErrorToErrorModel(Error error, boolean retry, long postBoxId) {
		GDSErrorModel model = new GDSErrorModel();
		model.setAction(error.getAction());
		model.setErrorCode(error.getErrorCode());
		model.setErrorDescription(error.getErrorDescription());
		model.setShouldRetry(retry);
		model.setStackTrace(error.getStackTrace());
		model.setPostBoxId(postBoxId);
		return model;
	}

	private GDSPostBoxMessageModel convertPostBoxPojoToModel(GDSPostBoxMessage message) {
		GDSPostBoxMessageModel model = new GDSPostBoxMessageModel();
		model.setGdsSource(message.getGdsSource());
		model.setGdsDestination(message.getGdsDestination());
		model.setGdsMessageType(message.getGdsMessageType());
		model.setSourceId(message.getSourceId());
		model.setDestinationId(message.getDestinationId());
		model.setExtraInfo(message.getExtraInfo());

		PostBoxMessage pbmessage = message.getMessage();
		model.setEventId(pbmessage.getEventId());
		model.setEntityId(pbmessage.getEntityId());
		model.setEventType(pbmessage.getEventType());
		model.setEntityType(pbmessage.getEntityType());
		model.setMessageType(pbmessage.getMessageType());
		model.setProductResponse(pbmessage.getProductResponse());
		model.setMsgExtraInfo(pbmessage.getExtraInfo());
		model.setConsumerId(pbmessage.getConsumerId());
		model.setProducerId(pbmessage.getProducerId());
		model.setExecutionAt(GDSCPostBoxExecutionAtEnum.CALL_BACK_FROM_CONSUMER.getValue());
		model.setStatus(GDSCPostBoxStatus.SUCCESS.getValue());
		model.setGdscId(pbmessage.getGdscId());
		model.setTenantId(pbmessage.getTenantId());
		return model;
	}

	private void callBackToProducer(GDSPostBoxMessage message, GDSPostBoxMessageModel model) throws GDSCException {

		// need to check code
		try {
			List<RuleConfiguration> rules = ruleConfigurationRepository.getRuleConfiguration(
					message.getGdsDestination(), message.getMessage().getEntityType(),
					message.getMessage().getEventType());
			if (rules.isEmpty()) {
				throw new GDSCException(GDSCErrorEnum.RULE_NOT_CONFIGURED.getValue(),
						GDSCErrorEnum.RULE_NOT_CONFIGURED.getText(), new Exception());
			} else {
				RuleConfiguration ruleConfig = rules.get(0);
				if (ruleConfig.getGdsEndPoint() != null) {
					fetchCallBackEndPoint(message, ruleConfig.getGdsEndPoint(), model);
				}
			}
		} catch (GDSCException e) {
			updateGDSPostBoxMessageModelStatusAndExecutionAt(model, GDSCPostBoxStatus.FAILED.getValue(),
					GDSCPostBoxExecutionAtEnum.CALL_BACK_TO_PRODUCER.getValue(), null);
			updateErrorCodeAndDescription(model, e);
		} catch (Exception e) {
			LOG.error(" Unable to send Producer due to {}", e);
		}
	}

	private void fetchCallBackEndPoint(GDSPostBoxMessage message, String endPoint, GDSPostBoxMessageModel model)
			throws GDSCException {
		String endPointUrl = null;
		RuleDetails ruleDetails = getRuleDetails(endPoint);
		int flag = 0;
		for (RuleData ruleData : ruleDetails.getRuleData()) {
			String messageTypes = ruleData.getMessageType();
			String[] messageType = messageTypes.split(",");
			List<String> types = Arrays.asList(messageType);
			if (ruleData.getTargetProductCode().equalsIgnoreCase(message.getDestinationId())
					&& (types.contains(message.getMessage().getMessageType()) || types.contains("ALL"))) {
				//endPointUrl = getCallBackUrl(model, ruleData);
				endPointUrl = ruleData.getCallBack();

				if (endPointUrl != null) {
					flag = 1;
					LOG.info("Producer Product Call Back url : " + endPointUrl);
					updateGDSPostBoxMessageModelStatusAndExecutionAt(model, GDSCPostBoxStatus.PROCESSING.getValue(),
							GDSCPostBoxExecutionAtEnum.CALL_BACK_TO_PRODUCER.getValue(), null);
					Response response = GDSCRestEndPoint.producerCallBack(message, endPointUrl);
					if (response.getStatus() == GDSRestResponseConstant.SUCCESS && response.getEntity() != null) {
						// check ack and check status if failed retry.
						updateGDSPostBoxMessageModelStatusAndExecutionAt(model, GDSCPostBoxStatus.SUCCESS.getValue(),
								GDSCPostBoxExecutionAtEnum.CALL_BACK_TO_PRODUCER.getValue(), response);
						LOG.info("Sent Consumer call back response to Producer for Event with Event Id - "
								+ model.getEventId() + " Successfully");
					} else {
						LOG.info("Failed to Send Consumer call back response to Producer for Event with Event Id - "
								+ model.getEventId() + " to CGDS!!!");
						updateGDSPostBoxErrorInfo(model, response);
					}
				} else {
					updateGDSPostBoxMessageModelStatusAndExecutionAt(model, GDSCPostBoxStatus.NOTSET.getValue(),
							GDSCPostBoxExecutionAtEnum.CALL_BACK_TO_PRODUCER.getValue(), null);
					// throw new
					// GDSCException(GDSCErrorEnum.CALL_BACK_URL_NOT_FOUND.getValue(),GDSCErrorEnum.CALL_BACK_URL_NOT_FOUND.getText(),
					// new Exception());
					flag = 1;
				}
			}
		}
		if (flag == 0) {
			updateGDSPostBoxMessageModelStatusAndExecutionAt(model, GDSCPostBoxStatus.FAILED.getValue(),
					GDSCPostBoxExecutionAtEnum.CALL_BACK_TO_PRODUCER.getValue(), null);
			throw new GDSCException(GDSCErrorEnum.CALL_BACK_URL_NOT_FOUND.getValue(),
					GDSCErrorEnum.CALL_BACK_URL_NOT_FOUND.getText(), new Exception());
		}
	}

	private void updateGDSPostBoxMessageModelStatusAndExecutionAt(GDSPostBoxMessageModel model, String status,
			String executionAt, Response response) {
		model.setStatus(status);
		model.setExecutionAt(executionAt);
		model.setProducerResponse(
				(response != null && response.getEntity() != null) ? response.getEntity().toString() : null);
		gdscPostBoxMessageRepository.save(model);
	}

	private void updateGDSPostBoxErrorInfo(GDSPostBoxMessageModel model, Response response) throws GDSCException {
		String errorCode = null;
		String errorDescription = null;
		if (response.getStatus() == GDSRestResponseConstant.SUCCESS && response.getEntity() == null) {
			errorCode = GDSCErrorEnum.ACK_FROM_CGDS_NULL.getValue();
			errorDescription = GDSCErrorEnum.ACK_FROM_CGDS_NULL.getText();
		} else if (response.getStatus() == 500) {
			errorCode = GDSCErrorEnum.INTERNAL_SERVER_ERROR.getValue();
			errorDescription = GDSCErrorEnum.INTERNAL_SERVER_ERROR.getText();
		} else if (response.getStatus() == GDSRestResponseConstant.SEND_CONNECTION_TIMEOUT) {
			errorCode = GDSCErrorEnum.REST_CONNECTION_TIMEOUT.getValue();
			errorDescription = GDSCErrorEnum.REST_CONNECTION_TIMEOUT.getText();
		} else if (response.getStatus() == GDSRestResponseConstant.OTHER_EXCEPTION) {
			errorCode = GDSCErrorEnum.REST_OTHER_EXCEPTION.getValue();
			errorDescription = GDSCErrorEnum.REST_OTHER_EXCEPTION.getText();
		}

		model.setStatus(GDSCPostBoxStatus.FAILED.getValue());
		model.setExecutionAt(GDSCPostBoxExecutionAtEnum.CALL_BACK_TO_PRODUCER.getValue());
		model.setProducerResponse(
				(response != null && response.getEntity() != null) ? response.getEntity().toString() : null);
		model.setErrorCode(errorCode);
		model.setErrorDescription(errorDescription);
		model.setStacktrace((response.getEntity() == null ? null : response.getEntity().toString()));
		model.setProducerResponse(
				(response != null && response.getEntity() != null) ? response.getEntity().toString() : null);
		gdscPostBoxMessageRepository.save(model);
	}

	private RuleDetails getRuleDetails(String ruleDetails) throws GDSCException {
		ObjectMapper mapper = new ObjectMapper();
		try {
			return mapper.readValue(ruleDetails, RuleDetails.class);
		} catch (Exception e) {
			throw new GDSCException(GDSCErrorEnum.RULE_CONFIGURATION_GDS_ENDPOINT_ERROR.getValue(),
					GDSCErrorEnum.RULE_CONFIGURATION_GDS_ENDPOINT_ERROR.getText(), new Exception());
		}
	}

	private String getCallBackUrl(GDSPostBoxMessageModel model, RuleData ruleData) throws GDSCException {
		String endPointUrl;
		if (ruleData.isUseServiceDiscoveryForProducerCallback()) {
			endPointUrl = GDSCUtil.getEndpointConsul(model.getTenantId(), model.getGdsDestination(), ACL_TOKEN,
					SERVICE_URL);
		} else {
			endPointUrl = ruleData.getUrl();
		}
		return endPointUrl;
	}

	@Override
	public void callBackToProducerScheduler() {
		// get all pending for call Back to producer
		LOG.info("Getting all pending call back events...");
		List<GDSPostBoxMessageModel> callBackData = gdscPostBoxMessageRepository.getGDSCGDSPostBoxMessageModel();
		for (GDSPostBoxMessageModel model : callBackData) {
			LOG.info("CallBack GDSCId : " + model.getGdscId());
			GDSPostBoxMessage message = convertPostBoxModelToPojo(model);
			try {
				List<GDSErrorModel> errorList = gdsErrorModelRepository
						.getAllErrorListOnPostBoxId(model.getPostBoxId());
				Errors errors = convertErrorModelToError(errorList);
				message.setErrors(errors);
				callBackToProducer(message, model);
			} catch (GDSCException e) {
				e.printStackTrace();
			}
		}
		LOG.info("End of call back events.");
	}

	private GDSPostBoxMessage convertPostBoxModelToPojo(GDSPostBoxMessageModel model) {
		GDSPostBoxMessage message = new GDSPostBoxMessage();
		message.setGdsSource(model.getGdsSource());
		message.setGdsDestination(model.getGdsDestination());
		message.setGdsMessageType(model.getGdsMessageType());
		message.setSourceId(model.getSourceId());
		message.setDestinationId(model.getDestinationId());
		message.setExtraInfo(model.getExtraInfo());

		PostBoxMessage pbmessage = new PostBoxMessage();
		pbmessage.setEventId(model.getEventId());
		pbmessage.setEntityId(model.getEntityId());
		pbmessage.setEventType(model.getEventType());
		pbmessage.setEntityType(model.getEntityType());
		pbmessage.setMessageType(model.getMessageType());
		pbmessage.setProductResponse(model.getProductResponse());
		pbmessage.setExtraInfo(model.getMsgExtraInfo());
		pbmessage.setConsumerId(model.getConsumerId());
		pbmessage.setProducerId(model.getProducerId());
		pbmessage.setGdscId(model.getGdscId());
		pbmessage.setTenantId(model.getTenantId());
		message.setMessage(pbmessage);
		return message;
	}

	private Errors convertErrorModelToError(List<GDSErrorModel> errorModelList) {
		List<Error> errorList = new ArrayList<>();
		for (GDSErrorModel errorModel : errorModelList) {
			Error error = new Error();
			error.setAction(errorModel.getAction());
			error.setErrorCode(errorModel.getErrorCode());
			error.setErrorDescription(errorModel.getErrorDescription());
			error.setStackTrace(errorModel.getStackTrace());
			errorList.add(error);
		}
		if (errorList.isEmpty() && errorList.size() == 0) {
			return null;
		} else {
			Errors errors = new Errors();
			errors.setShouldRetry(false);
			errors.setError(errorList);
			return errors;
		}

	}

}
