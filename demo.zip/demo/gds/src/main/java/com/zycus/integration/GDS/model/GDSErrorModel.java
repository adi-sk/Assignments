package com.zycus.integration.GDS.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name = "GDS_POST_BOX_ERROR")
@SequenceGenerator(name = "GDS_PBERROR_SEQ", sequenceName = "GDS_PBERROR_SEQ", initialValue = 1, allocationSize = 1)
public class GDSErrorModel {

	@Id
	@Column(name = "ID")
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "GDS_PBERROR_SEQ")
	private long errorId;
	
	@Column(name = "RETRY")
	private boolean shouldRetry;

	@Column(name = "POST_BOX_ID")
	private long postBoxId;
	
	@Column(name = "ERROR_CODE")
	private String errorCode;
	
	@Column(name = "ERROR_DESCRIPTION")
	private String errorDescription;

	@Column(name = "ACTION")
	private String action;
	
	@Column(name = "STACKS_TRACE")
	private String stackTrace;

	public long getErrorId() {
		return errorId;
	}

	public void setErrorId(long errorId) {
		this.errorId = errorId;
	}

	public boolean isShouldRetry() {
		return shouldRetry;
	}

	public void setShouldRetry(boolean shouldRetry) {
		this.shouldRetry = shouldRetry;
	}

	public String getErrorCode() {
		return errorCode;
	}

	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}

	public String getErrorDescription() {
		return errorDescription;
	}

	public void setErrorDescription(String errorDescription) {
		this.errorDescription = errorDescription;
	}

	public String getAction() {
		return action;
	}

	public void setAction(String action) {
		this.action = action;
	}

	public String getStackTrace() {
		return stackTrace;
	}

	public void setStackTrace(String stackTrace) {
		this.stackTrace = stackTrace;
	}

	public long getPostBoxId() {
		return postBoxId;
	}

	public void setPostBoxId(long postBoxId) {
		this.postBoxId = postBoxId;
	}
	
}
