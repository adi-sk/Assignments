package com.zycus.integration.GDS.pojo;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonRootName;

@JsonRootName("acknowledge")
public class Acknowledge {
	
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private Long timeStamp;
	
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private String gdscId;
	
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private String errorCode;
	
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private String errorDescription;
	
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private String stackTrace;

	public Long getTimeStamp() {
		return timeStamp;
	}

	public void setTimeStamp(Long timeStamp) {
		this.timeStamp = timeStamp;
	}

	public String getGdscId() {
		return gdscId;
	}

	public void setGdscId(String gdscId) {
		this.gdscId = gdscId;
	}

	public String getErrorCode() {
		return errorCode;
	}

	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}

	public String getStackTrace() {
		return stackTrace;
	}

	public void setStackTrace(String stackTrace) {
		this.stackTrace = stackTrace;
	}

	public String getErrorDescription() {
		return errorDescription;
	}

	public void setErrorDescription(String errorDescription) {
		this.errorDescription = errorDescription;
	}
	
}
