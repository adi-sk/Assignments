package com.zycus.integration.GDS.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.zycus.integration.GDS.model.RuleConfiguration;


@Repository
public abstract interface RuleConfigurationRepository extends JpaRepository<RuleConfiguration, Long> {

	@Query("select r from RuleConfiguration r where r.sourceProduct= :productCode and r.entity = :entity and r.event LIKE  %:event%")
	public abstract List<RuleConfiguration> getRuleConfiguration(@Param("productCode") String productCode, @Param("entity") String entity,@Param("event") String event);
	
}
