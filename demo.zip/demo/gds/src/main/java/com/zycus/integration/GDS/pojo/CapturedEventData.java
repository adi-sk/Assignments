
package com.zycus.integration.GDS.pojo;

import java.util.List;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;

/**
 *punit.sukhija
 *
 */
public class CapturedEventData {

	@NotNull(message="Mandatory and Cannot be null or Empty")
	private EventInfo eventInfo;
	
	@Valid
	@NotNull(message="Mandatory and Cannot be null or Empty")
	private List<MessageSet> messageSet;
	
	public EventInfo getEventInfo() {
		return eventInfo;
	}
	public void setEventInfo(EventInfo eventInfo) {
		this.eventInfo = eventInfo;
	}
	public List<MessageSet> getMessageSet() {
		return messageSet;
	}
	public void setMessageSet(List<MessageSet> messageSet) {
		this.messageSet = messageSet;
	}
	

}
