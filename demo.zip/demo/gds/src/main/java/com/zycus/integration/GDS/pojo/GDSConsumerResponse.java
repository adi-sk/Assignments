
package com.zycus.integration.GDS.pojo;

import com.fasterxml.jackson.annotation.JsonInclude;

/**
 *punit.sukhija
 *
 */
public class GDSConsumerResponse {
	
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private String gdsConsumerId;
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private Long timeStamp;
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private String errorCode;
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private String duplicate;
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private String executionAt;
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private String stackTrace;
	
	public String getGdsConsumerId() {
		return gdsConsumerId;
	}
	public void setGdsConsumerId(String gdsConsumerId) {
		this.gdsConsumerId = gdsConsumerId;
	}
	public Long getTimeStamp() {
		return timeStamp;
	}
	public void setTimeStamp(Long timeStamp) {
		this.timeStamp = timeStamp;
	}
	public String getErrorCode() {
		return errorCode;
	}
	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}
	public String getExecutionAt() {
		return executionAt;
	}
	public void setExecutionAt(String executionAt) {
		this.executionAt = executionAt;
	}
	public String getStackTrace() {
		return stackTrace;
	}
	public void setStackTrace(String stackTrace) {
		this.stackTrace = stackTrace;
	}
	public String getDuplicate() {
		return duplicate;
	}
	public void setDuplicate(String duplicate) {
		this.duplicate = duplicate;
	}

}
