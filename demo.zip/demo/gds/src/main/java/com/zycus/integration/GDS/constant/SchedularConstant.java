package com.zycus.integration.GDS.constant;

public interface SchedularConstant {

	String SCHEDULER_NAME="CGDS_SCHEDULER";
	
	String SCHEDULER_GROUP = "CGDS";
	
	String SCHEDULER_JOB_NAME="CGDS_JOB";
	
	String SCHEDULER_TRIGGER_NAME="CGDS_JOB_TRIGGER";

	String INSTANCENAME = "CGDS";

	String INSTANCEID = "CGDSID";

	String THREADCOUNT = "5";

	String JOBSTORECLASS = "org.quartz.simpl.RAMJobStore";
	
	String QUARTZClASS = "org.quartz.impl.jdbcjobstore.JobStoreTX";
	
	String DRIVERDELEGATECLASS = "org.quartz.impl.jdbcjobstore.StdJDBCDelegate";
	
	String TABLEPREFIX = "QRTZ_";
	
	String ISCLUSTERED = "true";
	
	String DATASOURCE = "myDS";
	
	String MISFIRETHRESHOLD = "25000";
	
	String MAXCONNECTIONS = "5";
	
	String VALIDATIONQUERY = "select 1";
	
	String SELECTWITHLOCKSQL = "SELECT * FROM {0}LOCKS UPDLOCK WHERE LOCK_NAME = ?";

	int QUARTZ_STARTUP_DELAY = 10;
}
