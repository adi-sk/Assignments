package com.zycus.integration.GDS.pojo;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonRootName;

@JsonRootName("dataPacket")
public class GDSProducerRequest {

	@NotNull(message="Mandatory and Cannot be null or Empty")
	private Long id;
	
	@NotNull(message="Mandatory and Cannot be null or Empty")
	private Long timeStamp;
	
	@Size(min=1,max=50)
	@NotNull(message="Mandatory and Cannot be null or Empty")
	private String productCode;
	
	private String additionalInfo;
	private String status;
	private String executionAt;
	private String deliveryStatus;
	
	@JsonInclude(Include.NON_NULL)
	private String errorCode;
	
	@JsonInclude(Include.NON_NULL)
	private String errorDescription;
	
	@NotNull(message="Mandatory and Cannot be null or Empty")
	private CapturedEventData capturedEventData;
	
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public Long getTimeStamp() {
		return timeStamp;
	}
	public void setTimeStamp(Long timeStamp) {
		this.timeStamp = timeStamp;
	}
	public String getProductCode() {
		return productCode;
	}
	public void setProductCode(String productCode) {
		this.productCode = productCode;
	}
	public String getAdditionalInfo() {
		return additionalInfo;
	}
	public void setAdditionalInfo(String additionalInfo) {
		this.additionalInfo = additionalInfo;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getExecutionAt() {
		return executionAt;
	}
	public void setExecutionAt(String executionAt) {
		this.executionAt = executionAt;
	}
	public String getDeliveryStatus() {
		return deliveryStatus;
	}
	public void setDeliveryStatus(String deliveryStatus) {
		this.deliveryStatus = deliveryStatus;
	}
	public String getErrorCode() {
		return errorCode;
	}
	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}
	public String getErrorDescription() {
		return errorDescription;
	}
	public void setErrorDescription(String errorDescription) {
		this.errorDescription = errorDescription;
	}
	public CapturedEventData getCapturedEventData() {
		return capturedEventData;
	}
	public void setCapturedEventData(CapturedEventData capturedEventData) {
		this.capturedEventData = capturedEventData;
	}
	
}