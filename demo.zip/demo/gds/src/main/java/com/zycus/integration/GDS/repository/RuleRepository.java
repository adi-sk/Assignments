
package com.zycus.integration.GDS.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.zycus.integration.GDS.model.Rule;

/**
 * punit.sukhija
 *
 */
@Repository
public abstract interface RuleRepository extends JpaRepository<Rule, Long> {

	@Query("select r from Rule r where r.productCode= :productCode and r.entity = :entity and r.event LIKE  %:event%")
	public abstract List<Rule> getRule(@Param("productCode") String productCode, @Param("entity") String entity,
			@Param("event") String event);

}
