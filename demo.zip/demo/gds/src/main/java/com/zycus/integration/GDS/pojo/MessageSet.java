package com.zycus.integration.GDS.pojo;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

public class MessageSet {
	
	@Size(max=50)
	@NotNull(message="Mandatory and Cannot be null or Empty")
	private String type;
	
	@NotNull(message="Mandatory and Cannot be null or Empty")
	private String data;
	
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public String getData() {
		return data;
	}
	public void setData(String data) {
		this.data = data;
	}
}
