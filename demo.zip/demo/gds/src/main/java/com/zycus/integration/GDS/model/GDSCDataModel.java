
package com.zycus.integration.GDS.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.UniqueConstraint;

/**
 *punit.sukhija
 *
 */
@Entity
@Table(name = "GDSC_DATA_MODEL", uniqueConstraints=@UniqueConstraint(columnNames={"GDS_PRODUCER_ID", "ENTITY_ID","ENTITY_TYPE"}))
@SequenceGenerator(name = "GDSC_DATA_MODEL_SEQ", sequenceName = "GDSC_DATA_MODEL_SEQ", initialValue = 1, allocationSize = 1)
public class GDSCDataModel {
	
	private Long id;
	private String tenantId;
	private String gdscId;
	private Long gdsProducerId;
	private String businessRefId;
	private String sourceProductCode;
	private String entityId;
	private String entityType;
	private String eventId;
	private Long eventInfoId;
	private String eventType;
	private String version;
	private String extraInfo;
	private Date gdsTimestamp;
	private String receivedData;
	private String status;
	private String producerExecutionAt;
	private String producerErrorCode;
	private String producerErrorDescription;
	
	
	@Id
	@Column(name = "ID")
	 @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "GDSC_DATA_MODEL_SEQ")
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	
	@Column(name = "TENANT_ID")
	public String getTenantId() {
		return tenantId;
	}
	public void setTenantId(String tenantId) {
		this.tenantId = tenantId;
	}
	
	@Column(name = "GDSC_ID")
	public String getGdscId() {
		return gdscId;
	}
	public void setGdscId(String gdscId) {
		this.gdscId = gdscId;
	}
	
	@Column(name = "GDS_PRODUCER_ID")
	public Long getGdsProducerId() {
		return gdsProducerId;
	}
	public void setGdsProducerId(Long gdsProductId) {
		this.gdsProducerId = gdsProductId;
	}
	
	@Column(name = "BUSINESS_REF_ID")
	public String getBusinessRefId() {
		return businessRefId;
	}
	public void setBusinessRefId(String businessRefId) {
		this.businessRefId = businessRefId;
	}
	
	@Column(name = "SOURCE_PRODUCT_CODE")
	public String getSourceProductCode() {
		return sourceProductCode;
	}
	public void setSourceProductCode(String sourceProductCode) {
		this.sourceProductCode = sourceProductCode;
	}
	
	@Column(name = "ENTITY_ID")
	public String getEntityId() {
		return entityId;
	}
	public void setEntityId(String entityId) {
		this.entityId = entityId;
	}
	
	@Column(name = "ENTITY_TYPE")
	public String getEntityType() {
		return entityType;
	}
	public void setEntityType(String entityType) {
		this.entityType = entityType;
	}
	
	@Column(name = "EVENT_ID")
	public String getEventId() {
		return eventId;
	}
	public void setEventId(String eventId) {
		this.eventId = eventId;
	}
	
	@Column(name = "EVENT_TYPE")
	public String getEventType() {
		return eventType;
	}
	public void setEventType(String eventType) {
		this.eventType = eventType;
	}
	
	@Column(name = "VERSION")
	public String getVersion() {
		return version;
	}
	public void setVersion(String version) {
		this.version = version;
	}
	
	@Lob
	@Column(name = "EXTRA_INFO")
	public String getExtraInfo() {
		return extraInfo;
	}
	public void setExtraInfo(String extraInfo) {
		this.extraInfo = extraInfo;
	}
	
	@Column(name = "GDS_TIMESTAMP")
	@Temporal(TemporalType.TIMESTAMP)
	public Date getGdsTimestamp() {
		return gdsTimestamp;
	}
	public void setGdsTimestamp(Date gdsTimestamp) {
		this.gdsTimestamp = gdsTimestamp;
	}
	
	@Column(name = "RECEIVED_DATA")
	public String getReceivedData() {
		return receivedData;
	}
	public void setReceivedData(String receivedData) {
		this.receivedData = receivedData;
	}
	
	@Column(name = "STATUS")
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	
	@Column(name = "PRODUCER_EXECUTION_AT")
	public String getProducerExecutionAt() {
		return producerExecutionAt;
	}
	public void setProducerExecutionAt(String producerExecutionAt) {
		this.producerExecutionAt = producerExecutionAt;
	}
	
	@Column(name = "PRODUCER_ERROR_CODE")
	public String getProducerErrorCode() {
		return producerErrorCode;
	}
	public void setProducerErrorCode(String producerErrorCode) {
		this.producerErrorCode = producerErrorCode;
	}
	
	@Column(name = "PRODUCER_ERROR_DESCRIPTION")
	public String getProducerErrorDescription() {
		return producerErrorDescription;
	}
	public void setProducerErrorDescription(String producerErrorDescription) {
		this.producerErrorDescription = producerErrorDescription;
	}
	
	@Column(name = "EVENT_INFO_ID")
	public Long getEventInfoId() {
		return eventInfoId;
	}
	public void setEventInfoId(Long eventInfoId) {
		this.eventInfoId = eventInfoId;
	}
}
