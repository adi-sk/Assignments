package com.zycus.integration.GDS.util;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import javax.validation.ConstraintViolation;
import javax.validation.Path;
import javax.validation.Validation;
import javax.validation.Validator;
import javax.validation.ValidatorFactory;

import com.zycus.integration.GDS.pojo.CapturedEventData;
import com.zycus.integration.GDS.pojo.Error;
import com.zycus.integration.GDS.pojo.Errors;
import com.zycus.integration.GDS.pojo.EventInfo;
import com.zycus.integration.GDS.pojo.GDSPostBoxMessage;
import com.zycus.integration.GDS.pojo.GDSProducerRequest;
import com.zycus.integration.GDS.pojo.MessageSet;
import com.zycus.integration.GDS.pojo.PostBoxMessage;

/**
 * Validate's EventInfo Object
 * @author narendra.m
 *
 */
public class GDSProducerRequestValidator {
	/**
	 * Validate EventInfo Object
	 * @param eventInfo
	 * @return
	 */
	public static List<String> validateEventInfo(GDSProducerRequest gdsProducerRequest) {

		ValidatorFactory validatorFactory = Validation.buildDefaultValidatorFactory();
		Validator validator = validatorFactory.getValidator();
		Set<ConstraintViolation<GDSProducerRequest>> violations = validator.validate(gdsProducerRequest);
		List<String> errorList=new ArrayList<>();
		for (ConstraintViolation<GDSProducerRequest> violation : violations)
		{
			String message = violation.getMessage();
			Path field = violation.getPropertyPath();
			Class<GDSProducerRequest> rootBeanClass=violation.getRootBeanClass();
			errorList.add(rootBeanClass+ " : ("+ field +" : "+ message + ")");
		}
		CapturedEventData capturedEventData = gdsProducerRequest.getCapturedEventData();
		if(capturedEventData!=null) {
			Set<ConstraintViolation<CapturedEventData>> capturedEventDataViolations = validator.validate(capturedEventData);
			for (ConstraintViolation<CapturedEventData> violation : capturedEventDataViolations)
			{
				String message = violation.getMessage();
				Path field = violation.getPropertyPath();
				Class<CapturedEventData> rootBeanClass=violation.getRootBeanClass();
				errorList.add(rootBeanClass+ " : ("+ field +" : "+ message + ")");
			}
			EventInfo eventInfo=capturedEventData.getEventInfo();
			if(eventInfo!=null) {
				Set<ConstraintViolation<EventInfo>> eventInfoViolations = validator.validate(eventInfo);
				for (ConstraintViolation<EventInfo> violation : eventInfoViolations)
				{
					String message = violation.getMessage();
					Path field = violation.getPropertyPath();
					Class<EventInfo> rootBeanClass=violation.getRootBeanClass();
					errorList.add(rootBeanClass+ " : ("+ field +" : "+ message + ")");
				}
			}
			List<MessageSet> messageSets=capturedEventData.getMessageSet();
			if(messageSets.isEmpty() && messageSets.size()==0 ) {
				errorList.add("MessageSet : Cannot be empty");
			}
			if(messageSets!=null) {
				Set<ConstraintViolation<List<MessageSet>>> eventInfoViolations = validator.validate(messageSets);
				for (ConstraintViolation<List<MessageSet>> violation : eventInfoViolations)
				{
					String message = violation.getMessage();
					Path field = violation.getPropertyPath();
					Class<List<MessageSet>> rootBeanClass=violation.getRootBeanClass();
					errorList.add(rootBeanClass+ " : ("+ field +" : "+ message + ")");
				}
			}
		}
		
		
		return errorList;
	}

	public static List<String> validatePostBoxMessage(GDSPostBoxMessage postBoxMessage) {
		ValidatorFactory validatorFactory = Validation.buildDefaultValidatorFactory();
		Validator validator = validatorFactory.getValidator();
		List<String> errorList=new ArrayList<>();
		Set<ConstraintViolation<GDSPostBoxMessage>> violations = validator.validate(postBoxMessage);
		for (ConstraintViolation<GDSPostBoxMessage> violation : violations)
		{
			String message = violation.getMessage();
			Path field = violation.getPropertyPath();
			Class<GDSPostBoxMessage> rootBeanClass=violation.getRootBeanClass();
			errorList.add(rootBeanClass+ " : ("+ field +" : "+ message + ")");
		}
		
		PostBoxMessage pbMessage=postBoxMessage.getMessage();
		if(pbMessage !=null) {
			Set<ConstraintViolation<PostBoxMessage>> postBoxMsgViolations = validator.validate(pbMessage);
			for (ConstraintViolation<PostBoxMessage> violation : postBoxMsgViolations)
			{
				String message = violation.getMessage();
				Path field = violation.getPropertyPath();
				Class<PostBoxMessage> rootBeanClass=violation.getRootBeanClass();
				errorList.add(rootBeanClass+ " : ("+ field +" : "+ message + ")");
			}
		}
		
		Errors errors=postBoxMessage.getErrors();
		if(errors!=null) {
			Set<ConstraintViolation<Errors>> errorsViolations = validator.validate(errors);
			for (ConstraintViolation<Errors> violation : errorsViolations)
			{
				String message = violation.getMessage();
				Path field = violation.getPropertyPath();
				Class<Errors> rootBeanClass=violation.getRootBeanClass();
				errorList.add(rootBeanClass+ " : ("+ field +" : "+ message + ")");
			}
			List<Error> error=errors.getError();
			Set<ConstraintViolation<List<Error>>> errorViolations = validator.validate(error);
			for (ConstraintViolation<List<Error>> violation : errorViolations)
			{
				String message = violation.getMessage();
				Path field = violation.getPropertyPath();
				Class<List<Error>> rootBeanClass=violation.getRootBeanClass();
				errorList.add(rootBeanClass+ " : ("+ field +" : "+ message + ")");
			}
			
		}
		return errorList;
	}
}
