package com.zycus.integration.GDS.service;

import com.zycus.integration.GDS.exception.GDSCException;
import com.zycus.integration.GDS.pojo.Ack;
import com.zycus.integration.GDS.pojo.GDSPostBoxMessage;

public interface GDSCPostBoxMessageService {

	public Ack capturePostBoxMessage(GDSPostBoxMessage postBoxMessage)throws GDSCException;
	
	public void callBackToProducerScheduler();
}
