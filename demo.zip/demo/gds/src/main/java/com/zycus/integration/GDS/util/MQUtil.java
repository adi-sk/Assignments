
package com.zycus.integration.GDS.util;

import java.io.Serializable;

import javax.jms.Connection;
import javax.jms.DeliveryMode;
import javax.jms.Destination;
import javax.jms.MessageProducer;
import javax.jms.Session;
import javax.jms.TextMessage;

import org.apache.activemq.ActiveMQConnectionFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.zycus.integration.GDS.enums.GDSCErrorEnum;
import com.zycus.integration.GDS.exception.GDSCException;

/**
 *punit.sukhija
 *
 */
public class MQUtil {
	
	private static final Logger LOG = LoggerFactory.getLogger(GDSCUtil.class);
	public static void sendObjectMessage(String mqUrl, String queueName, boolean isTopic, Serializable payload, String clientId) throws GDSCException{
		try {
			// Create a ConnectionFactory
			ActiveMQConnectionFactory connectionFactory = new ActiveMQConnectionFactory(mqUrl);
			connectionFactory.setCloseTimeout(10000);
			// Create a Connection
			Connection connection = connectionFactory.createConnection();
			if (clientId != null) {
				connection.setClientID(clientId);
			}
			connection.start();

			// Create a Session
			Session session = connection.createSession(false, Session.AUTO_ACKNOWLEDGE);

			// Create the destination (Topic or Queue)
			Destination destination = null;
			if (isTopic) {
				LOG.info("Sending data to topic - " + queueName);
				destination = session.createTopic(queueName);
			} else {
				LOG.info("Sending data to queue - " + queueName);
				destination = session.createQueue(queueName);
			}

			// Create a MessageProducer from the Session to the Topic or Queue
			MessageProducer producer = session.createProducer(destination);
			producer.setDeliveryMode(DeliveryMode.NON_PERSISTENT);

			
			//byte[] payloadByte = getBytes(payload);
			// Create a messages
			//ObjectMessage message = session.createObjectMessage();
			//message.setObject(payload);

			TextMessage message = session.createTextMessage();
			message.setText(payload.toString());
			
			// Tell the producer to send the message
			producer.send(message);

			// Clean up
			session.close();
			connection.close();
		} catch (Exception e) {
			LOG.error("Unable to send via JMS : {} " + e);
			throw new GDSCException(GDSCErrorEnum.UNABLE_TO_SEND_VIA_ACTIVE_MQ.getValue(),GDSCErrorEnum.UNABLE_TO_SEND_VIA_ACTIVE_MQ.getText(),e);
		}
	}

}
