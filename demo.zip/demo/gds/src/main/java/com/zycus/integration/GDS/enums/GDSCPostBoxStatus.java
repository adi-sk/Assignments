package com.zycus.integration.GDS.enums;

public enum GDSCPostBoxStatus {
	SUCCESS("SUCCESS"),
	FAILED("FAILED"),
	NOTSET("NOTSET"),
	PROCESSING("PROCESSING");
	
	private String value;
	
	private GDSCPostBoxStatus(String value){
		this.value = value;
		
	}

	public String getValue() {
		return value;
	}
}
