
package com.zycus.integration.GDS.service.impl;

import java.io.IOException;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;

import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.Entity;
import javax.ws.rs.client.Invocation.Builder;
import javax.ws.rs.client.WebTarget;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.hibernate.exception.ConstraintViolationException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.env.Environment;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.client.RestTemplate;

import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.zycus.integration.GDS.constant.DeliveryTypeConstant;
import com.zycus.integration.GDS.enums.ErrorEnums;
import com.zycus.integration.GDS.enums.GDSCErrorEnum;
import com.zycus.integration.GDS.enums.GDSCStatus;
import com.zycus.integration.GDS.exception.GDSCException;
import com.zycus.integration.GDS.model.GDSCDataModel;
import com.zycus.integration.GDS.model.GDSCDeliveryDataModel;
import com.zycus.integration.GDS.model.RuleConfiguration;
import com.zycus.integration.GDS.pojo.Acknowledge;
import com.zycus.integration.GDS.pojo.EventInfo;
import com.zycus.integration.GDS.pojo.GDSConsumerRequest;
import com.zycus.integration.GDS.pojo.GDSConsumerResponse;
import com.zycus.integration.GDS.pojo.GDSPostBoxMessage;
import com.zycus.integration.GDS.pojo.GDSProducerRequest;
import com.zycus.integration.GDS.pojo.MessageSet;
import com.zycus.integration.GDS.pojo.PostBoxMessage;
import com.zycus.integration.GDS.pojo.QueueData;
import com.zycus.integration.GDS.pojo.QueueDetails;
import com.zycus.integration.GDS.pojo.RuleData;
import com.zycus.integration.GDS.pojo.RuleDetails;
import com.zycus.integration.GDS.pojo.TopicData;
import com.zycus.integration.GDS.pojo.TopicDetails;
import com.zycus.integration.GDS.repository.GDSCDataModelRepository;
import com.zycus.integration.GDS.repository.GDSCDeliveryDataRepository;
import com.zycus.integration.GDS.repository.RuleConfigurationRepository;
import com.zycus.integration.GDS.service.GDSCPostBoxMessageService;
import com.zycus.integration.GDS.service.GDSCService;
import com.zycus.integration.GDS.util.GDSCUtil;
import com.zycus.integration.GDS.util.JsonUtil;
import com.zycus.integration.GDS.util.MQUtil;

/**
 * punit.sukhija
 *
 */
@Service
public class GDSCServiceImpl implements GDSCService {

	@Autowired
	private RuleConfigurationRepository ruleConfigurationRepository;

	@Autowired
	private GDSCDeliveryDataRepository deliveryRepo;

	@Autowired
	private GDSCDataModelRepository dataModelRepo;

	@Autowired
	private GDSCPostBoxMessageService gdscPostBoxMessageService;

	@Value(value = "${TMS_AUTH_USERNAME}")
	private String TMS_USERNAME;

	@Value(value = "${TMS_AUTH_PASSWORD}")
	private String TMS_PASSWORD;

	@Value(value = "${SERVICE_URL}")
	private String SERVICE_URL;

	@Value(value = "${ACL_TOKEN}")
	private String ACL_TOKEN;

	@Autowired
	private Environment environment;

	private static final Logger LOG = LoggerFactory.getLogger(GDSCServiceImpl.class);

	/**
	 * Captures the Producer Request and divides into individual Packets
	 */
	@Override
	public Acknowledge captureEventData(GDSProducerRequest gdsProducerRequest) throws GDSCException {

		try {
			// Checking for duplicate record in db....
			GDSCDataModel gdscDataModel = getDuplicateGDSProducerRequest(gdsProducerRequest.getId(),
					gdsProducerRequest.getProductCode());

			if (gdsProducerRequest.getCapturedEventData() == null
					|| gdsProducerRequest.getCapturedEventData().getEventInfo() == null
					|| gdsProducerRequest.getCapturedEventData().getMessageSet() == null) {
				// work with null data in request
				LOG.info("Null Data received in Producer Request");
				return workWithNullRequest(gdsProducerRequest, gdscDataModel);
			}

			if (gdscDataModel != null) {
				// work with duplicate data in request
				LOG.info("Duplicate Producer Request Received");
				return workWithDuplicateEntry(gdsProducerRequest, gdscDataModel);
			} else {
				// work with Non duplicate data in request
				LOG.info("Processing New Producer Request");
				return workWithNonDuplicateEntry(gdsProducerRequest);

			}

		} catch (GDSCException e) {
			LOG.info("Unable to save event due to {}", e);
			throw e;
		}
	}

	/**
	 * Processes all the Pending Delivery Packets
	 */
	@Override
	public void processCGDSPendingDeliveryData() {

		// getPending Request from GDSCDeliveryDataModel
		LOG.info("Fetching GDSCDeliveryDataModels...");
		List<GDSCDeliveryDataModel> deliveryDataModels = getGDSPendingDeliveryDataModels();

		if (deliveryDataModels.isEmpty()) {
			LOG.info("No Pending GDS delivery Packets found");
			return;
		}
		Map<String, List<GDSCDeliveryDataModel>> chunks = new HashMap<String, List<GDSCDeliveryDataModel>>();
		LinkedHashSet<String> keyOrders = new LinkedHashSet<>();
		createChunks(deliveryDataModels, chunks, keyOrders);
		for (String keyOrder : keyOrders) {
			for (GDSCDeliveryDataModel deliveryModel : chunks.get(keyOrder)) {
				try {
					LOG.info("CGDS->CONSUMER GDSCID : " + deliveryModel.getGdscId());
					LOG.info("Sending GDS Data from " + deliveryModel.getSourceProductCode() + "  ----->  "
							+ deliveryModel.getConsumerProductCode());

					String endPoint = fetchRuleConfiguration(deliveryModel.getSourceProductCode(),
							deliveryModel.getEntityType(), deliveryModel.getEventType(), DeliveryTypeConstant.GDS);
					fetchConsumerGDSUrlAndSendToConsumer(deliveryModel, endPoint);

				} catch (GDSCException e) {
					LOG.error("FAILED to send data to consumer GDS \nError : " + e.getErrorMessage(), e);
					updateTableWithFailedStatus(deliveryModel, e.getErrorCode(), e.getErrorMessage(),
							getStackTraceInfoInString(e));
					break;
				}
			}
		}
	}

	@Override
	public void processQueuePendingDeliveryData() {

		// getPending Request from GDSCDeliveryDataModel
		LOG.info("Fetching Queue GDSCDeliveryDataModels...");
		List<GDSCDeliveryDataModel> deliveryDataModels = getQueuePendingDeliveryDataModels();

		if (deliveryDataModels.isEmpty()) {
			LOG.info("No Pending Queue delivery found");
			return;
		}
		Map<String, List<GDSCDeliveryDataModel>> chunks = new HashMap<String, List<GDSCDeliveryDataModel>>();
		LinkedHashSet<String> keyOrders = new LinkedHashSet<>();
		createChunks(deliveryDataModels, chunks, keyOrders);
		for (String keyOrder : keyOrders) {
			for (GDSCDeliveryDataModel deliveryModel : chunks.get(keyOrder)) {
				try {
					LOG.info("CGDS->QUEUE GDSCID : " + deliveryModel.getGdscId());
					LOG.info("Sending Data to consumer via Queue from " + deliveryModel.getSourceProductCode()
							+ "  ----->  " + deliveryModel.getConsumerProductCode());
					String endPoint = fetchRuleConfiguration(deliveryModel.getSourceProductCode(),
							deliveryModel.getEntityType(), deliveryModel.getEventType(), DeliveryTypeConstant.QUEUE);
					fetchQueueDetailsAndSendToConsumer(deliveryModel, endPoint);
					updateGDSCDeliveryDataModelSuccess(deliveryModel);

					// sending response back
					sendAckToProducer(deliveryModel, DeliveryTypeConstant.QUEUE);

				} catch (GDSCException e) {
					LOG.error("FAILED to send data to consumer Queue \nError : " + e.getErrorMessage(), e);
					updateTableWithFailedStatus(deliveryModel, e.getErrorCode(), e.getErrorMessage(),
							getStackTraceInfoInString(e));
					break;
				}
			}
		}
	}

	private void sendAckToProducer(GDSCDeliveryDataModel deliveryModel, String type) {
		try {
			GDSCDataModel dataModel = getGDSCDataModel(deliveryModel.getGdscId());
			GDSConsumerRequest requestData = getGDSConsumerRequestFromDeliveryDataModel(deliveryModel, dataModel);
			GDSPostBoxMessage postBoxMessage = getGDSPostBoxMessage(requestData, "SUCCESS", type);
			gdscPostBoxMessageService.capturePostBoxMessage(postBoxMessage);
		} catch (Throwable e) {
			LOG.error("Failed to send call back to " + deliveryModel.getSourceProductCode() + " producer,Due to {}", e);
		}
	}

	@Override
	public void processTopicPendingDeliveryData() {

		LOG.info("Fetching Topic GDSCDeliveryDataModels...");
		List<GDSCDeliveryDataModel> deliveryDataModels = getTopicPendingDeliveryDataModels();

		if (deliveryDataModels.isEmpty()) {
			LOG.info("No Pending Topic delivery found");
			return;
		}
		Map<String, List<GDSCDeliveryDataModel>> chunks = new HashMap<String, List<GDSCDeliveryDataModel>>();
		LinkedHashSet<String> keyOrders = new LinkedHashSet<>();
		createChunks(deliveryDataModels, chunks, keyOrders);
		for (String keyOrder : keyOrders) {
			for (GDSCDeliveryDataModel deliveryModel : chunks.get(keyOrder)) {
				try {
					LOG.info("CGDS->TOPIC GDSCID : " + deliveryModel.getGdscId());
					LOG.info("Sending Data to consumer via Topic from " + deliveryModel.getSourceProductCode()
							+ "  ----->  " + deliveryModel.getConsumerProductCode());
					String endPoint = fetchRuleConfiguration(deliveryModel.getSourceProductCode(),
							deliveryModel.getEntityType(), deliveryModel.getEventType(), DeliveryTypeConstant.TOPIC);
					fetchTopicDetailsAndSendToConsumer(deliveryModel, endPoint);
					updateGDSCDeliveryDataModelSuccess(deliveryModel);

					// sending response back
					sendAckToProducer(deliveryModel, DeliveryTypeConstant.TOPIC);

					LOG.info("Successfully sent Data to consumer via Topic for deliveryid "
							+ deliveryModel.getDeliveryId());
				} catch (GDSCException e) {
					LOG.error("FAILED to send data to consumer topic \nError : " + e.getErrorMessage(), e);
					updateTableWithFailedStatus(deliveryModel, e.getErrorCode(), e.getErrorMessage(),
							getStackTraceInfoInString(e));
					break;
				}
			}
		}
	}

	@Override
	public void processHttpPendingDeliveryData() {

		// getPending Request from GDSCDeliveryDataModel
		LOG.info("Fetching Http GDSCDeliveryDataModels...");
		List<GDSCDeliveryDataModel> deliveryDataModels = getHttpPendingDeliveryDataModels();

		if (deliveryDataModels.isEmpty()) {
			LOG.info("No Pending http delivery Packets found");
			return;
		}
		Map<String, List<GDSCDeliveryDataModel>> chunks = new HashMap<String, List<GDSCDeliveryDataModel>>();
		LinkedHashSet<String> keyOrders = new LinkedHashSet<>();
		createChunks(deliveryDataModels, chunks, keyOrders);
		for (String keyOrder : keyOrders) {
			for (GDSCDeliveryDataModel deliveryModel : chunks.get(keyOrder)) {
				try {
					LOG.info("CGDS->HTTP GDSCID : " + deliveryModel.getGdscId());
					LOG.info("Sending Data to consumer via Http from " + deliveryModel.getSourceProductCode()
							+ "  ----->  " + deliveryModel.getConsumerProductCode());

					String endPoint = fetchRuleConfiguration(deliveryModel.getSourceProductCode(),
							deliveryModel.getEntityType(), deliveryModel.getEventType(), DeliveryTypeConstant.HTTP);
					fetchHttpDetailsAndSendToConsumer(deliveryModel, endPoint);

				} catch (GDSCException e) {
					LOG.error("FAILED to send data to consumer Http \nError : " + e.getErrorMessage(), e);
					updateTableWithFailedStatus(deliveryModel, e.getErrorCode(), e.getErrorMessage(),
							getStackTraceInfoInString(e));
					break;
				}
			}
		}
	}

	private void fetchHttpDetailsAndSendToConsumer(GDSCDeliveryDataModel deliveryModel, String endPoint)
			throws GDSCException {
		String endPointUrl = null;
		RuleDetails ruleDetails = getRuleDetails(endPoint);
		for (RuleData ruleData : ruleDetails.getRuleData()) {
			String messageTypes = ruleData.getMessageType();
			String[] messageType = messageTypes.split(",");
			List<String> types = Arrays.asList(messageType);
			if (ruleData.getTargetProductCode().equalsIgnoreCase(deliveryModel.getConsumerProductCode())
					&& (types.contains(deliveryModel.getMessageType()) || types.contains("ALL"))) {
				if (ruleData.isUseServiceDiscovery()) {
					endPointUrl = getPostFixPath(GDSCUtil.getEndpointConsul(deliveryModel.getTenantId(),
							ruleData.getServiceName(), ACL_TOKEN, SERVICE_URL), ruleData.getUrl());
				} else if (ruleData.isTms()) {
					endPointUrl = getPostFixPath(GDSCUtil.getEndpointTMS(deliveryModel.getTenantId(),
							deliveryModel.getConsumerProductCode(), TMS_USERNAME, TMS_PASSWORD), ruleData.getUrl());
				} else if (ruleData.isConsulKey()) {
					endPointUrl = environment.getRequiredProperty(ruleData.getUrl());
				} else {
					endPointUrl = ruleData.getUrl();
				}

				if (endPointUrl == null || endPointUrl.trim().isEmpty()) {
					throw new GDSCException(String.valueOf(ErrorEnums.END_POINT_NOT_CONFIGURED.getValue()),
							ErrorEnums.END_POINT_NOT_CONFIGURED.getValue(), new Exception());
				} else {
					LOG.info("Consumer Product base url : " + endPointUrl);
					GDSCDataModel dataModel = getGDSCDataModel(deliveryModel.getGdscId());
					GDSConsumerRequest requestData = getGDSConsumerRequestFromDeliveryDataModel(deliveryModel,
							dataModel);
					LOG.info("Data for Consumer http : " + requestData);
					sendDataToConsumerhttp(endPointUrl, deliveryModel, requestData);
				}
			}
		}
	}

	private String getPostFixPath(String endPointUrl, String postFixPath) {
		if (checkIfNullNEmpty(postFixPath)) {
			return endPointUrl;
		} else {
			return endPointUrl + postFixPath;
		}
	}

	private static boolean checkIfNullNEmpty(String str) {
		return (str == null || str.isEmpty()) ? true : false;
	}

	private void sendDataToConsumerhttp(String endpoint, GDSCDeliveryDataModel model, GDSConsumerRequest requestData)
			throws GDSCException {

		try {
			LOG.info("Sending data to consumer http......");

			// update delivery timestamp
			updateDeliveryTimestamp(model);

			Client client = ClientBuilder.newClient();
			WebTarget resource = client.target(endpoint);
			Builder req = resource.request();
			requestData.getMessageToDispatch();
			String mediaType = MediaType.APPLICATION_JSON;
			String str = requestData.getMessageToDispatch();
			if (str != null && str.trim().startsWith("<")) {
				mediaType = MediaType.TEXT_XML;
			}
			Response resp = req.accept(MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML)
					.post(Entity.entity(requestData.getMessageToDispatch(), mediaType));
			if (resp.getStatus() == 415) {
				resp = req.accept(MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML)
						.post(Entity.entity(requestData.getMessageToDispatch(), MediaType.APPLICATION_XML));
			}
			String entity = resp.readEntity(String.class);

			if (resp.getStatus() == 200 && entity != null) {
				LOG.info("SUCCESS response received from http consumer Status Code : " + resp.getStatus());
				updateTableWithSuccessResponsehttp(model, resp.getStatus(), entity);

				// add to post box message and send to producer---
				GDSPostBoxMessage postBoxMessage = getGDSPostBoxMessage(requestData, entity, DeliveryTypeConstant.HTTP);
				gdscPostBoxMessageService.capturePostBoxMessage(postBoxMessage);

			} else {
				LOG.info("FAILED response received from http consumer Status Code : " + resp.getStatus());
				updateTableWithFailedResponsehttp(model, resp.getStatus(), entity);
			}
		} catch (Exception e) {
			LOG.error("Error Occured : " + e.getMessage());
			throw new GDSCException("500", "Failed to Send Data to Consumer http", e);
		}
	}

	private GDSPostBoxMessage getGDSPostBoxMessage(GDSConsumerRequest requestData, String entity, String type) {
		GDSPostBoxMessage gdsPostBoxMessage = new GDSPostBoxMessage();
		gdsPostBoxMessage.setGdsSource(requestData.getConsumerProductCode());
		gdsPostBoxMessage.setGdsDestination(requestData.getSourceProductCode());
		gdsPostBoxMessage.setGdsMessageType(type);
		gdsPostBoxMessage.setSourceId(requestData.getSourceProductCode());
		gdsPostBoxMessage.setDestinationId(requestData.getConsumerProductCode());
		EventInfo eventInfo = requestData.getEventInfo();
		PostBoxMessage message = new PostBoxMessage();
		message.setEventId(eventInfo.getEventId());
		message.setEntityId(eventInfo.getEntityId());
		message.setEventType(eventInfo.getEventType());
		message.setEntityType(eventInfo.getEntityType());
		message.setMessageType(requestData.getMessageType());
		message.setProductResponse(entity);
		message.setGdscId(requestData.getGdscId());
		message.setProducerId(requestData.getGdsProducerId() + "");
		message.setTenantId(eventInfo.getTenantId());
		gdsPostBoxMessage.setMessage(message);
		return gdsPostBoxMessage;
	}

	private void updateTableWithSuccessResponsehttp(GDSCDeliveryDataModel model, int status, String entity) {
		model.setStatus(GDSCStatus.SUCCESS.getValue());
		model.setExecutionAt("DATA SENT TO CONSUMER");
		model.setConsumerTimeStamp(new Date());
		model.setResponse(entity);
		model.setResponseStatus(status + "");
		deliveryRepo.save(model);
	}

	private void updateTableWithFailedResponsehttp(GDSCDeliveryDataModel model, int status, String entity) {
		model.setStatus(GDSCStatus.FAILED.getValue());
		model.setExecutionAt("DATA SENT TO CONSUMER");
		model.setConsumerTimeStamp(new Date());
		model.setResponse(entity);
		model.setResponseStatus(status + "");
		deliveryRepo.save(model);
	}

	private void createChunks(List<GDSCDeliveryDataModel> deliveryDataModels,
			Map<String, List<GDSCDeliveryDataModel>> chunks, LinkedHashSet<String> keyOrders) {
		for (GDSCDeliveryDataModel gdscDeliveryDataModel : deliveryDataModels) {
			String key = gdscDeliveryDataModel.getConsumerProductCode();
			List<GDSCDeliveryDataModel> chunk = chunks.get(key);
			keyOrders.add(key);

			// Creating new chunk if key not present else add to previous existing
			if (chunk == null) {
				List<GDSCDeliveryDataModel> treeGDSProducerRequest = new ArrayList<GDSCDeliveryDataModel>();
				treeGDSProducerRequest.add(gdscDeliveryDataModel);
				chunks.put(key, treeGDSProducerRequest);
			} else {
				chunk.add(gdscDeliveryDataModel);
			}
		}
	}

	private List<GDSCDeliveryDataModel> getQueuePendingDeliveryDataModels() {
		return deliveryRepo.getGDSCDeliveryDataModel(DeliveryTypeConstant.QUEUE, GDSCStatus.READY_TO_PROCESS.getValue(),
				GDSCStatus.FAILED.getValue());
	}

	private List<GDSCDeliveryDataModel> getTopicPendingDeliveryDataModels() {
		return deliveryRepo.getGDSCDeliveryDataModel(DeliveryTypeConstant.TOPIC, GDSCStatus.READY_TO_PROCESS.getValue(),
				GDSCStatus.FAILED.getValue());
	}

	private List<GDSCDeliveryDataModel> getHttpPendingDeliveryDataModels() {
		return deliveryRepo.getGDSCDeliveryDataModel(DeliveryTypeConstant.HTTP, GDSCStatus.READY_TO_PROCESS.getValue(),
				GDSCStatus.FAILED.getValue());
	}

	private List<GDSCDeliveryDataModel> getGDSPendingDeliveryDataModels() {
		return deliveryRepo.getGDSCDeliveryDataModel(DeliveryTypeConstant.GDS, GDSCStatus.READY_TO_PROCESS.getValue(),
				GDSCStatus.FAILED.getValue());
	}

	private String getStackTraceInfoInString(Throwable e) {

		StringWriter sw = new StringWriter();
		e.printStackTrace(new PrintWriter(sw));
		String stackTrace = sw.toString();
		return stackTrace;
	}

	/**
	 * 
	 * @param gdsProducerRequest
	 * @param gdscDataModel
	 * @return
	 * @throws GDSCException
	 * 
	 *             Handles all request with null data
	 */

	private Acknowledge workWithNullRequest(GDSProducerRequest gdsProducerRequest, GDSCDataModel gdscDataModel)
			throws GDSCException {
		LOG.info("Processing Request with null data");
		if (gdscDataModel != null) {
			String status = gdscDataModel.getStatus();
			switch (status) {
			case "SUCCESS":
				return sendAcknowledge(gdscDataModel.getGdsTimestamp().getTime(), gdscDataModel.getGdscId(), null, null,
						null);
			case "READY TO PROCESS":
				return sendAcknowledge(gdscDataModel.getGdsTimestamp().getTime(), gdscDataModel.getGdscId(), null, null,
						null);
			case "FAILED":
				throw new GDSCException(String.valueOf(ErrorEnums.NO_DATA_RECEIVED.getValue()),
						ErrorEnums.NO_DATA_RECEIVED.getValue(), new Exception());
			default:
				throw new GDSCException(String.valueOf(ErrorEnums.NO_DATA_RECEIVED.getValue()),
						ErrorEnums.NO_DATA_RECEIVED.getValue(), new Exception());
			}
		} else {
			LOG.info("Storing request with null data in DB");
			storeEntryForNullData(gdsProducerRequest);
			throw new GDSCException(String.valueOf(ErrorEnums.NO_DATA_RECEIVED.getValue()),
					ErrorEnums.NO_DATA_RECEIVED.getValue(), new Exception());
		}
	}

	/**
	 * Stores entry for null data received in request
	 * 
	 * @param gdsProducerRequest
	 * @throws GDSCException
	 */
	private void storeEntryForNullData(GDSProducerRequest gdsProducerRequest) throws GDSCException {
		String gdscid = GDSCUtil.generateRandomNumber();
		addRequestWithEmptyDataInDB(gdsProducerRequest, gdscid);

	}

	private void addRequestWithEmptyDataInDB(GDSProducerRequest gdsProducerRequest, String gdscid)
			throws GDSCException {
		GDSCDataModel dataModel = new GDSCDataModel();
		dataModel.setGdsProducerId(gdsProducerRequest.getId());
		dataModel.setGdscId(gdscid);
		dataModel.setProducerExecutionAt(gdsProducerRequest.getExecutionAt());
		dataModel.setSourceProductCode(gdsProducerRequest.getProductCode());
		dataModel.setProducerErrorCode(gdsProducerRequest.getErrorCode());
		dataModel.setProducerErrorDescription(gdsProducerRequest.getErrorDescription());
		try {
			dataModel.setReceivedData(getGdsProducerRequest(gdsProducerRequest));
		} catch (IOException e) {
			throw new GDSCException(String.valueOf(ErrorEnums.INVALID_DATA_RECEIVED.getValue()),
					ErrorEnums.INVALID_DATA_RECEIVED.getValue(), e);
		}
		dataModel.setStatus(GDSCStatus.FAILED.getValue());
		dataModelRepo.save(dataModel);
	}

	/**
	 * Processes request Received from Producer and stores in DB
	 * 
	 * @param gdsProducerRequest
	 * @return
	 * @throws GDSCException
	 */
	@Transactional(rollbackFor = GDSCException.class)
	private Acknowledge workWithNonDuplicateEntry(GDSProducerRequest gdsProducerRequest) throws GDSCException {
		String gdscid = GDSCUtil.generateRandomNumber();

		// Adding the request in DB
		LOG.info("Adding producer request in DB");

		// Create individual packect of data from request
		List<GDSCDeliveryDataModel> packets = createDeliveryPackets(gdsProducerRequest, gdscid);
		List<MessageSet> messageSets = gdsProducerRequest.getCapturedEventData().getMessageSet();

		String messageType = validateMessageType(packets, messageSets);

		if (packets.size() != messageSets.size() && messageType != null) {
			LOG.info("Rule is not Configured for messageType - " + messageType.substring(0, messageType.length() - 1));
			EventInfo eventInfo = gdsProducerRequest.getCapturedEventData().getEventInfo();
			throw new GDSCException(GDSCErrorEnum.RULE_NOT_CONFIGURED.getValue(),
					GDSCErrorEnum.RULE_NOT_CONFIGURED.getText() + " for productCode : "
							+ gdsProducerRequest.getProductCode() + ", entityType : " + eventInfo.getEntityType()
							+ ", eventType : " + eventInfo.getEventType() + ", messageType :"
							+ messageType.substring(0, messageType.length() - 1),
					new Exception());
		}

		try {
			addDataPacketInDB(gdsProducerRequest, gdscid);
			LOG.info("Adding delivery packets in DB");
			printDeliveryPackets(packets);
			if (!packets.isEmpty()) {
				// adding the packect in DB
				addDeliverDataPacketsInDB(packets);
			}
		} catch (Exception e) {
			if (e instanceof ConstraintViolationException || e instanceof DataIntegrityViolationException) {
				return captureEventData(gdsProducerRequest);
			}
			LOG.error(" Unable to save request to DataBase {}", e);
			throw new GDSCException(GDSCErrorEnum.UNABLE_TO_SAVE_REQUEST.getValue(),
					GDSCErrorEnum.UNABLE_TO_SAVE_REQUEST.getText(), e);
		}
		return sendAcknowledge(gdsProducerRequest.getTimeStamp(), gdscid, null, null, null);

	}

	private String validateMessageType(List<GDSCDeliveryDataModel> packets, List<MessageSet> messageSets) {
		String messageType = null;

		for (MessageSet messageset : messageSets) {
			int flag = 0;
			for (GDSCDeliveryDataModel model : packets) {
				if (messageset.getType().equalsIgnoreCase(model.getMessageType())) {
					flag = 1;
				}
			}
			if (flag == 0) {
				if (messageType == null) {
					messageType = messageset.getType() + ",";
				} else {
					messageType += messageset.getType() + ",";
				}
			}
		}
		return messageType;
	}

	/**
	 * Processes Duplicate request received from Producer
	 * 
	 * @param gdsProducerRequest
	 * @param gdscDataModel
	 * @return
	 * @throws GDSCException
	 */

	private Acknowledge workWithDuplicateEntry(GDSProducerRequest gdsProducerRequest, GDSCDataModel gdscDataModel)
			throws GDSCException {

		LOG.info("Processing Duplicate Request");
		String status = gdscDataModel.getStatus();
		if (status.equals(GDSCStatus.SUCCESS.getValue()) || status.equals(GDSCStatus.READY_TO_PROCESS.getValue()))
			return sendAcknowledge(gdscDataModel.getGdsTimestamp().getTime(), gdscDataModel.getGdscId(), null, null,
					null);
		else
			return updateGDSProducerRequestInDB(gdsProducerRequest, gdscDataModel);

	}

	/**
	 * Store Producer Request in DB
	 * 
	 * @param gdsProducerRequest
	 * @param gdscDataModel
	 * @return
	 * @throws GDSCException
	 */

	private Acknowledge updateGDSProducerRequestInDB(GDSProducerRequest gdsProducerRequest, GDSCDataModel gdscDataModel)
			throws GDSCException {

		LOG.info("Updating the producer Request In DB...");

		String gdscid = gdscDataModel.getGdscId();
		// updateGDSCDataModel
		updateGDSCDataModel(gdsProducerRequest, gdscDataModel, gdscid);

		// extract Datapackets
		List<GDSCDeliveryDataModel> packets = createDeliveryPackets(gdsProducerRequest, gdscid);

		LOG.info("Adding delivery packets in DB");
		// printDeliveryPackets(packets);
		if (!packets.isEmpty()) {
			// adding the packect in DB
			addDeliverDataPacketsInDB(packets);
		}
		// send success response
		return sendAcknowledge(gdsProducerRequest.getTimeStamp(), gdscid, null, null, null);
	}

	/**
	 * Updates and Processes the Producer Request received in DB
	 * 
	 * @param gdsProducerRequest
	 * @param gdscDataModel
	 * @param gdscid
	 * @throws GDSCException
	 */

	private void updateGDSCDataModel(GDSProducerRequest gdsProducerRequest, GDSCDataModel gdscDataModel, String gdscid)
			throws GDSCException {

		GDSCDataModel dataModel = getDataModelFromGDSProducerRequest(gdsProducerRequest, gdscid);
		dataModel.setId(gdscDataModel.getId());

		dataModelRepo.save(dataModel);

	}

	/**
	 * Fetches previously stored Producer Request from DB
	 * 
	 * @param id
	 * @return
	 */

	private GDSCDataModel getDuplicateGDSProducerRequest(Long id, String productCode) {

		List<GDSCDataModel> gdscDataModel = dataModelRepo.getGDSCDataModel(id, productCode);

		if (gdscDataModel.isEmpty()) {
			return null;
		} else {
			return gdscDataModel.get(0);
		}
	}

	/**
	 * Storing ProducerRequest in DB
	 * 
	 * @param gdsProducerRequest
	 * @param gdscid
	 * @throws GDSCException
	 */

	private void addDataPacketInDB(GDSProducerRequest gdsProducerRequest, String gdscid) throws GDSCException {
		GDSCDataModel dataModel = getDataModelFromGDSProducerRequest(gdsProducerRequest, gdscid);
		dataModelRepo.save(dataModel);
	}

	private GDSCDataModel getDataModelFromGDSProducerRequest(GDSProducerRequest gdsProducerRequest, String gdscid)
			throws GDSCException {
		GDSCDataModel dataModel = new GDSCDataModel();
		EventInfo eventInfo = gdsProducerRequest.getCapturedEventData().getEventInfo();
		dataModel.setGdsProducerId(gdsProducerRequest.getId());
		dataModel.setGdscId(gdscid);
		dataModel.setEventInfoId(eventInfo.getId());
		dataModel.setBusinessRefId(eventInfo.getBusinessRefId());
		dataModel.setEntityId(eventInfo.getEntityId());
		dataModel.setEntityType(eventInfo.getEntityType());
		dataModel.setEventId(eventInfo.getEventId());
		dataModel.setEventType(eventInfo.getEventType());
		dataModel.setExtraInfo(eventInfo.getExtraInfo());
		dataModel.setGdsTimestamp(new Date(eventInfo.getTimeStamp()));
		dataModel.setProducerExecutionAt(gdsProducerRequest.getExecutionAt());
		dataModel.setTenantId(eventInfo.getTenantId());
		dataModel.setVersion(eventInfo.getVersion());
		dataModel.setSourceProductCode(gdsProducerRequest.getProductCode());
		try {
			dataModel.setReceivedData(getGdsProducerRequest(gdsProducerRequest));
		} catch (IOException e) {
			throw new GDSCException(String.valueOf(ErrorEnums.INVALID_DATA_RECEIVED.getValue()),
					ErrorEnums.INVALID_DATA_RECEIVED.getValue(), e);
		}

		dataModel.setStatus(GDSCStatus.SUCCESS.getValue());
		return dataModel;
	}

	private String getGdsProducerRequest(GDSProducerRequest gdsProducerRequest)
			throws JsonMappingException, IOException {

		return JsonUtil.serialize(gdsProducerRequest);
	}

	/**
	 * Log all the delivery Packets received in Producer Request
	 * 
	 * @param packets
	 */
	private void printDeliveryPackets(List<GDSCDeliveryDataModel> packets) {

		for (GDSCDeliveryDataModel model : packets) {
			LOG.info("Source : " + model.getSourceProductCode());
			LOG.info("Consumer : " + model.getConsumerProductCode());
			LOG.info("Message : " + model.getMessageToDispatch());
		}

	}

	private void addDeliverDataPacketsInDB(List<GDSCDeliveryDataModel> packets) {
		deliveryRepo.save(packets);
	}

	/**
	 * Creates all Delivery Packets using Producer Request
	 * 
	 * @param gdsProducerRequest
	 * @param gdsId
	 * @return
	 * @throws GDSCException
	 */
	private List<GDSCDeliveryDataModel> createDeliveryPackets(GDSProducerRequest gdsProducerRequest, String gdsId)
			throws GDSCException {

		LOG.info("Initializing the creation of delivery Packets for all consumers");
		List<GDSCDeliveryDataModel> deliveryData = new ArrayList<>();

		String productCode = gdsProducerRequest.getProductCode();
		String entityType = gdsProducerRequest.getCapturedEventData().getEventInfo().getEntityType();
		String eventType = gdsProducerRequest.getCapturedEventData().getEventInfo().getEventType();

		// need to change rule configuration
		RuleConfiguration ruleConfiguration = fetchRuleConfiguration(productCode, entityType, eventType);

		ObjectMapper mapper = new ObjectMapper();
		String gdsEndPoint = ruleConfiguration.getGdsEndPoint();
		String topicEndPoint = ruleConfiguration.getTopic();
		String queueEndPoint = ruleConfiguration.getQueue();
		String httpEndPoint = ruleConfiguration.getHttp();
		if (gdsEndPoint != null) {
			addDestinationEndPointDataToDeliveryTable(gdsProducerRequest, gdsId, deliveryData, mapper, gdsEndPoint,
					DeliveryTypeConstant.GDS);
		}
		if (queueEndPoint != null) {
			addDestinationEndPointDataToDeliveryTable(gdsProducerRequest, gdsId, deliveryData, mapper, queueEndPoint,
					DeliveryTypeConstant.QUEUE);
		}
		if (topicEndPoint != null) {
			addDestinationEndPointDataToDeliveryTable(gdsProducerRequest, gdsId, deliveryData, mapper, topicEndPoint,
					DeliveryTypeConstant.TOPIC);
		}
		if (httpEndPoint != null) {
			addDestinationEndPointDataToDeliveryTable(gdsProducerRequest, gdsId, deliveryData, mapper, httpEndPoint,
					DeliveryTypeConstant.HTTP);
		}

		LOG.info("Delivery Packets successfully created");

		return deliveryData;

	}

	private void addDestinationEndPointDataToDeliveryTable(GDSProducerRequest gdsProducerRequest, String gdsId,
			List<GDSCDeliveryDataModel> deliveryData, ObjectMapper mapper, String gdsEndPoint, String destinationType)
			throws GDSCException {
		try {
			RuleDetails ruleDetails = mapper.readValue(gdsEndPoint, RuleDetails.class);
			List<MessageSet> messages = gdsProducerRequest.getCapturedEventData().getMessageSet();
			for (RuleData ruleData : ruleDetails.getRuleData()) {
				String messageTypes = ruleData.getMessageType();
				String[] messageType = messageTypes.split(",");
				List<String> types = Arrays.asList(messageType);
				for (MessageSet message : messages) {
					String type = message.getType();
					if (types.contains(type) || types.contains("ALL")) {
						GDSCDeliveryDataModel data = getGDSCDeliveryDataModel(gdsProducerRequest, message,
								ruleData.getTargetProductCode(), gdsId, destinationType);
						deliveryData.add(data);
					}
				}
			}

		} catch (Exception e) {
			LOG.error("Unable to convert GDS_Endpoint string to RuleData {}", e);
			throw new GDSCException(GDSCErrorEnum.RULE_CONFIGURATION_GDS_ENDPOINT_ERROR.getValue(),
					GDSCErrorEnum.RULE_CONFIGURATION_GDS_ENDPOINT_ERROR.getText(), new Exception());
		}
	}

	private RuleConfiguration fetchRuleConfiguration(String productCode, String entityType, String eventType)
			throws GDSCException {
		List<RuleConfiguration> rules = ruleConfigurationRepository.getRuleConfiguration(productCode, entityType,
				eventType);
		if (rules.isEmpty()) {
			throw new GDSCException(GDSCErrorEnum.RULE_NOT_CONFIGURED.getValue(),
					GDSCErrorEnum.RULE_NOT_CONFIGURED.getText() + " for productCode : " + productCode
							+ ", entityType : " + entityType + ", eventType : " + eventType,
					new Exception());
		}
		validateEventType(eventType, rules.get(0));
		return rules.get(0);
	}

	private void validateEventType(String eventType, RuleConfiguration ruleConfiguration) throws GDSCException {
		String events = ruleConfiguration.getEvent();
		String[] event = events.split(",");

		List<String> types = Arrays.asList(event);
		if (!types.contains(eventType)) {
			throw new GDSCException(GDSCErrorEnum.RULE_NOT_CONFIGURED.getValue(),
					GDSCErrorEnum.RULE_NOT_CONFIGURED.getText() + " " + eventType, new Exception());
		}
	}

	private String fetchRuleConfiguration(String productCode, String entityType, String eventType,
			String destinationType) throws GDSCException {
		List<RuleConfiguration> rules = ruleConfigurationRepository.getRuleConfiguration(productCode, entityType,
				eventType);
		if (rules.isEmpty()) {
			throw new GDSCException(GDSCErrorEnum.RULE_NOT_CONFIGURED.getValue(),
					GDSCErrorEnum.RULE_NOT_CONFIGURED.getText(), new Exception());
		} else {
			RuleConfiguration ruleConfig = rules.get(0);
			String endPoint = null;
			switch (destinationType) {
			case DeliveryTypeConstant.GDS:
				endPoint = ruleConfig.getGdsEndPoint();
				break;
			case DeliveryTypeConstant.QUEUE:
				endPoint = ruleConfig.getQueue();
				break;
			case DeliveryTypeConstant.TOPIC:
				endPoint = ruleConfig.getTopic();
				break;
			case DeliveryTypeConstant.HTTP:
				endPoint = ruleConfig.getHttp();
				break;

			}
			return endPoint;
		}
	}

	private GDSCDeliveryDataModel getGDSCDeliveryDataModel(GDSProducerRequest gdsProducerRequest, MessageSet message,
			String consumer, String gdsid, String destinationType) {
		GDSCDeliveryDataModel data = new GDSCDeliveryDataModel();
		EventInfo eventInfo = gdsProducerRequest.getCapturedEventData().getEventInfo();
		data.setGdsProducerId(gdsProducerRequest.getId());
		data.setGdscId(gdsid);
		data.setTenantId(eventInfo.getTenantId());
		data.setSourceProductCode(gdsProducerRequest.getProductCode());
		data.setConsumerProductCode(consumer);
		data.setMessageToDispatch(message.getData());
		data.setMessageType(message.getType());
		data.setStatus(GDSCStatus.READY_TO_PROCESS.getValue());
		data.setExecutionAt("DATA RECEIVED FROM PRODUCER");
		data.setProducerTimeStamp(new Date(gdsProducerRequest.getTimeStamp()));
		data.setFailedAttempts(0l);
		data.setDestinationType(destinationType);
		data.setEventType(eventInfo.getEventType());
		data.setEntityType(eventInfo.getEntityType());
		return data;
	}

	/*
	 * private Map<String, String> getMapFromString(String consumerCode) {
	 * Map<String, String> consumerCodeMap = new HashMap<>(); String[] args =
	 * consumerCode.split(","); for (int i = 0; i < args.length; i++) { String
	 * product = args[i].substring(0, args[i].indexOf(":")); String type =
	 * args[i].substring(args[i].indexOf(":") + 1, args[i].length());
	 * consumerCodeMap.put(product, type); } return consumerCodeMap; }
	 */

	/**
	 * Gets the rules from DB
	 * 
	 * @param productCode
	 * @param entity
	 * @param event
	 * @return
	 * @throws GDSCException
	 *//*
		 * 
		 * private Rule fetchRules(String productCode, String entity, String event)
		 * throws GDSCException {
		 * 
		 * List<Rule> rules = ruleRepo.getRule(productCode, entity, event); if
		 * (rules.isEmpty()) { throw new
		 * GDSCException(String.valueOf(ErrorCode.RULE_NOT_FOUND.getValue()),
		 * ErrorDescription.RULE_NOT_FOUND.getValue(), new Exception()); }
		 * 
		 * return rules.get(0); }
		 */

	private Acknowledge sendAcknowledge(Long timestamp, String gdsid, String errorCode, String errorDescription,
			String stacktrace) {

		Acknowledge ack = new Acknowledge();
		ack.setTimeStamp(timestamp);
		ack.setGdscId(gdsid);
		ack.setErrorCode(errorCode);
		ack.setErrorDescription(errorDescription);
		ack.setStackTrace(stacktrace);
		LOG.info("Sending Acknowledgement......");
		LOG.info("Success Response : " + JsonUtil.serializeString(ack));
		return ack;
	}

	private void updateGDSCDeliveryDataModelSuccess(GDSCDeliveryDataModel model) {
		model.setStatus(GDSCStatus.SUCCESS.getValue());
		model.setExecutionAt("DATA SENT TO CONSUMER");
		model.setConsumerTimeStamp(new Date());
		model.setDeliveryTimeStamp(new Date());
		deliveryRepo.save(model);
	}

	private void fetchQueueDetailsAndSendToConsumer(GDSCDeliveryDataModel deliveryModel, String endPoint)
			throws GDSCException {
		String brokerUrl = null;
		String queueName = null;
		

		RuleDetails ruleDetails = getRuleDetails(endPoint);
		for (RuleData ruleData : ruleDetails.getRuleData()) {
			if (ruleData.getTargetProductCode().equalsIgnoreCase(deliveryModel.getConsumerProductCode())
					&& DeliveryTypeConstant.QUEUE.equalsIgnoreCase(deliveryModel.getDestinationType())) {
				if (ruleData.isConsulKey()) {

					brokerUrl = this.environment.getRequiredProperty(ruleData.getUrl());
					queueName = this.environment.getRequiredProperty(ruleData.getName());
				}

			} else {
				brokerUrl = ruleData.getUrl();
				queueName = ruleData.getName();
			}
			updateDeliveryTimestamp(deliveryModel);
			if (brokerUrl != null && queueName != null) {
				LOG.info("Consumer Product base url : " + brokerUrl + " Topic Name - " + queueName);
				String data = deliveryModel.getMessageToDispatch();
				MQUtil.sendObjectMessage(brokerUrl, queueName, false, data, null);
			} else {
				throw new GDSCException(GDSCErrorEnum.QUEUE_RULE_CONFIGURATION_ERROR.getValue(),
						GDSCErrorEnum.QUEUE_RULE_CONFIGURATION_ERROR.getText(), new Exception());
			}
		}
	}

	private void fetchTopicDetailsAndSendToConsumer(GDSCDeliveryDataModel deliveryModel, String endPoint)
			throws GDSCException {
		String brokerUrl = null;
		String topicName = null;

		RuleDetails ruleDetails = getRuleDetails(endPoint);
		for (RuleData ruleData : ruleDetails.getRuleData()) {
			if (ruleData.getTargetProductCode().equalsIgnoreCase(deliveryModel.getConsumerProductCode())
					&& DeliveryTypeConstant.TOPIC.equalsIgnoreCase(deliveryModel.getDestinationType())) {
				if (ruleData.isConsulKey()) {
					brokerUrl = this.environment.getRequiredProperty(ruleData.getUrl());
					topicName = this.environment.getRequiredProperty(ruleData.getName());
				} else {
					brokerUrl = ruleData.getUrl();
					topicName = ruleData.getName();
				}
				updateDeliveryTimestamp(deliveryModel);
				if (brokerUrl != null && topicName != null) {
					LOG.info("Consumer Product base url : " + brokerUrl + " Queue Name - " + topicName);
					String data = deliveryModel.getMessageToDispatch();
					MQUtil.sendObjectMessage(brokerUrl, topicName, true, data, null);

				} else {
					throw new GDSCException(GDSCErrorEnum.QUEUE_RULE_CONFIGURATION_ERROR.getValue(),
							GDSCErrorEnum.QUEUE_RULE_CONFIGURATION_ERROR.getText(), new Exception());
				}
			}
		}

	}

	private void fetchConsumerGDSUrlAndSendToConsumer(GDSCDeliveryDataModel deliveryModel, String endPoint)
			throws GDSCException {
		String endPointUrl = null;
		RuleDetails ruleDetails = getRuleDetails(endPoint);
		for (RuleData ruleData : ruleDetails.getRuleData()) {
			String messageTypes = ruleData.getMessageType();
			String[] messageType = messageTypes.split(",");
			List<String> types = Arrays.asList(messageType);
			if (ruleData.getTargetProductCode().equalsIgnoreCase(deliveryModel.getConsumerProductCode())
					&& (types.contains(deliveryModel.getMessageType()) || types.contains("ALL"))) {
				endPointUrl = getEndPointUrlFromRuleData(deliveryModel, ruleData);
				if (endPointUrl == null || endPointUrl.trim().isEmpty()) {
					throw new GDSCException(String.valueOf(ErrorEnums.END_POINT_NOT_CONFIGURED.getValue()),
							ErrorEnums.END_POINT_NOT_CONFIGURED.getValue(), new Exception());
				} else {
					LOG.info("Consumer Product base url : " + endPointUrl);
					GDSCDataModel dataModel = getGDSCDataModel(deliveryModel.getGdscId());
					GDSConsumerRequest requestData = getGDSConsumerRequestFromDeliveryDataModel(deliveryModel,
							dataModel);
					String consumerRequest = getConsumerRequestJsonFromObject(requestData);
					LOG.info("Data for Consumer : " + consumerRequest);
					sendDataToConsumer(endPointUrl, requestData, deliveryModel);
				}
			}
		}
	}

	private String getEndPointUrlFromRuleData(GDSCDeliveryDataModel deliveryModel, RuleData ruleData)
			throws GDSCException {
		String endPointUrl;
		if (ruleData.isUseServiceDiscovery()) {
			endPointUrl = GDSCUtil.getEndpointConsul(deliveryModel.getTenantId(), ruleData.getServiceName(), ACL_TOKEN,
					SERVICE_URL);
		} else if (ruleData.isTms()) {
			endPointUrl = GDSCUtil.getEndpointTMS(deliveryModel.getTenantId(), deliveryModel.getConsumerProductCode(),
					TMS_USERNAME, TMS_PASSWORD);
		} else if (ruleData.isConsulKey()) {
			endPointUrl = environment.getRequiredProperty(ruleData.getUrl());
		} else {
			endPointUrl = ruleData.getUrl();
		}
		return endPointUrl;
	}

	private RuleDetails getRuleDetails(String ruleDetails) throws GDSCException {
		ObjectMapper mapper = new ObjectMapper();
		try {
			return mapper.readValue(ruleDetails, RuleDetails.class);
		} catch (Exception e) {
			throw new GDSCException(GDSCErrorEnum.RULE_CONFIGURATION_GDS_ENDPOINT_ERROR.getValue(),
					GDSCErrorEnum.RULE_CONFIGURATION_GDS_ENDPOINT_ERROR.getText(), new Exception());
		}
	}

	private GDSCDataModel getGDSCDataModel(String gdscId) throws GDSCException {
		GDSCDataModel model = dataModelRepo.getGDSCDataModelWithGDSCId(gdscId);
		if (model != null) {
			return model;
		}
		throw new GDSCException(String.valueOf(ErrorEnums.INTERNAL_SERVER_ERROR.getValue()),
				ErrorEnums.INTERNAL_SERVER_ERROR.getValue(), new Exception());
	}

	private String getConsumerRequestJsonFromObject(GDSConsumerRequest requestData) throws GDSCException {
		try {
			String consumerRequest = JsonUtil.serialize(requestData);
			return consumerRequest;
		} catch (IOException e) {
			LOG.error("Failed to serialize ConsumerRequestData : " + e.getMessage(), e);
			throw new GDSCException(String.valueOf(ErrorEnums.INTERNAL_SERVER_ERROR.getValue()),
					ErrorEnums.INTERNAL_SERVER_ERROR.getValue(), e);
		}
	}

	/**
	 * Creating Consumer Packets from Delivery Data Model
	 * 
	 * @param deliveryModel
	 * @param dataModel
	 * @return
	 */
	private GDSConsumerRequest getGDSConsumerRequestFromDeliveryDataModel(GDSCDeliveryDataModel deliveryModel,
			GDSCDataModel dataModel) {
		GDSConsumerRequest gdsConsumerRequest = new GDSConsumerRequest();

		EventInfo eventInfo = getEventInfo(dataModel);

		gdsConsumerRequest.setDeliveryId(deliveryModel.getDeliveryId());
		gdsConsumerRequest.setGdsProducerId(deliveryModel.getGdsProducerId());
		gdsConsumerRequest.setGdscId(deliveryModel.getGdscId());
		gdsConsumerRequest.setSourceProductCode(deliveryModel.getSourceProductCode());
		gdsConsumerRequest.setConsumerProductCode(deliveryModel.getConsumerProductCode());
		gdsConsumerRequest.setTimeStamp(new Date().getTime());
		gdsConsumerRequest.setMessageToDispatch(deliveryModel.getMessageToDispatch());
		gdsConsumerRequest.setMessageType(deliveryModel.getMessageType());
		gdsConsumerRequest.setEventInfo(eventInfo);
		return gdsConsumerRequest;
	}

	private EventInfo getEventInfo(GDSCDataModel dataModel) {

		EventInfo eventInfo = new EventInfo();
		eventInfo.setId(dataModel.getEventInfoId());
		eventInfo.setBusinessRefId(dataModel.getBusinessRefId());
		eventInfo.setEntityId(dataModel.getEntityId());
		eventInfo.setEntityType(dataModel.getEntityType());
		eventInfo.setEventId(dataModel.getEventId());
		eventInfo.setEventType(dataModel.getEventType());
		eventInfo.setExtraInfo(dataModel.getExtraInfo());
		eventInfo.setTenantId(dataModel.getTenantId());
		eventInfo.setTimeStamp(dataModel.getGdsTimestamp().getTime());

		return eventInfo;
	}

	private void updateTableWithFailedConsumerResponse(GDSCDeliveryDataModel model, String errorCode,
			String errorMessage, String stackTraceInfoInString, String executionAt) {
		model.setConsumerErrorCode(errorCode);
		model.setConsumerExecutionAt(executionAt);
		model.setConsumerStacktrace(stackTraceInfoInString);
		Long failedAttempts = model.getFailedAttempts();
		model.setFailedAttempts((failedAttempts == null) ? 1l : failedAttempts + 1l);
		model.setStatus(GDSCStatus.FAILED.getValue());
		deliveryRepo.save(model);
	}

	private void updateTableWithFailedStatus(GDSCDeliveryDataModel model, String errorCode, String errorMessage,
			String stackTraceInfoInString) {
		model.setErrorCode(errorCode);
		model.setErrorDescription(errorMessage + "\n" + stackTraceInfoInString);
		model.setStatus(GDSCStatus.FAILED.getValue());
		Long failedAttempts = ((model.getFailedAttempts() == null) ? 1l : model.getFailedAttempts() + 1);
		model.setFailedAttempts(failedAttempts);
		deliveryRepo.save(model);
	}

	private void updateTableWithSuccessResponse(GDSCDeliveryDataModel model, GDSConsumerResponse gdsConsumerResponse) {
		model.setStatus(GDSCStatus.SUCCESS.getValue());
		model.setExecutionAt("DATA SENT TO CONSUMER");
		model.setConsumerTimeStamp(new Date(gdsConsumerResponse.getTimeStamp()));
		model.setGdsConsumerId(Long.parseLong(gdsConsumerResponse.getGdsConsumerId()));
		deliveryRepo.save(model);
	}

	/**
	 * Sends the Consumer Packet to its destination
	 * 
	 * @param endpoint
	 * @param gdsConsumerRequest
	 * @param model
	 * @throws GDSCException
	 */
	private void sendDataToConsumer(String endpoint, GDSConsumerRequest gdsConsumerRequest, GDSCDeliveryDataModel model)
			throws GDSCException {

		updateDeliveryTimestamp(model);
		String URL = endpoint + "/GDS/postbox/consumer";
		LOG.info("Destination URL : " + URL);
		HttpMethod httpMethod = HttpMethod.POST;
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(org.springframework.http.MediaType.APPLICATION_JSON);
		RestTemplate restTemplate = new RestTemplate();

		HttpEntity<GDSConsumerRequest> request = new HttpEntity<GDSConsumerRequest>(gdsConsumerRequest, headers);
		ResponseEntity<String> resp = null;
		try {
			resp = restTemplate.exchange(URL, httpMethod, request, String.class);
			GDSConsumerResponse gdsConsumerResponse = getGDSConsumerResponseForObject(resp.getBody());

			if (resp.getStatusCode() != HttpStatus.OK) {
				LOG.info("FAILED response received from GDS consumer status Code : " + resp.getStatusCode());
				updateTableWithFailedConsumerResponse(model, gdsConsumerResponse.getErrorCode(),
						gdsConsumerResponse.getExecutionAt(), gdsConsumerResponse.getStackTrace(),
						gdsConsumerResponse.getExecutionAt());
				throw new GDSCException(gdsConsumerResponse.getErrorCode(), gdsConsumerResponse.getExecutionAt(),
						new Exception(gdsConsumerResponse.getStackTrace()));
			} else {
				LOG.info("SUCCESS response received from GDS consumer status Code : " + resp.getStatusCode());
				updateTableWithSuccessResponse(model, gdsConsumerResponse);
			}
		} catch (GDSCException e) {
			LOG.error(e.getErrorMessage());
			throw e;
		} catch (Exception e) {

			LOG.error("Error Occured : " + e.getMessage());
			throw new GDSCException("500", "Failed to Send Data to Consumer", e);
		}

	}

	private void updateDeliveryTimestamp(GDSCDeliveryDataModel model) {
		model.setDeliveryTimeStamp(new Date());
		deliveryRepo.save(model);
	}

	public static GDSConsumerResponse getGDSConsumerResponseForObject(String response) throws GDSCException {
		System.out.println(response);
		try {
			return JsonUtil.deserialize(response, GDSConsumerResponse.class);
		} catch (IOException e) {
			LOG.info("Failed to Deserialize ConsumerResponse");
			throw new GDSCException("400", "Failed to read consumer response", new Exception());
		}
	}

}
