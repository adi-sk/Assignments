
package com.zycus.integration.GDS.pojo;
/**
 *punit.sukhija
 *
 */
public class ConsumerPayload {

}
