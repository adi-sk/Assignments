package com.zycus.integration.GDS.constant;

public interface DeliveryTypeConstant {
	
	String GDS="GDS"; 
	String QUEUE="QUEUE"; 
	String TOPIC="TOPIC"; 
	String HTTP="HTTP"; 
	
}
