package com.zycus.integration.GDS.enums;

public enum GDSCPostBoxExecutionAtEnum {
	CALL_BACK_FROM_CONSUMER("CALL_BACK_FROM_CONSUMER"),
	
	CALL_BACK_TO_PRODUCER("CALL_BACK_TO_PRODUCER");

	private String value;

	private GDSCPostBoxExecutionAtEnum(String value){
		this.value = value;

	}

	public String getValue() {
		return value;
	}
}
