package com.zycus.integration.GDS.scheduler;

import java.util.concurrent.Callable;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.zycus.integration.GDS.constant.DeliveryTypeConstant;
import com.zycus.integration.GDS.service.GDSCService;
/**
 * 
 * @author narendra.m
 *
 */
public class SchedulerJob implements Callable<Integer> {

	private static final Logger LOG = LoggerFactory.getLogger(SchedulerJob.class);

	private GDSCService gdscService;
	private String taskType;

	public SchedulerJob(GDSCService gdscService, String taskType) {
		super();
		this.gdscService = gdscService;
		this.taskType = taskType;
	}

	@Override
	public Integer call() throws Exception {
		switch (taskType) {
		case DeliveryTypeConstant.GDS:
			LOG.info("Initializing Consumer GDS Delivery of Pending data");
			gdscService.processCGDSPendingDeliveryData();
			break;
		case DeliveryTypeConstant.QUEUE:
			LOG.info("Initializing QUEUE Delivery of Pending data");
			gdscService.processQueuePendingDeliveryData();
			break;
		case DeliveryTypeConstant.TOPIC:
			LOG.info("Initializing TOPIC Delivery of Pending data");
			gdscService.processTopicPendingDeliveryData();
			break;
		case DeliveryTypeConstant.HTTP:
			LOG.info("Initializing HTTP Delivery of Pending data");
			gdscService.processHttpPendingDeliveryData();
			break;
		}
		return null;
	}

}