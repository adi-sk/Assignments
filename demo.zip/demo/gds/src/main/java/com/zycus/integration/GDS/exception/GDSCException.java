
package com.zycus.integration.GDS.exception;
/**
 *punit.sukhija
 *
 */
public class GDSCException extends Throwable{

	
	private String errorCode;
	private String errorMessage;
	
	public GDSCException() {
		super();
		// TODO Auto-generated constructor stub
	}
	public GDSCException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
		// TODO Auto-generated constructor stub
	}
	public GDSCException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}
	public GDSCException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}
	public GDSCException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}
	
	public GDSCException(String errorCode, String errorMessage , Throwable cause) {
		super(errorMessage, cause);
		this.errorCode = errorCode;
		this.errorMessage = errorMessage;
	}
	public String getErrorCode() {
		return errorCode;
	}
	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}
	public String getErrorMessage() {
		return errorMessage;
	}
	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}
}
