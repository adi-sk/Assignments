package com.zycus.integration.GDS.pojo;

import java.util.List;

public class RuleDetails {

	private List<RuleData> ruleData;

	public List<RuleData> getRuleData() {
		return ruleData;
	}

	public void setRuleData(List<RuleData> ruleData) {
		this.ruleData = ruleData;
	}
	
}
