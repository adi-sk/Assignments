package com.zycus.integration.GDS.pojo;

public class ResponseAck {

	Acknowledge acknowledge;

	public Acknowledge getAcknowledge() {
		return acknowledge;
	}

	public void setAcknowledge(Acknowledge acknowledge) {
		this.acknowledge = acknowledge;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((acknowledge == null) ? 0 : acknowledge.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		ResponseAck other = (ResponseAck) obj;
		if (acknowledge == null) {
			if (other.acknowledge != null)
				return false;
		} else if (!acknowledge.equals(other.acknowledge))
			return false;
		return true;
	}
	
}
