package com.zycus.guaranteed_delivery_consumer.dto;

import java.sql.Connection;

/**
 * For Product to send DB information.
 * @author narendra.m
 *
 */
public class DBConnection {
	
	private Connection connection;
	
	private boolean hibernateToUse = false;
	
	private boolean connectionCloseRequired;

	public Connection getConnection() {
		return connection;
	}

	public void setConnection(Connection connection) {
		this.connection = connection;
	}

	public boolean isHibernateToUse() {
		return hibernateToUse;
	}

	public boolean isConnectionCloseRequired() {
		return connectionCloseRequired;
	}

	public void setConnectionCloseRequired(boolean connectionCloseRequired) {
		this.connectionCloseRequired = connectionCloseRequired;
	}

}
