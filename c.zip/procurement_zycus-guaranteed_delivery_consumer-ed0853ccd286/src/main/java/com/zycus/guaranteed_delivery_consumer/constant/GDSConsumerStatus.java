package com.zycus.guaranteed_delivery_consumer.constant;

public interface GDSConsumerStatus {

	/**
	 * Constant Represents Request in processing Status 
	 */
	String GDSCONSUMER_PROCESSING="PROCESSING";
	/**
	 * Constant Represents Request in Success Status 
	 */
	String GDSCONSUMER_SUCCESS="SUCCESS";
	
	/**
	 * Constant Represents Request in Failed Status 
	 */
	String GDSCONSUMER_FAILED="FAILED";
	/**
	 * Constant Represents Request in Parked Status 
	 */
	String GDSCONSUMER_PARKED="PARKED";
}
