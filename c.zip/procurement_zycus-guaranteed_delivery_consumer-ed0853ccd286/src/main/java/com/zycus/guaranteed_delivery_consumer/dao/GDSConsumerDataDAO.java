package com.zycus.guaranteed_delivery_consumer.dao;

import java.sql.Connection;
import java.util.Date;
import java.util.List;

import com.zycus.guaranteed_delivery_consumer.Exception.GDSConsumerException;
import com.zycus.guaranteed_delivery_consumer.dto.GDSCConsumerRequest;
import com.zycus.guaranteed_delivery_consumer.model.ConsumerProductDataDispatchModel;

public interface GDSConsumerDataDAO {

	public Long updateCapturedEventData(GDSCConsumerRequest gdscRequest,Connection connection,String productCode) throws GDSConsumerException;

	public boolean updateEventDispatchStatus(long gdsConsumerId,Connection connection,String status,long retryAttempt) throws GDSConsumerException;

	public boolean updateEventConsumptionExecutaionAt(long gdsConsumerId,Connection connection,String executionAt) throws GDSConsumerException;

	public boolean updateConsumerEventStatusAndExecutaionAt(long gdsConsumerId,String status,String executionAt,Connection connection) throws GDSConsumerException;

	public boolean updateProductResponseDate(long gdsConsumerId,Connection connection,Date productResponseDate) throws GDSConsumerException;

	public boolean updateErrorCodeAndErrorDescription(long gdsConsumerId, String errorCode, String errorDescription,String stackTrace,Connection connection) throws GDSConsumerException;

	public List<ConsumerProductDataDispatchModel> getPendingDispath(Connection connection,String productCode) throws GDSConsumerException;

	public Long checkDuplicate(String deliveryId, long producerId, String gdscId,Connection connection) throws GDSConsumerException;

	public boolean updateProductResponse(long gdsConsumerId, String productResponse,Connection dbConnection) throws GDSConsumerException;

	public boolean updateCentralGDSCallBackResponse(long gdsConsumerId, String cgdsAck,Connection dbConnection) throws GDSConsumerException;

	public List<ConsumerProductDataDispatchModel> getPendingForCallBack(Connection connection,String productCode) throws GDSConsumerException;
	
	public String getProductResponse(long gdsConsumerId,Connection connection) throws GDSConsumerException;

	public boolean getStatusOfEvent(long gdsConsumerId,Connection connection,String executionAt,String status) throws GDSConsumerException;
}
