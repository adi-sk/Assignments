package com.zycus.guaranteed_delivery_consumer.Exception;

/**
 * GDSProducerException is exception class related to GDS Producer Component.
 * 
 * @author Narendra M
 * @version 1.0
 *
 */

public class GDSConsumerException extends BaseException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String				errorMessage;
	private Throwable			cause;
	private String				errorCode;
	private String 				standardErrorCode;

	public GDSConsumerException(String message, String errorCode , Throwable cause)
	{
		super(message, errorCode, cause);
		this.errorMessage = message;
		this.cause = cause;
		this.errorCode = errorCode;
	}
	
	public GDSConsumerException(String message, String errorCode)
	{
		super(message, errorCode);
		this.errorMessage = message;
		this.errorCode = errorCode;
	}
	
	@Override
	public String getErrorMessage()
	{
		return errorMessage;
	}
	
	public void setErrorMessage(String errorMessage)
	{
		this.errorMessage = errorMessage;
	}
	
	public Throwable getCause()
	{
		return cause;
	}
	
	public void setCause(Throwable cause)
	{
		this.cause = cause;
	}
	
	@Override
	public String getErrorCode()
	{
		return errorCode;
	}
	
	public void setErrorCode(String errorCode)
	{
		this.errorCode = errorCode;
	}

	public String getStandardErrorCode() {
		return standardErrorCode;
	}
}
