package com.zycus.guaranteed_delivery_consumer.constant;

public interface GDSConsumerRestConstant {

	String DUPLICATE_YES = "YES";
	
	String DUPLICATE_NO = "NO";
	
}
