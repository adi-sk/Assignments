package com.zycus.guaranteed_delivery_consumer.constant;

public interface GDSConsumerDeliveryConstant {

	String PROCEED_WITH_REMAINING_SAME_EVENT = "TRUE";
}
