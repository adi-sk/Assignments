package com.zycus.guaranteed_delivery_consumer.service.impl;

import java.io.PrintWriter;
import java.io.StringWriter;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.zycus.guaranteed_delivery_consumer.Exception.GDSConsumerException;
import com.zycus.guaranteed_delivery_consumer.configuration.GDSConsumerConfiguration;
import com.zycus.guaranteed_delivery_consumer.constant.GDSConsumerRestConstant;
import com.zycus.guaranteed_delivery_consumer.dto.GDSCConsumerRequest;
import com.zycus.guaranteed_delivery_consumer.dto.GDSConsumerFailedResponse;
import com.zycus.guaranteed_delivery_consumer.dto.GDSConsumerSuccessResponse;
import com.zycus.guaranteed_delivery_consumer.enums.GDSConsumerErrorEnum;
import com.zycus.guaranteed_delivery_consumer.enums.GDSConsumerRestErrorEnum;
import com.zycus.guaranteed_delivery_consumer.service.GDSCConsumerRequestService;
import com.zycus.guaranteed_delivery_consumer.service.GDSConsumerService;
import com.zycus.guaranteed_delivery_consumer.util.GDSCConsumerRequestValidator;

@Service
public class GDSCConsumerRequestServiceImpl implements GDSCConsumerRequestService {

	private static final Logger LOG = LoggerFactory.getLogger(GDSCConsumerRequestServiceImpl.class);

	@Autowired
	private GDSConsumerService gdsConsumerService;
	
	@Autowired 
	private GDSConsumerConfiguration gdsConsumerConfiguration; 
	
	@Autowired
	private GDSCConsumerRequestValidator gdscConsumerRequestValidator;
	
	@Override
	public ResponseEntity<?> updateCapturedEventData(GDSCConsumerRequest gdsCConsumerRequest) {
		List<String> errorList = gdscConsumerRequestValidator.validateGDSCConsumerRequest(gdsCConsumerRequest);
		if(errorList.isEmpty()) {
			try {
				GDSConsumerSuccessResponse gdsConsumerSuccessResponse = gdsConsumerService.updateCapturedEventData(gdsCConsumerRequest,gdsConsumerConfiguration.getProductCode());
				if(gdsConsumerSuccessResponse.getDuplicate().equalsIgnoreCase(GDSConsumerRestConstant.DUPLICATE_NO)) {
					LOG.info("Consumer Request with Event Id - "+gdsCConsumerRequest.getEventInfo().getEventId()+" has been saved Successfully");
				}else {
					LOG.info("Consumer Request with Event Id - "+gdsCConsumerRequest.getEventInfo().getEventId()+" already exist(Duplicate Record)");
				}
				return new ResponseEntity<GDSConsumerSuccessResponse>(gdsConsumerSuccessResponse,HttpStatus.OK);
			} catch (GDSConsumerException e) {
				LOG.error("Unable to save Consumer Request for Event ID - "+gdsCConsumerRequest.getEventInfo().getEventId()+",Due to {} ", e);
				GDSConsumerFailedResponse gdsConsumerFailedResponse = setErrorResponse(e.getErrorCode(), e.getErrorMessage(),e);
				return new ResponseEntity<GDSConsumerFailedResponse>(gdsConsumerFailedResponse,HttpStatus.INTERNAL_SERVER_ERROR);
			}catch (Exception e) {
				LOG.error("Unable to save Consumer Request for Event ID - "+gdsCConsumerRequest.getEventInfo().getEventId()+",Due to {} ", e);
				GDSConsumerFailedResponse gdsConsumerFailedResponse = setErrorResponse(GDSConsumerRestErrorEnum.GDSCCONSUMERREST_OTHER_EXCEPTION.getValue(), GDSConsumerRestErrorEnum.GDSCCONSUMERREST_OTHER_EXCEPTION.getText(), e);
				return new ResponseEntity<GDSConsumerFailedResponse>(gdsConsumerFailedResponse,HttpStatus.INTERNAL_SERVER_ERROR);
			}
		}else {
			StringBuilder errorMessage=new StringBuilder();
			for(String error : errorList) {
				errorMessage.append(error + "\n");
			}
			if(gdsCConsumerRequest.getEventInfo()==null) {
				LOG.error("Unable to save Consumer Request ,Due to {} ",errorMessage);
			}else {
				LOG.error("Unable to save Consumer Request for Event ID - "+gdsCConsumerRequest.getEventInfo().getEventId()+",Due to {} ",errorMessage);
			}
			GDSConsumerFailedResponse gdsConsumerFailedResponse = setErrorResponse(GDSConsumerErrorEnum.GDS_CONSUMER_VALIDATION_FAILED.getValue(), GDSConsumerErrorEnum.GDS_CONSUMER_VALIDATION_FAILED.getText(), new GDSConsumerException(errorMessage.toString(),GDSConsumerErrorEnum.GDS_CONSUMER_VALIDATION_FAILED.getValue()));
			return new ResponseEntity<GDSConsumerFailedResponse>(gdsConsumerFailedResponse,HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	private GDSConsumerFailedResponse setErrorResponse(String errorCode, String executionAt, Exception e) {
		StringWriter errors = new StringWriter();
		e.printStackTrace(new PrintWriter(errors));
		GDSConsumerFailedResponse gdsConsumerFailedResponse=new GDSConsumerFailedResponse();
		gdsConsumerFailedResponse.setErrorCode(errorCode);
		gdsConsumerFailedResponse.setExecutionAt(executionAt);
		gdsConsumerFailedResponse.setStackTrace(errors.toString());
		return gdsConsumerFailedResponse;
	}
}
