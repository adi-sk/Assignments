package com.zycus.guaranteed_delivery_consumer.schedulerjob;

import java.util.Date;
import java.util.TreeSet;
import java.util.concurrent.Callable;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.zycus.guaranteed_delivery_consumer.Exception.GDSConsumerException;
import com.zycus.guaranteed_delivery_consumer.configuration.GDSConsumerConfiguration;
import com.zycus.guaranteed_delivery_consumer.constant.BaseConstant;
import com.zycus.guaranteed_delivery_consumer.constant.ConsumerExecutionAt;
import com.zycus.guaranteed_delivery_consumer.constant.GDSConsumerStatus;
import com.zycus.guaranteed_delivery_consumer.dto.CallBackResponse;
import com.zycus.guaranteed_delivery_consumer.dto.DBConnection;
import com.zycus.guaranteed_delivery_consumer.enums.CallBackEnum;
import com.zycus.guaranteed_delivery_consumer.enums.GDSConsumerErrorEnum;
import com.zycus.guaranteed_delivery_consumer.model.ConsumerProductDataDispatchModel;
import com.zycus.guaranteed_delivery_consumer.service.ConsumerProductCallBack;
import com.zycus.guaranteed_delivery_consumer.service.GDSConsumerService;
import com.zycus.guaranteed_delivery_consumer.util.ClusterLeaderConsumer;

public class ProductDispatchJob implements Callable<String> {

	private  final Logger LOG = LoggerFactory.getLogger(ProductDispatchJob.class);
	private TreeSet<ConsumerProductDataDispatchModel> consumerProductDataDispatchModels; 
	private GDSConsumerService gdsConsumerService; 
	private ConsumerProductCallBack consumerProductCallBack; 
	private ClusterLeaderConsumer clusterLeader; 
	private String keyOrder; 
	private GDSConsumerConfiguration gdsConsumerConfiguration; 
	private DBConnection dbConnection;

	public ProductDispatchJob(TreeSet<ConsumerProductDataDispatchModel> consumerProductDataDispatchModels, GDSConsumerService gdsConsumerService,
			ConsumerProductCallBack consumerProductCallBack, ClusterLeaderConsumer clusterLeader, String keyOrder,
			GDSConsumerConfiguration gdsConsumerConfiguration, DBConnection dbConnection) {
		super();
		this.consumerProductDataDispatchModels = consumerProductDataDispatchModels;
		this.gdsConsumerService = gdsConsumerService;
		this.consumerProductCallBack = consumerProductCallBack;
		this.clusterLeader = clusterLeader;
		this.keyOrder = keyOrder;
		this.gdsConsumerConfiguration = gdsConsumerConfiguration;
		this.dbConnection = dbConnection;
	}



	@Override
	public String call() throws Exception {
		boolean proceedWithRemainingSameEvent=gdsConsumerConfiguration.getProceedWithRemainingSameEvent(); 
		keyOrder = BaseConstant.DISPATCH_MODE+keyOrder;
		if(acquireLock(keyOrder)) {
			for(ConsumerProductDataDispatchModel consumerProductDataDispatchModel:consumerProductDataDispatchModels) {
				long gdsConsumerId = consumerProductDataDispatchModel.getGdscConsumerId();
				long retryAttempts=consumerProductDataDispatchModel.getRetryAttempts();
				if(gdsConsumerService.getStatusOfEvent(gdsConsumerId,dbConnection,ConsumerExecutionAt.DISPATCH_EVENT_MESSAGE,GDSConsumerStatus.GDSCONSUMER_SUCCESS)) {
					LOG.info("Dispatching consumer Id - "+gdsConsumerId+" with Event Id - "+consumerProductDataDispatchModel.getEventId()+"  to product");
					try {
						boolean dispatchflag = gdsConsumerService.updateConsumerEventExecutionAtDispatchAndStatusInProgressing(gdsConsumerId, dbConnection);
						if(dispatchflag) {
							CallBackResponse response = consumerProductCallBack.OnMessage(consumerProductDataDispatchModel);
							if(response!=null && response.getStatus()==CallBackEnum.SUCCESS) {
								LOG.info("Dispatching consumer Id - "+gdsConsumerId+" with Event Id - "+consumerProductDataDispatchModel.getEventId()+"  to product successful");
								gdsConsumerService.updateProductResponse(gdsConsumerId, response, dbConnection);
								gdsConsumerService.updateEventConsumptionSuccess(gdsConsumerId, dbConnection,retryAttempts);
								centralGDSCallBack(dbConnection, consumerProductDataDispatchModel, gdsConsumerId, response);
							}else {
								if(response.getStatus()==CallBackEnum.PARKED || retryAttempts>=gdsConsumerConfiguration.getRetryAttempt()) {
									if(gdsConsumerService.getStatusOfEvent(gdsConsumerId,dbConnection,ConsumerExecutionAt.DISPATCH_EVENT_MESSAGE,GDSConsumerStatus.GDSCONSUMER_SUCCESS)) {
										LOG.info("Dispatching consumer Id - "+gdsConsumerId+" with Event Id - "+consumerProductDataDispatchModel.getEventId()+"  to product has been Parked");
										gdsConsumerService.updateEventConsumptionParked(gdsConsumerId, dbConnection,retryAttempts);
									}
								}else {
									if(gdsConsumerService.getStatusOfEvent(gdsConsumerId,dbConnection,ConsumerExecutionAt.DISPATCH_EVENT_MESSAGE,GDSConsumerStatus.GDSCONSUMER_SUCCESS)) {
										LOG.info("Dispatching consumer Id - "+gdsConsumerId+" with Event Id - "+consumerProductDataDispatchModel.getEventId()+"  to product has been failed");
										gdsConsumerService.updateEventConsumptionFailed(gdsConsumerId, dbConnection,retryAttempts+1);
									}
								}
								gdsConsumerService.updateProductResponse(gdsConsumerId, response, dbConnection);
								if(!proceedWithRemainingSameEvent) {
									break;
								}
							}
						}
					}
					catch (GDSConsumerException e) {
						LOG.error("Unable to dispatch Messages with Consumer Id -"+gdsConsumerId+" with Event Id - "+consumerProductDataDispatchModel.getEventId()+" to Product, Due to {}", e);
						updateDispatchFailed(dbConnection, gdsConsumerId, e,e.getErrorCode(), e.getErrorMessage(),retryAttempts+1);
						if(!proceedWithRemainingSameEvent) {
							break;
						}
					}catch (Exception e) {
						LOG.error("Unable to dispatch Messages with Consumer Id -"+gdsConsumerId+" with Event Id - "+consumerProductDataDispatchModel.getEventId()+" to Product, Due to {}", e);
						updateDispatchFailed(dbConnection, gdsConsumerId, e,GDSConsumerErrorEnum.OTHER_EXCEPTION_AT_DISPATCH.getValue(), e.getMessage(),retryAttempts+1);
						if(!proceedWithRemainingSameEvent) {
							break;
						}
					}	
				}else {
					LOG.info("Checking status for dispatch to product for Event id - "+gdsConsumerId);
					Thread thread = new Thread(new ManualExitJobs(gdsConsumerService, dbConnection, gdsConsumerId,ConsumerExecutionAt.DISPATCH_EVENT_MESSAGE,GDSConsumerStatus.GDSCONSUMER_SUCCESS,retryAttempts+1));
					thread.start();
				}
			}
			releaseAndDeleteLock(keyOrder);
			return keyOrder +BaseConstant.LOCK_ACQ_SUCCESS_MSG;
		}else {
			releaseLockOnTimeExceed(keyOrder);
			return keyOrder +BaseConstant.LOCK_ACQ_FAILED_MSG;
		}
	}
	private void centralGDSCallBack(DBConnection dbConnection, ConsumerProductDataDispatchModel consumerProductDataDispatchModel, long gdsConsumerId,
			CallBackResponse response) {
		try {
			gdsConsumerService.centralGDSCallBack(dbConnection, consumerProductDataDispatchModel, response);
		}catch (Exception e) {
			LOG.error("Unable to make Call back to CGDS for Consumer Id -"+gdsConsumerId+" with Event Id - "+consumerProductDataDispatchModel.getEventId()+", Due to {}", e);
		}
	}

	private void updateDispatchFailed(DBConnection dbConnection, long gdsConsumerId, Exception e,String errorCode,String errorDescription,long retryAttempts) throws GDSConsumerException {
		gdsConsumerService.updateEventConsumptionFailed(gdsConsumerId, dbConnection,retryAttempts);
		gdsConsumerService.updateErrorCodeErrorDescriptionStackTrace(gdsConsumerId,errorCode,errorDescription,e.getMessage(), dbConnection);
		consumerProductCallBack.sendNotifcation("Unable to dispatch Messages for Consumer Id - "+gdsConsumerId+" to Product {}"+ e);
	}

	private void releaseLockOnTimeExceed(String key) {
		String value = clusterLeader.getValueForKey(key);
		if(value!=null) {
			long time = Long.parseLong(value);
			Date date = new Date(time);
			Date date1= new Date();
			long diff = date1.getTime() - date.getTime();
			long diffHours = diff / (60 * 60 * 1000);
			long diffMinutes = diff / (60 * 1000) % 60 + diffHours*60;
			if(diffMinutes>=BaseConstant.CONSUL_LOCK_EXPIRE_TIME) {
				LOG.info("Lock has been released after "+BaseConstant.CONSUL_LOCK_EXPIRE_TIME +" for key - "+key);
				releaseAndDeleteLock(key);
			}
		}
	}

	private void releaseAndDeleteLock(String key) {
		clusterLeader.releaseLock(key);
		clusterLeader.removeKey(key);
	}
	private boolean acquireLock(String keyOrder) {
		return clusterLeader.accquireLeadership(keyOrder);
	}
}
