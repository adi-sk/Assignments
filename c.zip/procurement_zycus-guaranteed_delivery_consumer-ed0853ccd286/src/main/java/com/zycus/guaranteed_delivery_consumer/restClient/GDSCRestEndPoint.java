package com.zycus.guaranteed_delivery_consumer.restClient;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.ws.rs.core.Response;

import com.zycus.guaranteed_delivery_consumer.dto.Error;
import com.zycus.guaranteed_delivery_consumer.dto.Errors;
import com.zycus.guaranteed_delivery_consumer.dto.PostBoxMessage;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.HttpServerErrorException;
import org.springframework.web.client.ResourceAccessException;
import org.springframework.web.client.RestTemplate;

import com.zycus.guaranteed_delivery_consumer.constant.GDSRestResponseConstant;
import com.zycus.guaranteed_delivery_consumer.dto.GDSPostBoxMessage;

@Component
public class GDSCRestEndPoint
{

	private final Logger LOG = LoggerFactory.getLogger(GDSCRestEndPoint.class);

	public Response cgdsCallBack(GDSPostBoxMessage postBoxMessage, String consulUrl, String endPoint)
	{
		String pipelineUrl;
		String bearerToken;
		RestTemplate restTemplate = new RestTemplate();
		pipelineUrl = restTemplate.getForObject(consulUrl + "/GDS/PIPELINE/CONSUMER_CALLBACK/URL?raw", String.class);
		bearerToken = restTemplate.getForObject(consulUrl + "/GDS/PIPELINE/CONSUMER_CALLBACK/BEARER_TOKEN?raw", String.class);
		String URL = endPoint + pipelineUrl;
		HttpMethod httpMethod = HttpMethod.POST;
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);
		headers.set("Authorization", "Bearer " + bearerToken);
		Map<String, Object> data = new HashMap<String, Object>();
		data.put("gdsPostBoxMessage", postBoxMessage);
		HttpEntity<Map<String, Object>> request = new HttpEntity<Map<String, Object>>(data, headers);
		ResponseEntity<String> response = null;
		try
		{
			response = restTemplate.exchange(URL.replace("http://", "https://"), httpMethod, request, String.class);
			return Response.status(response.getStatusCode().value()).entity(response.getBody()).build();
		}
		catch (HttpServerErrorException e)
		{
			return Response.status(Response.Status.INTERNAL_SERVER_ERROR).entity(e.getResponseBodyAsString()).build();
		}
		catch (HttpClientErrorException e)
		{
			return Response.status(Response.Status.INTERNAL_SERVER_ERROR).entity(e.getResponseBodyAsString()).build();
		}
		catch (ResourceAccessException e)
		{
			LOG.error("Failed to send to CGDS due to {} ", e);
			return Response.status(GDSRestResponseConstant.SEND_CONNECTION_TIMEOUT).entity(e.getMessage()).build();
		}
		catch (Exception e)
		{
			LOG.error("Failed to send to CGDS due to {} ", e);
			return Response.status(GDSRestResponseConstant.OTHER_EXCEPTION).entity(e.getMessage().toString()).build();
		}

	}

}
