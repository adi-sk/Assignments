package com.zycus.guaranteed_delivery_consumer.configuration;

import java.util.Properties;
import java.util.TimeZone;

import org.quartz.CronScheduleBuilder;
import org.quartz.CronTrigger;
import org.quartz.JobBuilder;
import org.quartz.JobDetail;
import org.quartz.Trigger;
import org.quartz.TriggerBuilder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.quartz.SchedulerFactoryBean;

import com.zycus.guaranteed_delivery_consumer.constant.ConsumerSchedularConstant;
import com.zycus.guaranteed_delivery_consumer.schedulerjob.GDSConsumerScheduler;

@Configuration
public class SchedulerConsumerConfig {

	private JobDetail jobDetails = null;
	private Trigger triggers = null;

	@Autowired
	private ApplicationContext applicationContext;

	@Autowired
	private GDSConsumerConfiguration gdsConsumerConfiguration;

	@Bean(name=ConsumerSchedularConstant.SCHEDULER_BEAN_NAME)
	SchedulerFactoryBean consumerQuartzScheduler() {
		SchedulerFactoryBean quartzScheduler = new SchedulerFactoryBean();
		Properties quartzProperties = new Properties();
		quartzProperties.setProperty("org.quartz.scheduler.instanceName", ConsumerSchedularConstant.INSTANCENAME);
		quartzProperties.setProperty("org.quartz.scheduler.instanceId", ConsumerSchedularConstant.INSTANCEID);
		quartzProperties.setProperty("org.quartz.threadPool.threadCount", checkforActualAndPredefined(gdsConsumerConfiguration.getThreadCount(),ConsumerSchedularConstant.THREADCOUNT));
		quartzProperties.setProperty("org.quartz.jobStore.class", ConsumerSchedularConstant.JOBSTORECLASS);
		quartzScheduler.setQuartzProperties(quartzProperties);

		AutowiringSpringBeanJobFactory jobFactory = new AutowiringSpringBeanJobFactory();
		jobFactory.setApplicationContext(applicationContext);
		quartzScheduler.setJobFactory(jobFactory);
		if(gdsConsumerConfiguration.getQuartzStartUpDelay()==null) {
			quartzScheduler.setStartupDelay(ConsumerSchedularConstant.QUARTZ_STARTUP_DELAY);
		}else {
			quartzScheduler.setStartupDelay(gdsConsumerConfiguration.getQuartzStartUpDelay());
		}
		quartzScheduler.setJobDetails(jobDetails());
		quartzScheduler.setTriggers(quartzTriggers());
		quartzScheduler.setOverwriteExistingJobs(true);
		quartzScheduler.setAutoStartup(true);
		quartzScheduler.setSchedulerName(ConsumerSchedularConstant.SCHEDULER_NAME);
		return quartzScheduler;
	}

	public JobDetail jobDetails() {
		jobDetails = JobBuilder.newJob(GDSConsumerScheduler.class).storeDurably()
				.withIdentity(ConsumerSchedularConstant.SCHEDULER_JOB_NAME, ConsumerSchedularConstant.SCHEDULER_GROUP).build();
		return jobDetails;
	}

	public Trigger quartzTriggers() {
		String cronExpression=ConsumerSchedularConstant.QUARTZ_CRON_EXPRESSION;
		if(!checkIfNullNEmpty(gdsConsumerConfiguration.getCronExpression())) {
			cronExpression = gdsConsumerConfiguration.getCronExpression();
		}
		CronTrigger consumerJobTriger = TriggerBuilder.newTrigger().forJob(jobDetails)
				.withIdentity(ConsumerSchedularConstant.SCHEDULER_TRIGGER_NAME, ConsumerSchedularConstant.SCHEDULER_GROUP)
				.withSchedule(CronScheduleBuilder.cronSchedule(cronExpression)
						.withMisfireHandlingInstructionDoNothing().inTimeZone(TimeZone.getTimeZone("UTC")))
				.build();
		triggers = consumerJobTriger;
		return triggers;
	}

	private boolean checkIfNullNEmpty(String str) {
		return ( str == null || str.isEmpty()) ? true : false;
	}

	private String checkforActualAndPredefined(String actual,String predefined) {
		return (actual == null || actual.isEmpty()) ? predefined : actual;
	}
}
