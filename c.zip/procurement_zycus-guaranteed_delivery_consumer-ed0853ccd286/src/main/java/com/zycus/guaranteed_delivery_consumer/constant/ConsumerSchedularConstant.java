package com.zycus.guaranteed_delivery_consumer.constant;

public interface ConsumerSchedularConstant {
	
	String SCHEDULER_BEAN_NAME="CONSUMER";

	String SCHEDULER_NAME="CONSUMER_SCHEDULER";

	String SCHEDULER_GROUP = "CONSUMER";

	String SCHEDULER_JOB_NAME="CONSUMER_JOB";

	String SCHEDULER_TRIGGER_NAME="CONSUMER_JOB_TRIGGER";
	
	String INSTANCENAME = "GDS_CONSUMER";
	
	String INSTANCEID = "INSTANCE_CONSUMER";
	
	String THREADCOUNT = "5";
	
	String QUARTZClASS = "org.quartz.impl.jdbcjobstore.JobStoreTX";
	
	String DRIVERDELEGATECLASS = "org.quartz.impl.jdbcjobstore.StdJDBCDelegate";
	
	String TABLEPREFIX = "QRTZ_";
	
	String ISCLUSTERED = "true";
	
	String DATASOURCE = "myDS";
	
	String MISFIRETHRESHOLD = "25000";
	
	String MAXCONNECTIONS = "5";
	
	String VALIDATIONQUERY = "select 1";
	
	String SELECTWITHLOCKSQL = "SELECT * FROM {0}LOCKS UPDLOCK WHERE LOCK_NAME = ?";

	String QUARTZ_CRON_EXPRESSION = "0/15 * * 1/1 * ?";

	int QUARTZ_STARTUP_DELAY = 10;
	
	String JOBSTORECLASS = "org.quartz.simpl.RAMJobStore";
	
}
