package com.zycus.guaranteed_delivery_consumer.service;

import org.springframework.http.ResponseEntity;

import com.zycus.guaranteed_delivery_consumer.dto.GDSCConsumerRequest;

public interface GDSCConsumerRequestService {
	
	public ResponseEntity<?> updateCapturedEventData(GDSCConsumerRequest gdsCConsumerRequest);

}
