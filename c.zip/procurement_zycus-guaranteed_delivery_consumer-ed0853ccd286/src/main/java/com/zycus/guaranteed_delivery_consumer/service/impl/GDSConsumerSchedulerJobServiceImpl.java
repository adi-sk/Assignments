package com.zycus.guaranteed_delivery_consumer.service.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.TreeSet;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.zycus.guaranteed_delivery_consumer.Exception.GDSConsumerException;
import com.zycus.guaranteed_delivery_consumer.configuration.GDSConsumerConfiguration;
import com.zycus.guaranteed_delivery_consumer.dao.GDSConsumerDAO;
import com.zycus.guaranteed_delivery_consumer.dto.DBConnection;
import com.zycus.guaranteed_delivery_consumer.model.ConsumerProductDataDispatchModel;
import com.zycus.guaranteed_delivery_consumer.schedulerjob.CallBackToCGDSJob;
import com.zycus.guaranteed_delivery_consumer.schedulerjob.ProductDispatchJob;
import com.zycus.guaranteed_delivery_consumer.service.ConsumerProductCallBack;
import com.zycus.guaranteed_delivery_consumer.service.GDSConsumerSchedulerJobService;
import com.zycus.guaranteed_delivery_consumer.service.GDSConsumerService;
import com.zycus.guaranteed_delivery_consumer.util.ClusterLeaderConsumer;

@Service
public class GDSConsumerSchedulerJobServiceImpl implements GDSConsumerSchedulerJobService {

	private static final Logger LOG = LoggerFactory.getLogger(GDSConsumerSchedulerJobServiceImpl.class);

	@Autowired
	private GDSConsumerService gdsConsumerService;

	@Autowired
	private ConsumerProductCallBack consumerProductCallBack;

	@Autowired
	private GDSConsumerConfiguration gdsConsumerConfiguration;

	@Autowired
	private ClusterLeaderConsumer clusterLeader;

	@Autowired
	private GDSConsumerDAO gdsConsumerDAO;

	@Override
	public void dispatchMessageToProduct(DBConnection dbConnection) {

		try {
			LOG.info("Getting pending consumer Event's for dispatch...");
			List<ConsumerProductDataDispatchModel> consumerProductDataDispatchModels = gdsConsumerService.getPendingDispath(dbConnection,gdsConsumerConfiguration.getProductCode());
			if(consumerProductDataDispatchModels.isEmpty()) {
				LOG.info("No consumer Event's pending for dispatch.");
			}else {
				Map<String, TreeSet<ConsumerProductDataDispatchModel>> chunks=new HashMap<String, TreeSet<ConsumerProductDataDispatchModel>>();
				LinkedHashSet<String> keyOrders=new LinkedHashSet<String>();

				//create chunks
				createChunks(consumerProductDataDispatchModels, chunks, keyOrders);

				//send to product
				ExecutorService executor = Executors.newFixedThreadPool(keyOrders.size());
				List<Future<String>> list = new ArrayList<Future<String>>();
				LOG.info("Sending event's to consumer's ConsumerProductCallBack->OnMessage() method...");
				for(String keyOrder : keyOrders) {
					Callable<String> callable = new ProductDispatchJob(chunks.get(keyOrder),gdsConsumerService,consumerProductCallBack,clusterLeader,keyOrder,gdsConsumerConfiguration,dbConnection);
					Future<String> future = executor.submit(callable);
					list.add(future);
				}
				for(Future<String> fut : list){
					try {
						LOG.info(" Dispatch Processed event for key - "+fut.get());
					} catch (InterruptedException e) {
						e.printStackTrace();
					} catch (ExecutionException e) {
						e.printStackTrace();
					}
				}
				LOG.info("End of event's to consumer's ConsumerProductCallBack->OnMessage() method.");
				executor.shutdown();

			}
		} catch (GDSConsumerException e) {
			LOG.error("Unable to dispatch Messages to Product {}", e);
			consumerProductCallBack.sendNotifcation("Unable to dispatch Messages to Product {}"+ e);
		}
	}

	private void createChunks(List<ConsumerProductDataDispatchModel> consumerProductDataDispatchModels,Map<String, TreeSet<ConsumerProductDataDispatchModel>> chunks, LinkedHashSet<String> keyOrders) {
		LOG.info("Creating chunks to Consumer for dispatching...");
		for(ConsumerProductDataDispatchModel consumerProductDataDispatchModel : consumerProductDataDispatchModels) {
			String key = getKey(consumerProductDataDispatchModel);
			TreeSet<ConsumerProductDataDispatchModel> chunk=chunks.get(key);
			keyOrders.add(key);

			if(chunk==null) {
				TreeSet<ConsumerProductDataDispatchModel> treeConsumerProductDataDispatchModel= new TreeSet<ConsumerProductDataDispatchModel>();
				treeConsumerProductDataDispatchModel.add(consumerProductDataDispatchModel);
				chunks.put(key,treeConsumerProductDataDispatchModel);
			}else {
				chunk.add(consumerProductDataDispatchModel);
			}
		}
	}

	public String getKey(ConsumerProductDataDispatchModel consumerProductDataDispatchModel) {
		return consumerProductDataDispatchModel.getSourceProductCode()+consumerProductDataDispatchModel.getEntityType()+consumerProductDataDispatchModel.getEntityId(); 
	}

	@Override
	public void callBackToCentralGDS(DBConnection dbConnection) {
		try {
			LOG.info("Getting pending consumer Event's for Call Back...");
			List<ConsumerProductDataDispatchModel> consumerProductDataDispatchModels = gdsConsumerService.getPendingForCallBack(dbConnection,gdsConsumerConfiguration.getProductCode());
			if(consumerProductDataDispatchModels.isEmpty()) {
				LOG.info("No consumer Event's pending for Call Back.");
			}else {
				Map<String, TreeSet<ConsumerProductDataDispatchModel>> chunks=new HashMap<String, TreeSet<ConsumerProductDataDispatchModel>>();
				LinkedHashSet<String> keyOrders=new LinkedHashSet<String>();

				//create chunks
				createChunks(consumerProductDataDispatchModels, chunks, keyOrders);

				//send to product
				ExecutorService executor = Executors.newFixedThreadPool(keyOrders.size());
				List<Future<String>> list = new ArrayList<Future<String>>();
				LOG.info("Sending event's to CGDS CallBack...");
				for(String keyOrder : keyOrders) {
					Callable<String> callable = new CallBackToCGDSJob(chunks.get(keyOrder),gdsConsumerService,consumerProductCallBack,clusterLeader,keyOrder,gdsConsumerDAO,dbConnection);
					Future<String> future = executor.submit(callable);
					list.add(future);
				}
				for(Future<String> fut : list){
					try {
						LOG.info("CallBack Processed event for key - "+fut.get());
					} catch (InterruptedException e) {
						e.printStackTrace();
					} catch (ExecutionException e) {
						e.printStackTrace();
					}
				}
				LOG.info("End of event's for Call Back to Central GDS.");
				executor.shutdown();
			}
		} catch (GDSConsumerException e) {
			LOG.error("Unable to make Call Back to CGDS {}", e);
			consumerProductCallBack.sendNotifcation("Unable to make Call Back to CGDS {}"+ e);
		}

	}

}
