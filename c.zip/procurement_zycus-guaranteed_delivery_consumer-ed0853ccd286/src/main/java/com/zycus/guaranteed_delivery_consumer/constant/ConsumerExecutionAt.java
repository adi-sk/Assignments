package com.zycus.guaranteed_delivery_consumer.constant;

public interface ConsumerExecutionAt {

	/**
	 * Represent's Event Request from product has been received
	 */
	String EVENT_RECEIVED = "EVENT_RECEIVED";
	
	/**
	 * Represent's an Event's Data is being/been captured
	 */
	String DISPATCH_EVENT_MESSAGE = "DISPATCH_EVENT_MESSAGE";
	
	/**
	 * Represent's an response sending back to product.
	 */
	String PRODUCT_CALL_BACK = "PRODUCT_CALL_BACK";

}
