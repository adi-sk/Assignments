package com.zycus.guaranteed_delivery_consumer.dto;

public class GDSConsumerFailedResponse {

	private String errorCode;

	private String executionAt;

	private String stackTrace;

	public String getErrorCode() {
		return errorCode;
	}

	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}

	public String getExecutionAt() {
		return executionAt;
	}

	public void setExecutionAt(String executionAt) {
		this.executionAt = executionAt;
	}

	public String getStackTrace() {
		return stackTrace;
	}

	public void setStackTrace(String stackTrace) {
		this.stackTrace = stackTrace;
	}

}
