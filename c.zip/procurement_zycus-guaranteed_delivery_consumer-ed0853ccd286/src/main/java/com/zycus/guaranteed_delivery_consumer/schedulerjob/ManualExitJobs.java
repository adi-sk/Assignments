package com.zycus.guaranteed_delivery_consumer.schedulerjob;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.zycus.guaranteed_delivery_consumer.dto.DBConnection;
import com.zycus.guaranteed_delivery_consumer.service.GDSConsumerService;

public class ManualExitJobs extends Thread{
	private final Logger LOG = LoggerFactory.getLogger(ManualExitJobs.class);

	private GDSConsumerService gdsConsumerService;
	private DBConnection dbConnection; 
	private long gdsConsumerId;
	private String excutionAt;
	private String status;
	private long retryAttempt;

	public ManualExitJobs(GDSConsumerService gdsConsumerService, DBConnection dbConnection, long gdsConsumerId,
			String excutionAt, String status,long retryAttempt) {
		super();
		this.gdsConsumerService = gdsConsumerService;
		this.dbConnection = dbConnection;
		this.gdsConsumerId = gdsConsumerId;
		this.excutionAt = excutionAt;
		this.status = status;
		this.retryAttempt = retryAttempt;
	}

	@Override
	public void run() {
		try {
			Thread.sleep(5000);
			if(!gdsConsumerService.getStatusOfEvent(gdsConsumerId,dbConnection,excutionAt,status)) {
				gdsConsumerService.updateEventConsumptionFailed(gdsConsumerId, dbConnection,retryAttempt);
			}
		} catch (Exception e) {
			LOG.error("Unable to make the thread sleep due to {}",e);
		} 
	}
}
