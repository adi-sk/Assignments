package com.zycus.guaranteed_delivery_consumer.configuration;

import com.zycus.guaranteed_delivery_consumer.Exception.GDSConsumerException;
import com.zycus.guaranteed_delivery_consumer.enums.GDSConsumerErrorEnum;

public class GDSConsumerConfiguration
{

	private boolean proceedWithRemainingSameEvent;

	private Integer quartzStartUpDelay;

	private String cronExpression;

	private String consulHost;

	private Integer consulPort;

	private String consulEnvironment;

	private String consulProductName;

	private String productCode;

	private String gdsEndPoint;

	private String threadCount;

	private long retryAttempt = 120;

	/**
	 *
	 * @param consulHost
	 * @param consulPort
	 * @param consulEnvironment
	 * @param consulProductName
	 * @param productCode
	 * @param gdsEndPoint
	 * @throws GDSConsumerException
	 */
	public GDSConsumerConfiguration(String consulHost, Integer consulPort, String consulEnvironment,
			String consulProductName, String productCode, String gdsEndPoint) throws GDSConsumerException
	{
		super();
		this.consulHost = consulHost;
		this.consulPort = consulPort;
		this.consulEnvironment = consulEnvironment;
		this.consulProductName = consulProductName;
		this.productCode = productCode;
		this.gdsEndPoint = gdsEndPoint;
		if (checkIfNullNEmpty(consulHost) || consulPort == null || checkIfNullNEmpty(consulEnvironment)
				|| checkIfNullNEmpty(consulProductName) || checkIfNullNEmpty(productCode) || checkIfNullNEmpty(
				gdsEndPoint))
		{
			throw new GDSConsumerException(GDSConsumerErrorEnum.GDS_CONSUMER_CONFIGURATION_FAILED.getText(),
					GDSConsumerErrorEnum.GDS_CONSUMER_CONFIGURATION_FAILED.getValue());
		}
	}

	/**
	 *
	 * @param consulHostAndPort
	 * @param consulEnvironment
	 * @param consulProductName
	 * @param productCode
	 * @param gdsEndPoint
	 * @throws GDSConsumerException
	 */
	public GDSConsumerConfiguration(String consulHostAndPort, String consulEnvironment, String consulProductName,
			String productCode, String gdsEndPoint) throws GDSConsumerException
	{
		this(consulHostAndPort.split(":")[0].trim(), Integer.parseInt(consulHostAndPort.split(":")[1].trim()),
				consulEnvironment, consulProductName, productCode, gdsEndPoint);
	}

	/**
	 *
	 * @param consulHost
	 * @param consulPort
	 * @param consulEnvironment
	 * @param consulProductName
	 * @param productCode
	 * @param gdsEndpoint
	 * @param quartzStartUpDelay
	 * @param cronExpression
	 * @param proceedWithRemainingSameEvent
	 * @throws GDSConsumerException
	 */
	public GDSConsumerConfiguration(String consulHost, Integer consulPort, String consulEnvironment,
			String consulProductName, String productCode, String gdsEndpoint, Integer quartzStartUpDelay,
			String cronExpression, boolean proceedWithRemainingSameEvent) throws GDSConsumerException
	{
		this(consulHost, consulPort, consulEnvironment, consulProductName, productCode, gdsEndpoint);
		this.cronExpression = cronExpression;
		this.quartzStartUpDelay = quartzStartUpDelay;
		this.proceedWithRemainingSameEvent = proceedWithRemainingSameEvent;

		if (quartzStartUpDelay == null || checkIfNullNEmpty(cronExpression) || checkIfNullNEmpty(productCode)
				|| checkIfNullNEmpty(gdsEndpoint))
		{
			throw new GDSConsumerException(GDSConsumerErrorEnum.GDS_CONSUMER_CONFIGURATION_FAILED.getText(),
					GDSConsumerErrorEnum.GDS_CONSUMER_CONFIGURATION_FAILED.getValue());
		}
	}

	public GDSConsumerConfiguration(String consulHost, Integer consulPort, String consulEnvironment,
			String consulProductName, String productCode, String gdsEndpoint, Integer quartzStartUpDelay,
			String cronExpression, boolean proceedWithRemainingSameEvent, String threadCount)
			throws GDSConsumerException
	{
		this(consulHost, consulPort, consulEnvironment, consulProductName, productCode, gdsEndpoint);
		this.cronExpression = cronExpression;
		this.quartzStartUpDelay = quartzStartUpDelay;
		this.proceedWithRemainingSameEvent = proceedWithRemainingSameEvent;
		this.threadCount = threadCount;

		if (quartzStartUpDelay == null || checkIfNullNEmpty(cronExpression) || checkIfNullNEmpty(productCode)
				|| checkIfNullNEmpty(gdsEndpoint) || checkIfNullNEmpty(threadCount))
		{
			throw new GDSConsumerException(GDSConsumerErrorEnum.GDS_CONSUMER_CONFIGURATION_FAILED.getText(),
					GDSConsumerErrorEnum.GDS_CONSUMER_CONFIGURATION_FAILED.getValue());
		}
	}

	public GDSConsumerConfiguration(String consulHost, Integer consulPort, String consulEnvironment,
			String consulProductName, String productCode, String gdsEndPoint, long retryAttempt)
			throws GDSConsumerException
	{
		this(consulHost, consulPort, consulEnvironment, consulProductName, productCode, gdsEndPoint);
		if (retryAttempt == 0)
		{
			throw new GDSConsumerException(GDSConsumerErrorEnum.GDS_CONSUMER_CONFIGURATION_FAILED.getText(),
					GDSConsumerErrorEnum.GDS_CONSUMER_CONFIGURATION_FAILED.getValue());
		}
	}

	public GDSConsumerConfiguration(String consulHost, Integer consulPort, String consulEnvironment,
			String consulProductName, String productCode, String gdsEndpoint, Integer quartzStartUpDelay,
			String cronExpression, boolean proceedWithRemainingSameEvent, long retryAttempt) throws GDSConsumerException
	{
		this(consulHost, consulPort, consulEnvironment, consulProductName, productCode, gdsEndpoint, retryAttempt);
		this.cronExpression = cronExpression;
		this.quartzStartUpDelay = quartzStartUpDelay;
		this.proceedWithRemainingSameEvent = proceedWithRemainingSameEvent;

		if (quartzStartUpDelay == null || checkIfNullNEmpty(cronExpression) || checkIfNullNEmpty(productCode)
				|| checkIfNullNEmpty(gdsEndpoint))
		{
			throw new GDSConsumerException(GDSConsumerErrorEnum.GDS_CONSUMER_CONFIGURATION_FAILED.getText(),
					GDSConsumerErrorEnum.GDS_CONSUMER_CONFIGURATION_FAILED.getValue());
		}
	}

	public GDSConsumerConfiguration(String consulHost, Integer consulPort, String consulEnvironment,
			String consulProductName, String productCode, String gdsEndpoint, Integer quartzStartUpDelay,
			String cronExpression, boolean proceedWithRemainingSameEvent, String threadCount, long retryAttempt)
			throws GDSConsumerException
	{
		this(consulHost, consulPort, consulEnvironment, consulProductName, productCode, gdsEndpoint, retryAttempt);
		this.cronExpression = cronExpression;
		this.quartzStartUpDelay = quartzStartUpDelay;
		this.proceedWithRemainingSameEvent = proceedWithRemainingSameEvent;
		this.threadCount = threadCount;

		if (quartzStartUpDelay == null || checkIfNullNEmpty(cronExpression) || checkIfNullNEmpty(productCode)
				|| checkIfNullNEmpty(gdsEndpoint) || checkIfNullNEmpty(threadCount))
		{
			throw new GDSConsumerException(GDSConsumerErrorEnum.GDS_CONSUMER_CONFIGURATION_FAILED.getText(),
					GDSConsumerErrorEnum.GDS_CONSUMER_CONFIGURATION_FAILED.getValue());
		}
	}

	public GDSConsumerConfiguration(String consulHostAndPort, String consulEnvironment, String consulProductName,
			String productCode, String gdsEndpoint, Integer quartzStartUpDelay, String cronExpression,
			boolean proceedWithRemainingSameEvent, String threadCount, long retryAttempts) throws GDSConsumerException
	{
		this(consulHostAndPort.split(":")[0].trim(), Integer.parseInt(consulHostAndPort.split(":")[1].trim()),
				consulEnvironment, consulProductName, productCode, gdsEndpoint, quartzStartUpDelay, cronExpression,
				proceedWithRemainingSameEvent, threadCount, retryAttempts);
		this.threadCount = threadCount;
	}

	public Integer getQuartzStartUpDelay()
	{
		return quartzStartUpDelay;
	}

	public String getCronExpression()
	{
		return cronExpression;
	}

	private boolean checkIfNullNEmpty(String str)
	{
		return (str == null || str.isEmpty()) ? true : false;
	}

	public Boolean getProceedWithRemainingSameEvent()
	{
		return proceedWithRemainingSameEvent;
	}

	public String getProductCode()
	{
		return productCode;
	}

	public String getGdsEndPoint()
	{
		return gdsEndPoint;
	}

	public void validateBean() throws GDSConsumerException
	{
		if (productCode == null || gdsEndPoint == null || consulHost == null || consulPort == null
				|| consulEnvironment == null || consulProductName == null)
		{
			throw new GDSConsumerException(GDSConsumerErrorEnum.GDS_CONSUMER_CONFIGURATION_FAILED.getText(),
					GDSConsumerErrorEnum.GDS_CONSUMER_CONFIGURATION_FAILED.getValue());
		}
	}

	public String getThreadCount()
	{
		return threadCount;
	}

	public String getConsulHost()
	{
		return consulHost;
	}

	public Integer getConsulPort()
	{
		return consulPort;
	}

	public String getConsulEnvironment()
	{
		return consulEnvironment;
	}

	public String getConsulProductName()
	{
		return consulProductName;
	}

	public long getRetryAttempt()
	{
		return retryAttempt;
	}

}
