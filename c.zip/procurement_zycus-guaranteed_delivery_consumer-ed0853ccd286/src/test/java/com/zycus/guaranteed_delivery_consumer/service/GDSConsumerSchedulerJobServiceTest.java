package com.zycus.guaranteed_delivery_consumer.service;

import java.sql.Connection;
import java.sql.DriverManager;

import javax.transaction.Transactional;

import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.context.SpringBootTest.WebEnvironment;
import org.springframework.test.context.junit4.SpringRunner;

import com.zycus.guaranteed_delivery_consumer.App;
import com.zycus.guaranteed_delivery_consumer.dto.DBConnection;

@RunWith(SpringRunner.class)
@SpringBootTest(webEnvironment = WebEnvironment.RANDOM_PORT,classes = {App.class, DatabaseConfiguration.class})
@Transactional
public class GDSConsumerSchedulerJobServiceTest {

	public static DBConnection dbConnection=null;

	@Autowired
	private GDSConsumerSchedulerJobService gdsConsumerSchedulerJobService;

	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
		System.setProperty("env", "INTEGRATION_BANGALORE");
		System.setProperty("productName", "PRODUCT_1");
		System.setProperty("configSourceHost", "10.10.10.153");
		System.setProperty("gdsProductName", "GUARANTEED-DELIVERY");

		dbConnection=new DBConnection();

		Class.forName("oracle.jdbc.driver.OracleDriver");
		Connection connection=DriverManager.getConnection("jdbc:oracle:thin:@192.168.2.197:1521:ORCL","GDS","GDS");  
		dbConnection.setConnection(connection);
	}

	@Test
	public void dispatchMessageToProductJDBC() {
		gdsConsumerSchedulerJobService.dispatchMessageToProduct(dbConnection);
	}
	
	@Test
	public void dispatchMessageToProductJDBCError() {
		gdsConsumerSchedulerJobService.dispatchMessageToProduct(getJDBCDBConnectionObjectError());
	}

	private DBConnection getJDBCDBConnectionObjectError() {
		DBConnection dbconnection=new DBConnection();
		dbconnection.setConnection(null);
		return dbconnection;
	}
}
