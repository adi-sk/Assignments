package com.zycus.guaranteed_delivery_consumer.util;

import java.util.List;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.junit4.SpringRunner;

import com.zycus.guaranteed_delivery_consumer.dto.GDSCConsumerRequest;

import uk.co.jemos.podam.api.PodamFactory;
import uk.co.jemos.podam.api.PodamFactoryImpl;

@RunWith(SpringRunner.class)
public class GDSCConsumerRequestValidatorTest {

	GDSCConsumerRequestValidator gdscConsumerRequestValidator = new GDSCConsumerRequestValidator();
	
	@Test
	public void testValidateGDSCConsumerRequest() {
		PodamFactory podam=new PodamFactoryImpl();
		GDSCConsumerRequest gdscConsumerRequest=podam.manufacturePojo(GDSCConsumerRequest.class);
		List<String> errorList = gdscConsumerRequestValidator.validateGDSCConsumerRequest(gdscConsumerRequest);
		Assert.assertEquals(0, errorList.size());
	}
	
	@Test
	public void testValidateGDSCConsumerRequestError() {
		PodamFactory podam=new PodamFactoryImpl();
		GDSCConsumerRequest gdscConsumerRequest=podam.manufacturePojo(GDSCConsumerRequest.class);
		gdscConsumerRequest.getEventInfo().setEventId(null);
		gdscConsumerRequest.setGdscId(null);
		List<String> errorList = gdscConsumerRequestValidator.validateGDSCConsumerRequest(gdscConsumerRequest);
		Assert.assertTrue(errorList.size()>=2);
	}
	@Test
	public void testValidateGDSCConsumerRequestError2() {
		PodamFactory podam=new PodamFactoryImpl();
		GDSCConsumerRequest gdscConsumerRequest=podam.manufacturePojo(GDSCConsumerRequest.class);
		gdscConsumerRequest.setEventInfo(null);
		List<String> errorList = gdscConsumerRequestValidator.validateGDSCConsumerRequest(gdscConsumerRequest);
		Assert.assertTrue(errorList.size()==1);
	}
}
