package com.zycus.guaranteed_delivery_consumer.service;

import java.sql.Connection;
import java.sql.DriverManager;
import java.util.Date;
import java.util.List;

import javax.transaction.Transactional;

import org.junit.Assert;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.context.SpringBootTest.WebEnvironment;
import org.springframework.test.context.junit4.SpringRunner;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.zycus.guaranteed_delivery_consumer.App;
import com.zycus.guaranteed_delivery_consumer.Exception.GDSConsumerException;
import com.zycus.guaranteed_delivery_consumer.configuration.GDSConsumerConfiguration;
import com.zycus.guaranteed_delivery_consumer.dto.DBConnection;
import com.zycus.guaranteed_delivery_consumer.dto.GDSCConsumerRequest;
import com.zycus.guaranteed_delivery_consumer.dto.GDSConsumerSuccessResponse;
import com.zycus.guaranteed_delivery_consumer.enums.GDSConsumerErrorEnum;
import com.zycus.guaranteed_delivery_consumer.model.ConsumerProductDataDispatchModel;

import uk.co.jemos.podam.api.PodamFactory;
import uk.co.jemos.podam.api.PodamFactoryImpl;

@RunWith(SpringRunner.class)
@SpringBootTest(webEnvironment = WebEnvironment.RANDOM_PORT,classes = {App.class, DatabaseConfiguration.class})
@Transactional
public class GDSConsumerServiceTest {

	private static final Logger LOG = LoggerFactory.getLogger(GDSConsumerServiceTest.class);

	@Autowired
	private GDSConsumerService gdsConsumerService;

	@Autowired
	private GDSConsumerConfiguration gdsConsumerConfiguration;
	
	long gdsConsumerId = 861;

	public static DBConnection dbConnection=null;
	@BeforeClass
	public static void setUpBeforeClass() throws Exception {

		dbConnection=new DBConnection();
		Class.forName("oracle.jdbc.driver.OracleDriver");
		Connection connection=DriverManager.getConnection("jdbc:oracle:thin:@192.168.2.197:1521:ORCL","GDS","GDS");  
		
		System.out.println(connection.getMetaData().getURL());
		dbConnection.setConnection(connection); 
	}

	@Test
	public void updateCapturedEventData() throws GDSConsumerException, JsonProcessingException {
		PodamFactory podam=new PodamFactoryImpl();
		GDSCConsumerRequest gdscConsumerRequest=podam.manufacturePojo(GDSCConsumerRequest.class);
		gdscConsumerRequest.setTimeStamp(new Date());
		gdscConsumerRequest.getEventInfo().setTimeStamp(new Date());
		GDSConsumerSuccessResponse gdSuccessResponse = gdsConsumerService.updateCapturedEventData(gdscConsumerRequest,gdsConsumerConfiguration.getProductCode());
		Assert.assertNotNull(gdSuccessResponse);
		LOG.info("GDSConsumerId - "+gdSuccessResponse.getGdsConsumerId());
		Assert.assertTrue("Primary Key Greater Than 0",Long.parseLong(gdSuccessResponse.getGdsConsumerId())>0 );
	}

	@Test
	public void updateEventConsumptionSuccessJDBC() throws GDSConsumerException {
		boolean flag = gdsConsumerService.updateEventConsumptionSuccess(gdsConsumerId, dbConnection,0);
		Assert.assertEquals("Updated Successfully", true, flag);
	}

	@Test
	public void updateEventConsumptionSuccessJDBCError() {
		try {
			gdsConsumerService.updateEventConsumptionSuccess(1, dbConnection,0);
		} catch (GDSConsumerException e) {
			Assert.assertEquals(GDSConsumerErrorEnum.INVALID_GDS_CONSUMER_ID.getText(), e.getErrorMessage());
			Assert.assertEquals(GDSConsumerErrorEnum.INVALID_GDS_CONSUMER_ID.getValue(), e.getErrorCode());
		}
	}


	@Test
	public void updateEventConsumptionFailedJDBC() throws GDSConsumerException {
		boolean flag = gdsConsumerService.updateEventConsumptionFailed(gdsConsumerId, dbConnection,1);
		Assert.assertEquals("Updated Successfully", true, flag);
	}

	@Test
	public void updateEventConsumptionFailedJDBCError() {
		try {
			gdsConsumerService.updateEventConsumptionFailed(1, dbConnection,1);
		} catch (GDSConsumerException e) {
			Assert.assertEquals(GDSConsumerErrorEnum.INVALID_GDS_CONSUMER_ID.getText(), e.getErrorMessage());
			Assert.assertEquals(GDSConsumerErrorEnum.INVALID_GDS_CONSUMER_ID.getValue(), e.getErrorCode());
		}
	}



	@Test
	public void updateConsumerEventExecutionAtDispatchAndStatusInProgressingJDBC() throws GDSConsumerException {
		boolean flag = gdsConsumerService.updateConsumerEventExecutionAtDispatchAndStatusInProgressing(gdsConsumerId, dbConnection);
		Assert.assertEquals("Updated Successfully", true, flag);
	}

	@Test
	public void updateConsumerEventExecutionAtDispatchAndStatusInProgressingJDBCError() {
		try {
			gdsConsumerService.updateConsumerEventExecutionAtDispatchAndStatusInProgressing(1, dbConnection);
		} catch (GDSConsumerException e) {
			Assert.assertEquals(GDSConsumerErrorEnum.INVALID_GDS_CONSUMER_ID.getText(), e.getErrorMessage());
			Assert.assertEquals(GDSConsumerErrorEnum.INVALID_GDS_CONSUMER_ID.getValue(), e.getErrorCode());
		}
	}

	@Test
	public void updateErrorCodeAndErrorDescriptionJDBC() throws GDSConsumerException {
		boolean flag = gdsConsumerService.updateErrorCodeErrorDescriptionStackTrace(gdsConsumerId, "TEST", "FAILED","exception",dbConnection); 
		Assert.assertEquals("Updated Successfully", true, flag);
	}

	@Test
	public void updateErrorCodeAndErrorDescriptionJDBCError(){
		try {
			gdsConsumerService.updateErrorCodeErrorDescriptionStackTrace(1,"TEST", "FAILED","exception", dbConnection);
		} catch (GDSConsumerException e) {
			Assert.assertEquals(GDSConsumerErrorEnum.INVALID_GDS_CONSUMER_ID.getText(), e.getErrorMessage());
			Assert.assertEquals(GDSConsumerErrorEnum.INVALID_GDS_CONSUMER_ID.getValue(), e.getErrorCode());
			e.printStackTrace();
		}
	}

	@Test
	public void getPendingDispathJDBC() throws GDSConsumerException {
		List<ConsumerProductDataDispatchModel> list = gdsConsumerService.getPendingDispath(dbConnection,gdsConsumerConfiguration.getProductCode());
		Assert.assertTrue(list.size()>=0);
	}
	@Test
	public void getPendingForCallBackJDBC() throws GDSConsumerException {
		List<ConsumerProductDataDispatchModel> list = gdsConsumerService.getPendingForCallBack(dbConnection,gdsConsumerConfiguration.getProductCode());
		Assert.assertTrue(list.size()>=0);
	}

}
