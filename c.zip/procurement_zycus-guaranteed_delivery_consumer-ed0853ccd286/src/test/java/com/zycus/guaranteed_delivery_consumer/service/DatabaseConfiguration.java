package com.zycus.guaranteed_delivery_consumer.service;

import java.util.Properties;

import javax.sql.DataSource;

import org.hibernate.SessionFactory;
import org.hibernate.jpa.HibernateEntityManagerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.env.Environment;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.orm.jpa.JpaTransactionManager;
import org.springframework.orm.jpa.LocalContainerEntityManagerFactoryBean;
import org.springframework.orm.jpa.vendor.HibernateJpaVendorAdapter;
import org.springframework.test.annotation.Rollback;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.TestPropertySource;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.annotation.EnableTransactionManagement;

import com.zycus.guaranteed_delivery_consumer.Exception.GDSConsumerException;
import com.zycus.guaranteed_delivery_consumer.configuration.GDSConsumerConfiguration;

@Configuration
@EnableJpaRepositories
@EnableTransactionManagement
@TestPropertySource("application.properties")
@ContextConfiguration
@Rollback
public class DatabaseConfiguration {

	@Autowired
	private DataSource dataSource;

	@Autowired
	private Environment env;

	@Bean
	public LocalContainerEntityManagerFactoryBean entityManagerFactory() {
		HibernateJpaVendorAdapter vendorAdapter = new HibernateJpaVendorAdapter();
		vendorAdapter.setGenerateDdl(true);
		vendorAdapter.setShowSql(false);

		LocalContainerEntityManagerFactoryBean factory = new LocalContainerEntityManagerFactoryBean();
		factory.setJpaVendorAdapter(vendorAdapter);
		factory.setPackagesToScan(new String[] {
				"com.zycus.guaranteed_delivery_consumer.*" });
		factory.setDataSource(this.dataSource);
		factory.setJpaProperties(additionalProperties());
		return factory;
	}

	@Bean
	public PlatformTransactionManager transactionManager() {
		JpaTransactionManager txManager = new JpaTransactionManager();
		txManager.setEntityManagerFactory(entityManagerFactory().getObject());
		return txManager;
	}

	@Bean  
	public SessionFactory sessionFactory(HibernateEntityManagerFactory hemf){  
		return hemf.getSessionFactory();  
	}
	Properties additionalProperties() {
		Properties properties = new Properties();
		properties.setProperty("hibernate.current_session_context_class", env.getProperty("hibernate.current_session_context_class"));
		return properties;
	}
	
	@Bean
	public GDSConsumerConfiguration getGDSConsumerConfiguration() throws GDSConsumerException {
		return new GDSConsumerConfiguration("10.10.10.153",8500,"DEV","GDS","ICONSOLE","http://10.30.30.86:8092");
	}
}