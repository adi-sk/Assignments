package com.zycus.guaranteed_delivery_consumer.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.util.Date;

import javax.transaction.Transactional;

import org.junit.Assert;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.context.SpringBootTest.WebEnvironment;
import org.springframework.test.context.junit4.SpringRunner;

import com.zycus.guaranteed_delivery_consumer.App;
import com.zycus.guaranteed_delivery_consumer.Exception.GDSConsumerException;
import com.zycus.guaranteed_delivery_consumer.configuration.GDSConsumerConfiguration;
import com.zycus.guaranteed_delivery_consumer.dto.DBConnection;
import com.zycus.guaranteed_delivery_consumer.dto.GDSCConsumerRequest;
import com.zycus.guaranteed_delivery_consumer.enums.GDSConsumerErrorEnum;
import com.zycus.guaranteed_delivery_consumer.service.ConsumerProductCallBack;
import com.zycus.guaranteed_delivery_consumer.service.DatabaseConfiguration;

import uk.co.jemos.podam.api.PodamFactory;
import uk.co.jemos.podam.api.PodamFactoryImpl;

@RunWith(SpringRunner.class)
@SpringBootTest(webEnvironment = WebEnvironment.RANDOM_PORT,classes = {App.class, DatabaseConfiguration.class})
@Transactional
public class GDSConsumerDAOTest {
	
	@Autowired
	private GDSConsumerDAO gdsConsumerDAO;

	@Autowired
	private ConsumerProductCallBack consumerProductCallBack;
	
	public static DBConnection dbConnection=null;
	
	@Autowired
	private GDSConsumerConfiguration gdsConsumerConfiguration;
	
	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
		System.setProperty("env", "INTEGRATION_BANGALORE");
		System.setProperty("productName", "PRODUCT_1");
		System.setProperty("configSourceHost", "10.10.10.153");
		System.setProperty("gdsProductName", "GUARANTEED-DELIVERY");

		dbConnection=new DBConnection();

		Class.forName("oracle.jdbc.driver.OracleDriver");
		Connection connection=DriverManager.getConnection("jdbc:oracle:thin:@192.168.2.197:1521:ORCL","GDS","GDS");  
		dbConnection.setConnection(connection); 
	}
	
	@Test
	public void testUpdateCapturedEventData() throws GDSConsumerException {
		PodamFactory podam=new PodamFactoryImpl();
		GDSCConsumerRequest gdscConsumerRequest=podam.manufacturePojo(GDSCConsumerRequest.class);
		gdscConsumerRequest.setTimeStamp(new Date());
		gdscConsumerRequest.getEventInfo().setTimeStamp(new Date());
		Long gdscId = gdsConsumerDAO.updateCapturedEventData(gdscConsumerRequest, dbConnection,gdsConsumerConfiguration.getProductCode());
		Assert.assertNotNull(gdscId);
		Assert.assertTrue(gdscId>0);
	}
	
	@Test
	public void testUpdateCapturedEventDataJDBCError() {
		PodamFactory podam=new PodamFactoryImpl();
		GDSCConsumerRequest gdscConsumerRequest=podam.manufacturePojo(GDSCConsumerRequest.class);
		gdscConsumerRequest.setTimeStamp(new Date());
		gdscConsumerRequest.getEventInfo().setTimeStamp(new Date());
		try {
			gdsConsumerDAO.updateCapturedEventData(gdscConsumerRequest, getJDBCErrorDBConnectionObject(),gdsConsumerConfiguration.getProductCode());
		} catch (GDSConsumerException e) {
			Assert.assertEquals(GDSConsumerErrorEnum.GDSCCONSUMERREQUEST_PERSIST_FAILED.getValue(), e.getErrorCode());
			Assert.assertEquals(GDSConsumerErrorEnum.GDSCCONSUMERREQUEST_PERSIST_FAILED.getText(), e.getErrorMessage());
		}
	}
	
	@Test
	public void testGetPendingDispathJDBC() {
		try {
			gdsConsumerDAO.getPendingDispath(getJDBCErrorDBConnectionObject(),gdsConsumerConfiguration.getProductCode());
		} catch (GDSConsumerException e) {
			Assert.assertEquals(GDSConsumerErrorEnum.FETCH_OPERATION_FAILED.getValue(), e.getErrorCode());
			Assert.assertEquals(GDSConsumerErrorEnum.FETCH_OPERATION_FAILED.getText(), e.getErrorMessage());
		}
	}
	
	@Test
	public void testUpdateEventDispatchStatusJDBC() {
		try {
			gdsConsumerDAO.updateEventDispatchStatus(-1, getJDBCErrorDBConnectionObject(), "TestStatus",0);
		} catch (GDSConsumerException e) {
			Assert.assertEquals(GDSConsumerErrorEnum.UPDATE_OPERATION_FAILED.getValue(), e.getErrorCode());
			Assert.assertEquals(GDSConsumerErrorEnum.UPDATE_OPERATION_FAILED.getText(), e.getErrorMessage());
		}
	}
	 
	@Test
	public void checkDuplicateJDBC() throws GDSConsumerException {
		Long ConsumerId = gdsConsumerDAO.checkDuplicate(8124l,494l,"7dc266f5-ea5f-46e1-9b67-6dcfad2d0e0d#1519140041561",dbConnection);
		System.out.println(ConsumerId);
	}
	
	@Test
	public void checkDuplicateHibernate() throws GDSConsumerException {
		Long ConsumerId  = gdsConsumerDAO.checkDuplicate(8124l,4994l,"7dc266f5-ea5f-46e1-9b67-6dcfad2d0e0d#1519140041561",consumerProductCallBack.getConnection());
		System.out.println(ConsumerId);
	}
	
	private DBConnection getJDBCErrorDBConnectionObject() {
		DBConnection dbconnection=new DBConnection();
		dbconnection.setConnection(null);
		return dbconnection;
	}

}
