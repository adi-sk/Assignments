# README #

Guaranteed delivery Consumer  

### What is this repository for? ###

For Receiving data from product which has adopted GDS, the consumer need to adopt GDS Consumer Jar .

### How do I get set up? ###

* Add maven dependency or download jar from nexus repository and follow the required step from integration document.
* To run application set environment variable as provided in integration document.
* Database configuration : create sessionFactory or JDBC connection and pass it to provided interface as specified in integration document.

### Who do I talk to? ###

* Repo owner or admin : Chandan / Narendra / Mathan kumar
* Other community or team contact : pdt-integration