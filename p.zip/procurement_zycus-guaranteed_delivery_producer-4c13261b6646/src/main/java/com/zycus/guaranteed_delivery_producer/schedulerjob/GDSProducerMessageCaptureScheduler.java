package com.zycus.guaranteed_delivery_producer.schedulerjob;

import java.sql.Connection;

import org.quartz.DisallowConcurrentExecution;
import org.quartz.Job;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import org.quartz.PersistJobDataAfterExecution;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.zycus.guaranteed_delivery_producer.dto.DBConnection;
import com.zycus.guaranteed_delivery_producer.exception.GDSProducerException;
import com.zycus.guaranteed_delivery_producer.service.GDSProducerCallBack;
import com.zycus.guaranteed_delivery_producer.service.GDSProducerJobService;
import com.zycus.guaranteed_delivery_producer.util.DBConnectionValidator;

@Component
@PersistJobDataAfterExecution
@DisallowConcurrentExecution
public class GDSProducerMessageCaptureScheduler implements Job
{

	private static final Logger LOG = LoggerFactory.getLogger(GDSProducerMessageCaptureScheduler.class);

	@Autowired
	private GDSProducerCallBack gdsProducerCallBack;

	@Autowired
	private GDSProducerJobService gdsProducerJobService;

	@Override
	public void execute(JobExecutionContext context) throws JobExecutionException
	{

		LOG.info("Starting Scheduler.... ");
		DBConnection dbConnection = null;
		try
		{
			dbConnection = gdsProducerCallBack.getConnection();
			DBConnectionValidator.validateDBConnection(dbConnection);
		}
		catch (GDSProducerException e)
		{
			LOG.error("Unable to get DBConnection Due to {}", e);
			gdsProducerCallBack.sendNotifcation("Unable to get DBConnection Due to {}" + e);
			return;
		}
		catch (Exception e)
		{
			LOG.error("Unable to get DBConnection Due to {}", e);
			gdsProducerCallBack.sendNotifcation("Unable to get DBConnection Due to {}" + e);
			return;
		}
		//capture
		gdsProducerJobService.captureEventData(dbConnection);

		//send
		gdsProducerJobService.sendCapturedEventData(dbConnection);
		if (dbConnection.isConnectionCloseRequired())
		{
			try
			{
				Connection con = dbConnection.getConnection();
				con.close();
				LOG.info("Connection closed successfully ");
			}
			catch (Exception e)
			{
				LOG.error("Unable to close Connection due to {}", e);
			}
		}
	}

}
