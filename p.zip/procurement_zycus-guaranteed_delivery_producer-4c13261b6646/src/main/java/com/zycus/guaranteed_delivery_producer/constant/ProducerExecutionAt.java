package com.zycus.guaranteed_delivery_producer.constant;

public interface ProducerExecutionAt {

	/**
	 * Represent's Event Request from product has been received
	 */
	String REQUEST_RECEIVED = "REQUEST_RECEIVED";
	
	/**
	 * Represent's an Event's Data is being/been captured
	 */
	String CAPTURING_EVENT_DATA = "CAPTURING_EVENT_DATA";
	
	/**
	 * Represent's an Event's is being/been sent CGDS.
	 */
	String SENDING_TO_CGDS = "SENDING_TO_CGDS";

}
