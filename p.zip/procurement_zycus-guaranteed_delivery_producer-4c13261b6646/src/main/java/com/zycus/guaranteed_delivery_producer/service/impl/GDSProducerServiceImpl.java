package com.zycus.guaranteed_delivery_producer.service.impl;

import java.sql.Connection;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.zycus.guaranteed_delivery_producer.dao.GDSDAO;
import com.zycus.guaranteed_delivery_producer.dto.CapturedEventData;
import com.zycus.guaranteed_delivery_producer.dto.DBConnection;
import com.zycus.guaranteed_delivery_producer.dto.EventInfo;
import com.zycus.guaranteed_delivery_producer.enums.GDSProducerErrorEnum;
import com.zycus.guaranteed_delivery_producer.exception.GDSProducerException;
import com.zycus.guaranteed_delivery_producer.model.GDSProducerData;
import com.zycus.guaranteed_delivery_producer.service.GDSProducerService;
import com.zycus.guaranteed_delivery_producer.util.DBConnectionValidator;
import com.zycus.guaranteed_delivery_producer.util.EventInfoValidator;
import org.springframework.transaction.annotation.Transactional;

@Service
@Transactional
public class GDSProducerServiceImpl implements GDSProducerService
{

	private static final Logger LOG = LoggerFactory.getLogger(GDSProducerServiceImpl.class);

	@Autowired
	private GDSDAO gdsdao;

	@Override
	public boolean saveProducerEvent(EventInfo eventInfo, DBConnection dbConnection) throws GDSProducerException
	{
		DBConnectionValidator.validateDBConnection(dbConnection);
		List<String> errorList = EventInfoValidator.validateEventInfo(eventInfo);
		if (errorList.isEmpty())
		{
			boolean result = gdsdao.saveProducerEvent(eventInfo, dbConnection);
			closeConnection(dbConnection);
			return result;
		}
		else
		{
			StringBuilder errorMessage = new StringBuilder();
			for (String error : errorList)
			{
				errorMessage.append(error + "\n");
			}
			if (eventInfo != null)
			{
				gdsdao.saveUnRecoverableProducerEvent(eventInfo, dbConnection, errorMessage.toString(),
						GDSProducerErrorEnum.EVENTINFO_VALIDATION_FAILED.getValue());
			}
			closeConnection(dbConnection);
			throw new GDSProducerException(errorMessage.toString(),
					GDSProducerErrorEnum.EVENTINFO_VALIDATION_FAILED.getValue());
		}

	}

	private void closeConnection(DBConnection dbConnection)
	{
		if (dbConnection.isConnectionCloseRequired())
		{
			try
			{
				Connection con = dbConnection.getConnection();
				con.close();
			}
			catch (Exception e)
			{
				LOG.error("Unable to close Connection due to {}", e);
			}
		}
	}

	@Override
	public List<EventInfo> getAllPendingEventToCapture(DBConnection dbConnection) throws GDSProducerException
	{
		return gdsdao.getAllPendingEventToCapture(dbConnection);
	}

	@Override
	public boolean updateCapturedEventData(CapturedEventData capturedEventData, DBConnection dbConnection)
			throws GDSProducerException
	{
		return gdsdao.updateCapturedEventData(capturedEventData, dbConnection);
	}

	@Override
	public boolean updateGDSCId(Long reqId, String gdscId, DBConnection dbConnection) throws GDSProducerException
	{
		return gdsdao.updateGDSCId(reqId, gdscId, dbConnection);
	}

	@Override
	public List<GDSProducerData> getAllEventPendingToDeliverToGDSC(DBConnection dbConnection)
			throws GDSProducerException
	{
		return gdsdao.getAllEventPendingToDeliverToGDSC(dbConnection);
	}

	@Override
	public boolean updateExecutionAt(Long reqId, String executionAt, DBConnection dbConnection)
			throws GDSProducerException
	{
		return gdsdao.updateExecutionAt(reqId, executionAt, dbConnection);
	}

	@Override
	public boolean updateExecutionAtWithStatus(Long reqId, String executionAt, String status, DBConnection dbConnection)
			throws GDSProducerException
	{
		return gdsdao.updateExecutionAtWithStatus(reqId, executionAt, status, dbConnection);
	}

	@Override
	public boolean updateStatus(Long reqId, String status, DBConnection dbConnection) throws GDSProducerException
	{
		return gdsdao.updateStatus(reqId, status, dbConnection);
	}

	@Override
	public boolean updateErrorCodeAndDescription(Long reqId, String errorCode, String stackTrace,
			DBConnection dbConnection) throws GDSProducerException
	{
		return gdsdao.updateErrorCodeAndDescription(reqId, errorCode, stackTrace, dbConnection);
	}

	@Override
	public boolean getStatusOfAnEvent(Long reqId, String executionAt, String status, DBConnection dbConnection)
			throws GDSProducerException
	{
		return gdsdao.getStatusOfAnEvent(reqId, executionAt, status, dbConnection);
	}

}
