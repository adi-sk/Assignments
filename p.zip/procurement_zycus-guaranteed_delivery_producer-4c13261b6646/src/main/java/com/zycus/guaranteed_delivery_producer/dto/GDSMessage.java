package com.zycus.guaranteed_delivery_producer.dto;

public class GDSMessage {
	
	private String type;
	
	private String data;

	@Deprecated
	private String activeMQMessageType;

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getData() {
		return data;
	}

	public void setData(String data) {
		this.data = data;
	}

	@Deprecated
	public String getActiveMQMessageType()
	{
		return activeMQMessageType;
	}

	@Deprecated
	public void setActiveMQMessageType(String activeMQMessageType)
	{
		this.activeMQMessageType = activeMQMessageType;
	}
}
