package com.zycus.guaranteed_delivery_producer.util;

import java.io.IOException;
import java.lang.reflect.Type;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;

import com.google.gson.*;
import com.google.gson.reflect.TypeToken;
import com.zycus.guaranteed_delivery_producer.dto.GDSResponse;
import org.json.JSONException;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.zycus.guaranteed_delivery_producer.dto.Acknowledge;

/**
 * Util Class for converting any object to JSON String
 * @author narendra.m
 *
 */
public class ObjectConversion
{
	private static Gson gson = null;

	/**
	 * Util Class for converting any object to JSON String
	 * @param anyObject
	 * @return {@link String}
	 * @throws JsonProcessingException
	 */
	public static String convertObjectToJSONString(Object anyObject) throws JsonProcessingException
	{
		ObjectMapper objectMapper = new ObjectMapper();
		String JsonString = objectMapper.writeValueAsString(anyObject);
		return JsonString;
	}

	public static GDSResponse convertCGDSResposeToAck(String jsonResponse)
	{
		Type typeResult = new TypeToken<List<GDSResponse>>()
		{
		}.getType();
		Gson gson = getGson();
		List<GDSResponse> gdsResponse = gson.fromJson(jsonResponse, typeResult);
		return gdsResponse.get(0);
	}

	public static Gson getGson()
	{
		if (gson == null)
		{
			GsonBuilder gsonBuilder = new GsonBuilder();
			registerCustomFuncs(gsonBuilder);
			gson = gsonBuilder.create();
		}
		return gson;
	}

	public static void registerCustomFuncs(GsonBuilder builder)
	{
		builder.registerTypeAdapter(Date.class, new JsonDeserializer<Date>()
		{
			public Date deserialize(JsonElement json, Type typeOfT, JsonDeserializationContext context)
					throws com.google.gson.JsonParseException
			{
				try
				{
					return new Date(json.getAsJsonPrimitive().getAsLong());
				}
				catch (NumberFormatException var10)
				{
					try
					{
						return new Date(json.getAsJsonPrimitive().getAsString());
					}
					catch (Exception var9)
					{
						SimpleDateFormat dateFormatter = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.S z");

						try
						{
							return dateFormatter.parse(json.getAsJsonPrimitive().getAsString());
						}
						catch (ParseException var8)
						{
							throw new com.google.gson.JsonParseException(var8);
						}
					}
				}
			}
		});
		builder.registerTypeAdapter(Date.class, new JsonSerializer<Date>()
		{
			public JsonElement serialize(Date date, Type typeOfT, JsonSerializationContext context)
			{
				return date == null ? null : new JsonPrimitive(date.getTime());
			}
		});
		builder.registerTypeAdapter(Currency.class, new JsonSerializer<Currency>()
		{
			public JsonElement serialize(Currency currency, Type typeOfT, JsonSerializationContext context)
			{
				return currency == null ? null : new JsonPrimitive(currency.getCurrencyCode());
			}
		});
		builder.registerTypeAdapter(Currency.class, new JsonDeserializer<Currency>()
		{
			public Currency deserialize(JsonElement json, Type typeOfT, JsonDeserializationContext context)
					throws com.google.gson.JsonParseException
			{
				if (json instanceof JsonPrimitive)
				{
					return Currency.getInstance(json.getAsJsonPrimitive().getAsString());
				}
				else if (json instanceof JsonObject)
				{
					Gson gson = new Gson();
					Type type = (new TypeToken<Map<String, String>>()
					{
					}).getType();
					Map<String, String> map = (Map) gson.fromJson(json, type);
					return Currency.getInstance((String) map.get("currencyCode"));
				}
				else
				{
					return null;
				}
			}
		});
		builder.registerTypeAdapter(TimeZone.class, new JsonSerializer<TimeZone>()
		{
			public JsonElement serialize(TimeZone timezone, Type typeOfT, JsonSerializationContext context)
			{
				return timezone == null ? null : new JsonPrimitive(timezone.getID());
			}
		});
		builder.registerTypeAdapter(TimeZone.class, new JsonDeserializer<TimeZone>()
		{
			public TimeZone deserialize(JsonElement json, Type typeOfT, JsonDeserializationContext context)
					throws JsonParseException
			{
				if (json instanceof JsonPrimitive)
				{
					return TimeZone.getTimeZone(json.getAsJsonPrimitive().getAsString());
				}
				else if (json instanceof JsonObject)
				{
					Map<String, String> mapx = new HashMap();
					Gson gson = new Gson();
					Map<String, String> map = (Map) gson.fromJson(json, mapx.getClass());
					return TimeZone.getTimeZone((String) map.get("ID"));
				}
				else
				{
					return null;
				}
			}
		});
		builder.serializeSpecialFloatingPointValues();
	}

}
