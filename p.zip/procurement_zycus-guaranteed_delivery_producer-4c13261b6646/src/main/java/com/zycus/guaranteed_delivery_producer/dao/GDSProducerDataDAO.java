package com.zycus.guaranteed_delivery_producer.dao;

import java.sql.Connection;
import java.util.List;

import com.zycus.guaranteed_delivery_producer.dto.CapturedEventData;
import com.zycus.guaranteed_delivery_producer.dto.DBConnection;
import com.zycus.guaranteed_delivery_producer.dto.EventInfo;
import com.zycus.guaranteed_delivery_producer.exception.GDSProducerException;
import com.zycus.guaranteed_delivery_producer.model.GDSProducerData;

public interface GDSProducerDataDAO {
	
	public boolean saveProducerEvent(final EventInfo eventInfo, Connection connection) throws GDSProducerException;
	
	public List<EventInfo> getAllPendingEventToCapture(Connection connection) throws GDSProducerException;

	boolean updateGDSCId(Long id, String gdscId, Connection connection) throws GDSProducerException;

	public boolean updateCapturedEventData(CapturedEventData capturedEventData, Connection connection) throws GDSProducerException;
	
	public List<GDSProducerData> getAllEventPendingToDeliverToGDSC(Connection connection) throws GDSProducerException;
	
	public boolean saveUnRecoverableProducerEvent(EventInfo eventInfo, DBConnection dbConnection, String errorDescription, String errorCode) throws GDSProducerException;
	
	public boolean updateStatus(Long reqId, String status, Connection connection) throws GDSProducerException;

	public boolean updateExecutionAt(Long reqId, String executionAt, Connection connection) throws GDSProducerException;
	
	public boolean updateErrorCodeAndDescription(Long reqId, String errorCode,String stackTrace, Connection connection) throws GDSProducerException;
	
	public boolean updateExecutionAtWithStatus(Long reqId, String executionAt,String status, Connection connection) throws GDSProducerException;

	public boolean getStatusOfAnEvent(Long reqId, String executionAt,String status, Connection connection) throws GDSProducerException;
	
	
}
