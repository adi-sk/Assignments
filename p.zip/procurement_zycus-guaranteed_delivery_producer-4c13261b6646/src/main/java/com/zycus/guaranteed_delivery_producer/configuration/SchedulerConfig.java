package com.zycus.guaranteed_delivery_producer.configuration;

import java.util.Properties;
import java.util.TimeZone;

import org.quartz.CronScheduleBuilder;
import org.quartz.CronTrigger;
import org.quartz.JobBuilder;
import org.quartz.JobDetail;
import org.quartz.SchedulerException;
import org.quartz.Trigger;
import org.quartz.TriggerBuilder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.quartz.SchedulerFactoryBean;

import com.zycus.guaranteed_delivery_producer.constant.ProducerSchedularConstant;
import com.zycus.guaranteed_delivery_producer.exception.GDSProducerException;
import com.zycus.guaranteed_delivery_producer.schedulerjob.GDSProducerMessageCaptureScheduler;

@Configuration
public class SchedulerConfig
{

	private JobDetail jobDetails = null;
	private Trigger   triggers   = null;

	@Autowired
	private ApplicationContext applicationContext;

	@Autowired
	private GDSProducerConfiguration gdsProducerConfiguration;

	@Bean(name = ProducerSchedularConstant.SCHEDULER_BEAN_NAME)
	SchedulerFactoryBean producerQuartzScheduler() throws SchedulerException, GDSProducerException
	{
		gdsProducerConfiguration.validateBean();
		SchedulerFactoryBean quartzScheduler = new SchedulerFactoryBean();
		Properties quartzProperties = new Properties();
		quartzProperties.setProperty("org.quartz.scheduler.instanceName", ProducerSchedularConstant.INSTANCENAME);
		quartzProperties.setProperty("org.quartz.scheduler.instanceId", ProducerSchedularConstant.INSTANCEID);
		quartzProperties.setProperty("org.quartz.threadPool.threadCount",
				checkforActualAndPredefined(gdsProducerConfiguration.getThreadCount(),
						ProducerSchedularConstant.THREADCOUNT));
		quartzProperties.setProperty("org.quartz.jobStore.class", ProducerSchedularConstant.JOBSTORECLASS);

		quartzScheduler.setQuartzProperties(quartzProperties);
		AutowiringSpringBeanJobFactory jobFactory = new AutowiringSpringBeanJobFactory();
		jobFactory.setApplicationContext(applicationContext);
		quartzScheduler.setJobFactory(jobFactory);
		if (gdsProducerConfiguration.getQuartzStartUpDelay() == null)
		{
			quartzScheduler.setStartupDelay(ProducerSchedularConstant.QUARTZ_STARTUP_DELAY);
		}
		else
		{
			quartzScheduler.setStartupDelay(gdsProducerConfiguration.getQuartzStartUpDelay());
		}
		quartzScheduler.setJobDetails(jobDetails());
		quartzScheduler.setTriggers(quartzTriggers());
		quartzScheduler.setOverwriteExistingJobs(true);

		quartzScheduler.setAutoStartup(true);
		quartzScheduler.setSchedulerName(ProducerSchedularConstant.SCHEDULER_NAME);

		return quartzScheduler;
	}

	public JobDetail jobDetails()
	{
		jobDetails = JobBuilder.newJob(GDSProducerMessageCaptureScheduler.class).storeDurably()
				.withIdentity(ProducerSchedularConstant.SCHEDULER_JOB_NAME, ProducerSchedularConstant.SCHEDULER_GROUP)
				.build();
		return jobDetails;
	}

	public Trigger quartzTriggers()
	{
		String cronExpression = ProducerSchedularConstant.QUARTZ_CRON_EXPRESSION;
		if (!checkIfNullNEmpty(gdsProducerConfiguration.getCronExpression()))
		{
			cronExpression = gdsProducerConfiguration.getCronExpression();
		}
		CronTrigger producerJobTriger = TriggerBuilder.newTrigger().forJob(jobDetails)
				.withIdentity(ProducerSchedularConstant.SCHEDULER_TRIGGER_NAME,
						ProducerSchedularConstant.SCHEDULER_GROUP).withSchedule(
						CronScheduleBuilder.cronSchedule(cronExpression).withMisfireHandlingInstructionDoNothing()
								.inTimeZone(TimeZone.getTimeZone("UTC"))).build();
		triggers = producerJobTriger;
		return triggers;
	}

	private boolean checkIfNullNEmpty(String str)
	{
		return (str == null || str.isEmpty()) ? true : false;
	}

	private String checkforActualAndPredefined(String actual, String predefined)
	{
		return (actual == null || actual.isEmpty()) ? predefined : actual;
	}
}
