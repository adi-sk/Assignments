package com.zycus.guaranteed_delivery_producer.configuration;

import com.zycus.guaranteed_delivery_producer.constant.JDBCSqlConstant;
import com.zycus.guaranteed_delivery_producer.enums.GDSProducerErrorEnum;
import com.zycus.guaranteed_delivery_producer.exception.GDSProducerException;

public class GDSProducerConfiguration
{

	private String  consulHost;
	private Integer consulPort;
	private String  productCode;
	private String  gdsEndpoint;
	private Integer quartzStartUpDelay;
	private String  cronExpression;
	private String  threadCount;
	private String  tableName = JDBCSqlConstant.GDS_PRODUCER_TABLE;
	private String  consulEnvironment;
	private String  consulProductName;

	public GDSProducerConfiguration(String productCode, String gdsEndpoint, String consulHost, Integer consulPort,
			String consulEnvironment, String consulProductName) throws GDSProducerException
	{
		super();
		this.productCode = productCode;
		this.gdsEndpoint = gdsEndpoint;
		this.consulHost = consulHost;
		this.consulPort = consulPort;
		this.consulEnvironment = consulEnvironment;
		this.consulProductName = consulProductName;
		if (checkIfNullNEmpty(productCode) || checkIfNullNEmpty(gdsEndpoint) || checkIfNullNEmpty(productCode)
				|| consulPort == null || checkIfNullNEmpty(consulEnvironment) || checkIfNullNEmpty(consulProductName))
		{
			throw new GDSProducerException(GDSProducerErrorEnum.GDS_PRODUCER_CONFIGURATION_FAILED.getText(),
					GDSProducerErrorEnum.GDS_PRODUCER_CONFIGURATION_FAILED.getValue());
		}
	}

	public GDSProducerConfiguration(String productCode, String gdsEndpoint, String consulHostAndPort,
			String consulEnvironment, String consulProductName) throws GDSProducerException
	{
		super();
		this.productCode = productCode;
		this.gdsEndpoint = gdsEndpoint;
		this.consulHost = consulHostAndPort.split(":")[0].trim();
		this.consulPort = Integer.parseInt(consulHostAndPort.split(":")[1].trim());
		this.consulEnvironment = consulEnvironment;
		this.consulProductName = consulProductName;
		if (checkIfNullNEmpty(productCode) || checkIfNullNEmpty(gdsEndpoint) || checkIfNullNEmpty(productCode)
				|| consulPort == null || checkIfNullNEmpty(consulEnvironment) || checkIfNullNEmpty(consulProductName))
		{
			throw new GDSProducerException(GDSProducerErrorEnum.GDS_PRODUCER_CONFIGURATION_FAILED.getText(),
					GDSProducerErrorEnum.GDS_PRODUCER_CONFIGURATION_FAILED.getValue());
		}
	}

	public GDSProducerConfiguration(String productCode, String gdsEndpoint, String consulHost, Integer consulPort,
			String consulEnvironment, String consulProductName, Integer quartzStartUpDelay, String cronExpression)
			throws GDSProducerException
	{
		this(productCode, gdsEndpoint, consulHost, consulPort, consulEnvironment, consulProductName);
		this.quartzStartUpDelay = quartzStartUpDelay;
		this.cronExpression = cronExpression;

		if (checkIfNullNEmpty(productCode) || checkIfNullNEmpty(gdsEndpoint) || quartzStartUpDelay == null
				|| checkIfNullNEmpty(cronExpression))
		{
			throw new GDSProducerException(GDSProducerErrorEnum.GDS_PRODUCER_CONFIGURATION_FAILED.getText(),
					GDSProducerErrorEnum.GDS_PRODUCER_CONFIGURATION_FAILED.getValue());
		}
	}

	public GDSProducerConfiguration(String productCode, String gdsEndpoint, String consulHostAndPort,
			String consulEnvironment, String consulProductName, Integer quartzStartUpDelay, String cronExpression)
			throws GDSProducerException
	{
		this(productCode, gdsEndpoint, consulHostAndPort.split(":")[0].trim(),
				Integer.parseInt(consulHostAndPort.split(":")[1].trim()), consulEnvironment, consulProductName);
		this.quartzStartUpDelay = quartzStartUpDelay;
		this.cronExpression = cronExpression;

		if (checkIfNullNEmpty(productCode) || checkIfNullNEmpty(gdsEndpoint) || quartzStartUpDelay == null
				|| checkIfNullNEmpty(cronExpression))
		{
			throw new GDSProducerException(GDSProducerErrorEnum.GDS_PRODUCER_CONFIGURATION_FAILED.getText(),
					GDSProducerErrorEnum.GDS_PRODUCER_CONFIGURATION_FAILED.getValue());
		}
	}

	public GDSProducerConfiguration(String productCode, String gdsEndpoint, String consulHost, Integer consulPort,
			String consulEnvironment, String consulProductName, Integer quartzStartUpDelay, String cronExpression,
			String threadCount) throws GDSProducerException
	{
		this(productCode, gdsEndpoint, consulHost, consulPort, consulEnvironment, consulProductName, quartzStartUpDelay,
				cronExpression);
		this.threadCount = threadCount;

		if (checkIfNullNEmpty(threadCount))
		{
			throw new GDSProducerException(GDSProducerErrorEnum.GDS_PRODUCER_CONFIGURATION_FAILED.getText(),
					GDSProducerErrorEnum.GDS_PRODUCER_CONFIGURATION_FAILED.getValue());
		}
	}

	public GDSProducerConfiguration(String productCode, String gdsEndpoint, String consulHostAndPort,
			String consulEnvironment, String consulProductName, Integer quartzStartUpDelay, String cronExpression,
			String threadCount) throws GDSProducerException
	{
		this(productCode, gdsEndpoint, consulHostAndPort.split(":")[0].trim(),
				Integer.parseInt(consulHostAndPort.split(":")[1].trim()), consulEnvironment, consulProductName,
				quartzStartUpDelay, cronExpression);
		this.threadCount = threadCount;

		if (checkIfNullNEmpty(threadCount))
		{
			throw new GDSProducerException(GDSProducerErrorEnum.GDS_PRODUCER_CONFIGURATION_FAILED.getText(),
					GDSProducerErrorEnum.GDS_PRODUCER_CONFIGURATION_FAILED.getValue());
		}
	}

	public GDSProducerConfiguration(String productCode, String gdsEndpoint, String consulHostAndPort,
			String consulEnvironment, String consulProductName, Integer quartzStartUpDelay, String cronExpression,
			String threadCount, String tableName) throws GDSProducerException
	{
		this(productCode, gdsEndpoint, consulHostAndPort.split(":")[0].trim(),
				Integer.parseInt(consulHostAndPort.split(":")[1].trim()), consulEnvironment, consulProductName,
				quartzStartUpDelay, cronExpression);
		this.threadCount = threadCount;
		this.tableName = tableName;
		if (checkIfNullNEmpty(threadCount))
		{
			throw new GDSProducerException(GDSProducerErrorEnum.GDS_PRODUCER_CONFIGURATION_FAILED.getText(),
					GDSProducerErrorEnum.GDS_PRODUCER_CONFIGURATION_FAILED.getValue());
		}
	}

	public String getProductCode()
	{
		return productCode;
	}

	public String getGdsEndpoint()
	{
		return gdsEndpoint;
	}

	public Integer getQuartzStartUpDelay()
	{
		return quartzStartUpDelay;
	}

	public String getCronExpression()
	{
		return cronExpression;
	}

	private boolean checkIfNullNEmpty(String str)
	{
		return (str == null || str.isEmpty()) ? true : false;
	}

	public void validateBean() throws GDSProducerException
	{
		if (productCode == null || gdsEndpoint == null)
		{
			throw new GDSProducerException(GDSProducerErrorEnum.GDS_PRODUCER_CONFIGURATION_FAILED.getText(),
					GDSProducerErrorEnum.GDS_PRODUCER_CONFIGURATION_FAILED.getValue());
		}
	}

	public String getThreadCount()
	{
		return threadCount;
	}

	public String getConsulHost()
	{
		return consulHost;
	}

	public Integer getConsulPort()
	{
		return consulPort;
	}

	public String getConsulEnvironment()
	{
		return consulEnvironment;
	}

	public String getConsulProductName()
	{
		return consulProductName;
	}

	public String getTableName()
	{
		return tableName;
	}

	public void setTableName(String tableName)
	{
		this.tableName = tableName;
	}
}
