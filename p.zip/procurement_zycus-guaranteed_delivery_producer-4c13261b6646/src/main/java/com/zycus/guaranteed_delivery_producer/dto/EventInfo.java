package com.zycus.guaranteed_delivery_producer.dto;

import javax.persistence.Transient;
import java.util.Date;

public class EventInfo implements Comparable<EventInfo> {
	private long id;

	private String eventId;

	private String entityId;

	private String entityType;

	private String eventType;

	private String version;

	private String extraInfo;

	private String tenantId;

	private String businessRefId;

	private String metadataVersion;

	private Date timeStamp;

	@Deprecated
	private String productCode;

	public long getId()
	{
		return id;
	}

	public void setId(long id)
	{
		this.id = id;
	}

	public String getEventId()
	{
		return eventId;
	}

	public void setEventId(String eventId)
	{
		this.eventId = eventId;
	}

	public String getEntityId()
	{
		return entityId;
	}

	public void setEntityId(String entityId)
	{
		this.entityId = entityId;
	}

	public String getEntityType()
	{
		return entityType;
	}

	public void setEntityType(String entityType)
	{
		this.entityType = entityType;
	}

	public String getEventType()
	{
		return eventType;
	}

	public void setEventType(String eventType)
	{
		this.eventType = eventType;
	}

	public String getVersion()
	{
		return version;
	}

	public void setVersion(String version)
	{
		this.version = version;
	}

	public String getExtraInfo()
	{
		return extraInfo;
	}

	public void setExtraInfo(String extraInfo)
	{
		this.extraInfo = extraInfo;
	}

	public String getTenantId()
	{
		return tenantId;
	}

	public void setTenantId(String tenantId)
	{
		this.tenantId = tenantId;
	}

	public String getBusinessRefId()
	{
		return businessRefId;
	}

	public void setBusinessRefId(String businessRefId)
	{
		this.businessRefId = businessRefId;
	}

	public Date getTimeStamp()
	{
		return timeStamp;
	}

	public void setTimeStamp(Date timeStamp)
	{
		this.timeStamp = timeStamp;
	}

	@Override
	public int compareTo(EventInfo eventInfo) {
		return ((Long)this.id).compareTo((Long)eventInfo.getId());
	}

	public String getMetadataVersion()
	{
		return metadataVersion;
	}

	public void setMetadataVersion(String metadataVersion)
	{
		this.metadataVersion = metadataVersion;
	}

	@Deprecated
	public String getProductCode()
	{
		return productCode;
	}

	@Deprecated
	public void setProductCode(String productCode)
	{
		this.productCode = productCode;
	}
}
