package com.zycus.guaranteed_delivery_producer.dao.impl;

import static com.zycus.guaranteed_delivery_producer.constant.GDSProducerDataFieldConstant.*;
import static com.zycus.guaranteed_delivery_producer.constant.ProducerExecutionAt.REQUEST_RECEIVED;

import java.sql.Clob;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import com.zycus.guaranteed_delivery_producer.configuration.GDSProducerConfiguration;
import com.zycus.guaranteed_delivery_producer.constant.GDSProducerStatus;
import com.zycus.guaranteed_delivery_producer.constant.JDBCSqlConstant;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.zycus.guaranteed_delivery_producer.dao.GDSProducerDataDAO;
import com.zycus.guaranteed_delivery_producer.dto.CapturedEventData;
import com.zycus.guaranteed_delivery_producer.dto.DBConnection;
import com.zycus.guaranteed_delivery_producer.dto.EventInfo;
import com.zycus.guaranteed_delivery_producer.enums.GDSProducerErrorEnum;
import com.zycus.guaranteed_delivery_producer.exception.GDSProducerException;
import com.zycus.guaranteed_delivery_producer.model.GDSProducerData;
import com.zycus.guaranteed_delivery_producer.util.ObjectConversion;
import org.springframework.beans.factory.annotation.Autowired;

public class GDSProducerDataDAOImpl implements GDSProducerDataDAO
{

	private static final Logger                   LOG = LoggerFactory.getLogger(GDSProducerDataDAOImpl.class);
	@Autowired
	private              GDSProducerConfiguration gdsProducerConfiguration;

	private static java.sql.Timestamp getCurrentTimeStamp(Date date)
	{
		return new java.sql.Timestamp(date.getTime());

	}

	@Override
	public boolean saveProducerEvent(EventInfo eventInfo, Connection connection) throws GDSProducerException
	{
		PreparedStatement ps = null;
		try
		{
			ps = getInsertQuery(connection);
			ps.setString(1, eventInfo.getEventId());
			ps.setString(2, eventInfo.getEntityId());
			ps.setString(3, eventInfo.getEntityType());
			ps.setString(4, eventInfo.getEventType());
			ps.setString(5, eventInfo.getVersion());
			ps.setString(6, eventInfo.getExtraInfo());
			ps.setString(7, eventInfo.getTenantId());
			ps.setString(8, eventInfo.getBusinessRefId());
			ps.setTimestamp(9, eventInfo.getTimeStamp() == null ? null : getCurrentTimeStamp(eventInfo.getTimeStamp()));
			ps.setString(10, REQUEST_RECEIVED);
			ps.setString(11, eventInfo.getMetadataVersion());
			int flag = ps.executeUpdate();
			return isSavedOrUpdatedSuccessfully(flag);

		}
		catch (Exception e)
		{
			LOG.error("Unable to insert EventInfo Data to Table {}", e);
			throw new GDSProducerException(GDSProducerErrorEnum.EVENTINFO_PERSIST_FAILED.getText(),
					GDSProducerErrorEnum.EVENTINFO_PERSIST_FAILED.getValue());
		}
		finally
		{
			closeCursors(ps);

		}
	}

	@Override
	public List<GDSProducerData> getAllEventPendingToDeliverToGDSC(Connection connection) throws GDSProducerException
	{
		PreparedStatement ps = null;
		ResultSet resultSet = null;
		try
		{
			ps = connection.prepareStatement(JDBCSqlConstant.DELIVER_TO_GDSC
					.replace(JDBCSqlConstant.GDS_PRODUCER_TABLE, gdsProducerConfiguration.getTableName()));
			resultSet = ps.executeQuery();
			List<GDSProducerData> gdsProducerDatas = new ArrayList<GDSProducerData>();
			while (resultSet.next())
			{
				GDSProducerData gdsProducerData = new GDSProducerData();
				//ID,EVENT_ID,ENTITY_ID,ENTITY_TYPE,EVENT_TYPE,VERSION,EXTRA_INFO,TENANT_ID,BUSSINESS_REF_ID,TIMESTAMP,DATA,GDSCID,STATUS,EXECUTION_AT,DELIVERY_STATUS,ERROR_CODE,ERROR_DESCRIPTION
				gdsProducerData.setId(resultSet.getLong(ID));
				gdsProducerData.setEventId(resultSet.getString(EVENT_ID));
				gdsProducerData.setEntityId(resultSet.getString(ENTITY_ID));
				gdsProducerData.setEntityType(resultSet.getString(ENTITY_TYPE));
				gdsProducerData.setEventType(resultSet.getString(EVENT_TYPE));
				gdsProducerData.setVersion(resultSet.getString(VERSION));
				gdsProducerData.setExtraInfo(resultSet.getString(EXTRA_INFO));
				gdsProducerData.setTenantId(resultSet.getString(TENANT_ID));
				gdsProducerData.setBussinesRefId(resultSet.getString(BUSSINESS_REF_ID));
				gdsProducerData.setTimeStamp(resultSet.getTimestamp(TIMESTAMP));

				Clob clob = resultSet.getClob(DATA);
				String data = clob == null ? null : clob.getSubString(1, (int) clob.length());
				gdsProducerData.setData(data);

				gdsProducerData.setGdscId(resultSet.getString(GDSCID));
				gdsProducerData.setStatus(resultSet.getString(STATUS));
				gdsProducerData.setExecutionAt(resultSet.getString(EXECUTION_AT));
				gdsProducerData.setDeliveryStatus(resultSet.getString(DELIVERY_STATUS));
				gdsProducerData.setErrorCode(resultSet.getString(ERROR_CODE));
				gdsProducerData.setMetadataVersion(resultSet.getString(METADATA_VERSION));
				Clob clob1 = resultSet.getClob(ERROR_DESCRIPTION);
				String errorDescription = clob1 == null ? null : clob1.getSubString(1, (int) clob1.length());
				gdsProducerData.setErrorDescription(errorDescription);
				gdsProducerDatas.add(gdsProducerData);

			}
			return gdsProducerDatas;
		}
		catch (Exception e)
		{
			LOG.error("Unable to fetch Data From Table {}", e);
			throw new GDSProducerException(GDSProducerErrorEnum.FETCH_OPERATION_FAILED.getText(),
					GDSProducerErrorEnum.FETCH_OPERATION_FAILED.getValue());
		}
		finally
		{
			closeCursors(ps, resultSet);

		}
	}

	@Override
	public boolean updateGDSCId(Long id, String gdscId, Connection connection) throws GDSProducerException
	{
		PreparedStatement ps = null;
		try
		{
			ps = connection.prepareStatement(JDBCSqlConstant.UPDATE_GDSC_ID
					.replace(JDBCSqlConstant.GDS_PRODUCER_TABLE, gdsProducerConfiguration.getTableName()));
			ps.setString(1, gdscId);
			ps.setLong(2, id);
			int flag = ps.executeUpdate();
			return isSavedOrUpdatedSuccessfully(flag);
		}
		catch (Exception e)
		{
			LOG.error("Unable to Update Data to Table {}", e);
			throw new GDSProducerException(GDSProducerErrorEnum.UPDATE_OPERATION_FAILED.getText(),
					GDSProducerErrorEnum.UPDATE_OPERATION_FAILED.getValue());
		}
		finally
		{
			closeCursors(ps);

		}
	}

	@Override
	public boolean updateCapturedEventData(CapturedEventData capturedEventData, Connection connection)
			throws GDSProducerException
	{
		PreparedStatement ps = null;
		try
		{
			ps = connection.prepareStatement(JDBCSqlConstant.UPDATE_CAPTURE_DATA
					.replace(JDBCSqlConstant.GDS_PRODUCER_TABLE, gdsProducerConfiguration.getTableName()));
			Clob clob = connection.createClob();
			String jsonCaptureEventData;
			try
			{
				jsonCaptureEventData = ObjectConversion.convertObjectToJSONString(capturedEventData);
				clob.setString(1, jsonCaptureEventData);
				ps.setClob(1, clob);
				ps.setLong(2, capturedEventData.getEventInfo().getId());
			}
			catch (JsonProcessingException e)
			{
				LOG.error("Unable to Update Data to Table {}", e);
				throw new GDSProducerException(
						GDSProducerErrorEnum.CONVERTING_CAPTUREDEVENTDATA_TO_STRING_FAILED.getText(),
						GDSProducerErrorEnum.CONVERTING_CAPTUREDEVENTDATA_TO_STRING_FAILED.getValue());
			}
			catch (NullPointerException e)
			{
				LOG.error("Unable to Update Data to Table {}", e);
				throw new GDSProducerException(
						GDSProducerErrorEnum.CONVERTING_CAPTUREDEVENTDATA_TO_STRING_FAILED.getText(),
						GDSProducerErrorEnum.CONVERTING_CAPTUREDEVENTDATA_TO_STRING_FAILED.getValue());
			}

			int flag = ps.executeUpdate();
			return isSavedOrUpdatedSuccessfully(flag);
		}
		catch (GDSProducerException e)
		{
			throw e;
		}
		catch (Exception e)
		{
			LOG.error("Unable to Update Data to Table {}", e);
			throw new GDSProducerException(GDSProducerErrorEnum.UPDATE_OPERATION_FAILED.getText(),
					GDSProducerErrorEnum.UPDATE_OPERATION_FAILED.getValue());
		}
		finally
		{
			closeCursors(ps);

		}

	}

	@Override
	public List<EventInfo> getAllPendingEventToCapture(Connection connection) throws GDSProducerException
	{
		PreparedStatement ps = null;
		ResultSet resultSet = null;
		try
		{
			ps = connection.prepareStatement(JDBCSqlConstant.CAPTURE_EVENT_DATA
					.replace(JDBCSqlConstant.GDS_PRODUCER_TABLE, gdsProducerConfiguration.getTableName()));
			resultSet = ps.executeQuery();
			List<EventInfo> eventInfos = new ArrayList<EventInfo>();
			while (resultSet.next())
			{
				EventInfo eventInfo = new EventInfo();
				eventInfo.setId(resultSet.getLong(ID));
				eventInfo.setEntityId(resultSet.getString(ENTITY_ID));
				eventInfo.setEntityType(resultSet.getString(ENTITY_TYPE));
				eventInfo.setEventId(resultSet.getString(EVENT_ID));
				eventInfo.setEventType(resultSet.getString(EVENT_TYPE));
				eventInfo.setExtraInfo(resultSet.getString(EXTRA_INFO));
				eventInfo.setTenantId(resultSet.getString(TENANT_ID));
				eventInfo.setTimeStamp(resultSet.getTimestamp(TIMESTAMP));
				eventInfo.setVersion(resultSet.getString(VERSION));
				eventInfo.setBusinessRefId(resultSet.getString(BUSSINESS_REF_ID));
				eventInfo.setMetadataVersion(resultSet.getString(METADATA_VERSION));
				eventInfos.add(eventInfo);
			}
			return eventInfos;
		}
		catch (Exception e)
		{
			LOG.error("Unable to fetch Data From Table {}", e);
			throw new GDSProducerException(GDSProducerErrorEnum.FETCH_OPERATION_FAILED.getText(),
					GDSProducerErrorEnum.FETCH_OPERATION_FAILED.getValue());
		}
		finally
		{
			closeCursors(ps, resultSet);
		}

	}

	@Override
	public boolean saveUnRecoverableProducerEvent(EventInfo eventInfo, DBConnection dbConnection,
			String errorDescription, String errorCode) throws GDSProducerException
	{
		return saveUnRecoverableProducerEvent(eventInfo, dbConnection.getConnection(), errorDescription, errorCode);
	}

	public boolean saveUnRecoverableProducerEvent(EventInfo eventInfo, Connection connection, String errorDescription,
			String errorCode) throws GDSProducerException
	{
		PreparedStatement ps = null;
		try
		{
			ps = getUnrecoverableInserQuery(connection);
			ps.setString(1, eventInfo.getEventId());
			ps.setString(2, eventInfo.getEntityId());
			ps.setString(3, eventInfo.getEntityType());
			ps.setString(4, eventInfo.getEventType());
			ps.setString(5, eventInfo.getVersion());
			ps.setString(6, eventInfo.getExtraInfo());
			ps.setString(7, eventInfo.getTenantId());
			ps.setString(8, eventInfo.getBusinessRefId());
			ps.setTimestamp(9, eventInfo.getTimeStamp() == null ? null : getCurrentTimeStamp(eventInfo.getTimeStamp()));
			ps.setString(10, GDSProducerStatus.GDSPRODUCER_CANT_BE_RECOVERED);
			ps.setString(11, eventInfo.getMetadataVersion());
			ps.setString(12, errorCode);
			ps.setString(13, errorDescription);
			int flag = ps.executeUpdate();
			return isSavedOrUpdatedSuccessfully(flag);

		}
		catch (Exception e)
		{
			LOG.error("Unable to insert EventInfo Can't be recovered Data  to Table {}", e);
			throw new GDSProducerException(GDSProducerErrorEnum.EVENTINFO_PERSIST_FAILED.getText(),
					GDSProducerErrorEnum.EVENTINFO_PERSIST_FAILED.getValue());
		}
		finally
		{
			closeCursors(ps);

		}
	}

	@Override
	public boolean updateStatus(Long reqId, String status, Connection connection) throws GDSProducerException
	{
		PreparedStatement ps = null;
		try
		{
			ps = connection.prepareStatement(JDBCSqlConstant.UPDATE_STATUS
					.replace(JDBCSqlConstant.GDS_PRODUCER_TABLE, gdsProducerConfiguration.getTableName()));
			ps.setString(1, status);
			ps.setLong(2, reqId);
			int flag = ps.executeUpdate();
			return isSavedOrUpdatedSuccessfully(flag);
		}
		catch (Exception e)
		{
			LOG.error("Unable to Update Data to Table {}", e);
			throw new GDSProducerException(GDSProducerErrorEnum.UPDATE_OPERATION_FAILED.getText(),
					GDSProducerErrorEnum.UPDATE_OPERATION_FAILED.getValue());
		}
		finally
		{
			closeCursors(ps);

		}
	}

	@Override
	public boolean updateExecutionAt(Long reqId, String executionAt, Connection connection) throws GDSProducerException
	{
		PreparedStatement ps = null;
		try
		{
			ps = connection.prepareStatement(JDBCSqlConstant.UPDATE_EXECUTION_AT
					.replace(JDBCSqlConstant.GDS_PRODUCER_TABLE, gdsProducerConfiguration.getTableName()));
			ps.setString(1, executionAt);
			ps.setLong(2, reqId);
			int flag = ps.executeUpdate();
			return isSavedOrUpdatedSuccessfully(flag);
		}
		catch (Exception e)
		{
			LOG.error("Unable to Update Data to Table {}", e);
			throw new GDSProducerException(GDSProducerErrorEnum.UPDATE_OPERATION_FAILED.getText(),
					GDSProducerErrorEnum.UPDATE_OPERATION_FAILED.getValue());
		}
		finally
		{
			closeCursors(ps);

		}
	}

	@Override
	public boolean updateErrorCodeAndDescription(Long reqId, String errorCode, String stackTrace, Connection connection)
			throws GDSProducerException
	{
		PreparedStatement ps = null;
		try
		{
			ps = connection.prepareStatement(JDBCSqlConstant.UPDATE_REST_FAILURE
					.replace(JDBCSqlConstant.GDS_PRODUCER_TABLE, gdsProducerConfiguration.getTableName()));
			ps.setString(1, errorCode);

			Clob clob = connection.createClob();
			clob.setString(1, stackTrace);
			ps.setClob(2, clob);

			ps.setLong(3, reqId);
			int flag = ps.executeUpdate();
			return isSavedOrUpdatedSuccessfully(flag);
		}
		catch (Exception e)
		{
			LOG.error("Unable to Update Data to Table {}", e);
			throw new GDSProducerException(GDSProducerErrorEnum.UPDATE_OPERATION_FAILED.getText(),
					GDSProducerErrorEnum.UPDATE_OPERATION_FAILED.getValue());
		}
		finally
		{
			closeCursors(ps);

		}
	}

	@Override
	public boolean updateExecutionAtWithStatus(Long reqId, String executionAt, String status, Connection connection)
			throws GDSProducerException
	{
		PreparedStatement ps = null;
		try
		{
			ps = connection.prepareStatement(JDBCSqlConstant.UPDATE_EXECUTIONAT_WITH_STATUS
					.replace(JDBCSqlConstant.GDS_PRODUCER_TABLE, gdsProducerConfiguration.getTableName()));
			ps.setString(1, executionAt);
			ps.setString(2, status);
			ps.setLong(3, reqId);
			int flag = ps.executeUpdate();
			return isSavedOrUpdatedSuccessfully(flag);
		}
		catch (Exception e)
		{
			LOG.error("Unable to Update Data to Table {}", e);
			throw new GDSProducerException(GDSProducerErrorEnum.UPDATE_OPERATION_FAILED.getText(),
					GDSProducerErrorEnum.UPDATE_OPERATION_FAILED.getValue());
		}
		finally
		{
			closeCursors(ps);
		}
	}

	@Override
	public boolean getStatusOfAnEvent(Long reqId, String executionAt, String status, Connection connection)
			throws GDSProducerException
	{
		PreparedStatement ps = null;
		ResultSet resultSet = null;
		try
		{
			ps = connection.prepareStatement(JDBCSqlConstant.GET_EVENT_STATUS
					.replace(JDBCSqlConstant.GDS_PRODUCER_TABLE, gdsProducerConfiguration.getTableName()));
			ps.setString(1, executionAt);
			ps.setString(2, status);
			ps.setLong(3, reqId);
			resultSet = ps.executeQuery();
			if (resultSet.next())
			{
				return false;
			}
			else
			{
				return true;
			}
		}
		catch (Exception e)
		{
			LOG.error("Unable to fetch Data to Table {}", e);
			throw new GDSProducerException(GDSProducerErrorEnum.FETCH_OPERATION_FAILED.getText(),
					GDSProducerErrorEnum.FETCH_OPERATION_FAILED.getValue());
		}
		finally
		{
			closeCursors(ps, resultSet);
		}
	}

	private PreparedStatement getInsertQuery(Connection connection) throws SQLException
	{
		PreparedStatement ps = null;
		if (connection.getMetaData().getURL().contains("sqlserver"))
		{
			ps = connection.prepareStatement(JDBCSqlConstant.SAVE_PRODUCER_EVENT_MSSQL
					.replace(JDBCSqlConstant.GDS_PRODUCER_TABLE, gdsProducerConfiguration.getTableName()));
		}
		else
		{
			ps = connection.prepareStatement(JDBCSqlConstant.SAVE_PRODUCER_EVENT_ORACLE
					.replace(JDBCSqlConstant.GDS_PRODUCER_TABLE, gdsProducerConfiguration.getTableName()));
		}
		return ps;
	}

	private boolean isSavedOrUpdatedSuccessfully(int flag)
	{
		if (flag > 0)
		{
			return true;
		}
		return false;
	}

	private PreparedStatement getUnrecoverableInserQuery(Connection connection) throws SQLException
	{
		PreparedStatement ps = null;
		if (connection.getMetaData().getURL().contains("sqlserver"))
		{
			ps = connection.prepareStatement(JDBCSqlConstant.SAVE_UNRECOVERABLE_PRODUCER_EVENT_MSSQL.
					replace(JDBCSqlConstant.GDS_PRODUCER_TABLE, gdsProducerConfiguration.getTableName()));
		}
		else
		{
			ps = connection.prepareStatement(JDBCSqlConstant.SAVE_UNRECOVERABLE_PRODUCER_EVENT_ORACLE
					.replace(JDBCSqlConstant.GDS_PRODUCER_TABLE, gdsProducerConfiguration.getTableName()));
		}
		return ps;
	}

	private void closeCursors(PreparedStatement ps)
	{
		try
		{
			if (ps != null)
			{
				ps.close();
			}
		}
		catch (SQLException e)
		{
			LOG.error("Unable to close open cursors due to {}", e);
		}
	}

	private void closeCursors(PreparedStatement ps, ResultSet resultSet)
	{
		try
		{
			if (resultSet != null)
			{
				resultSet.close();
			}
			if (ps != null)
			{
				ps.close();
			}
		}
		catch (SQLException e)
		{
			LOG.error("Unable to close open cursors due to {}", e);
		}
		finally
		{
			try
			{
				if (ps != null)
				{
					ps.close();
				}
			}
			catch (SQLException e)
			{
				LOG.error("Unable to close open cursors due to {}", e);
			}
		}
	}

}
