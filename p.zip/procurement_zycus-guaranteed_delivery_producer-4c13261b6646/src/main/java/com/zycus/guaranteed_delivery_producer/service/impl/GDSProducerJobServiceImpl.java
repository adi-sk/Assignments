package com.zycus.guaranteed_delivery_producer.service.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.TreeSet;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.zycus.guaranteed_delivery_producer.configuration.GDSProducerConfiguration;
import com.zycus.guaranteed_delivery_producer.dto.DBConnection;
import com.zycus.guaranteed_delivery_producer.dto.EventInfo;
import com.zycus.guaranteed_delivery_producer.dto.GDSProducerRequest;
import com.zycus.guaranteed_delivery_producer.exception.GDSProducerException;
import com.zycus.guaranteed_delivery_producer.model.GDSProducerData;
import com.zycus.guaranteed_delivery_producer.schedulerjob.CaptureEventJob;
import com.zycus.guaranteed_delivery_producer.schedulerjob.SendToCGDSJob;
import com.zycus.guaranteed_delivery_producer.service.GDSProducerCallBack;
import com.zycus.guaranteed_delivery_producer.service.GDSProducerJobService;
import com.zycus.guaranteed_delivery_producer.service.GDSProducerService;
import com.zycus.guaranteed_delivery_producer.util.ClusterLeader;
import com.zycus.guaranteed_delivery_producer.util.GDSProducerDataUtil;

@Service
public class GDSProducerJobServiceImpl implements GDSProducerJobService
{

	private static final Logger LOG = LoggerFactory.getLogger(GDSProducerJobServiceImpl.class);

	@Autowired
	private GDSProducerService gdsProducerService;

	@Autowired
	private GDSProducerCallBack gdsProducerCallBack;

	@Autowired
	private GDSProducerConfiguration gdsProducerConfiguration;

	@Autowired
	private ClusterLeader clusterLeader;

	@Override
	public void captureEventData(DBConnection dbConnection)
	{
		try
		{
			LOG.info("Getting Event's for capturing Event Data.");
			List<EventInfo> eventInfos = gdsProducerService.getAllPendingEventToCapture(dbConnection);
			if (eventInfos.isEmpty())
			{
				LOG.info("No Event's for capturing CapturedEventData.");
			}
			else
			{
				Map<String, TreeSet<EventInfo>> chunks = new HashMap<String, TreeSet<EventInfo>>();
				LinkedHashSet<String> keyOrders = new LinkedHashSet<String>();
				captureEventDataCreateChunks(eventInfos, chunks, keyOrders);

				ExecutorService executor = Executors.newFixedThreadPool(keyOrders.size());
				List<Future<String>> list = new ArrayList<Future<String>>();

				for (String keyOrder : keyOrders)
				{
					try
					{
						Callable<String> callable = new CaptureEventJob(chunks.get(keyOrder), gdsProducerService,
								gdsProducerCallBack, clusterLeader, keyOrder, dbConnection);
						Future<String> future = executor.submit(callable);
						list.add(future);
					}
					catch (Exception e)
					{
						LOG.error("Unable to capture event () {}", e);
						gdsProducerCallBack
								.sendNotifcation("Unable to captureEventData()  for " + keyOrder + " due to {} " + e);
					}
				}
				for (Future<String> fut : list)
				{
					try
					{
						LOG.info("Captured event Data for key - " + fut.get());
					}
					catch (InterruptedException e)
					{
						e.printStackTrace();
					}
					catch (ExecutionException e)
					{
						e.printStackTrace();
					}
				}
				executor.shutdown();
				LOG.info("All Above Event's Successfully captured Event Data ");
			}
		}
		catch (GDSProducerException e)
		{
			LOG.error("Unable to getAllPendingEventToCapture() {}", e);
			gdsProducerCallBack.sendNotifcation("Unable to getAllPendingEventToCapture() {} " + e);
		}
	}

	@Override
	public void sendCapturedEventData(DBConnection dbConnection)
	{

		try
		{
			LOG.info("Getting all Event's for sending to Central GDS");
			List<GDSProducerData> gdsProducerDatas = gdsProducerService.getAllEventPendingToDeliverToGDSC(dbConnection);
			if (!gdsProducerDatas.isEmpty())
			{
				Map<String, TreeSet<GDSProducerRequest>> chunks = new HashMap<String, TreeSet<GDSProducerRequest>>();
				LinkedHashSet<String> keyOrders = new LinkedHashSet<String>();

				//create chunks
				createChunks(gdsProducerDatas, chunks, keyOrders);

				//send to CGDS
				ExecutorService executor = Executors.newFixedThreadPool(keyOrders.size());
				List<Future<String>> list = new ArrayList<Future<String>>();
				LOG.info("Sending Event's to Central GDS Started... ");
				for (String keyOrder : keyOrders)
				{
					try
					{
						Callable<String> callable = new SendToCGDSJob(chunks.get(keyOrder), gdsProducerService,
								gdsProducerCallBack, clusterLeader, keyOrder, gdsProducerConfiguration, dbConnection);
						Future<String> future = executor.submit(callable);
						list.add(future);
					}
					catch (Exception e)
					{
						LOG.error("Unable to sendCapturedEventData() for " + keyOrder + " Due to {} ", e);
					}
				}
				for (Future<String> fut : list)
				{
					try
					{
						LOG.info("Processed event for CGDS for key - " + fut.get());
					}
					catch (InterruptedException e)
					{
						e.printStackTrace();
					}
					catch (ExecutionException e)
					{
						e.printStackTrace();
					}
				}
				executor.shutdown();
			}
			else
			{
				LOG.info("No pending Events to send to Central GDS");
			}
		}
		catch (GDSProducerException e)
		{
			LOG.error("Unable to getAllEventPendingToDeliverToGDSC() Due to {}", e);
			return;
		}
	}

	private void createChunks(List<GDSProducerData> gdsProducerDatas, Map<String, TreeSet<GDSProducerRequest>> chunks,
			LinkedHashSet<String> keyOrders)
	{
		LOG.info("Creating producer chunks... ");
		for (GDSProducerData gdsProducerData : gdsProducerDatas)
		{
			try
			{
				GDSProducerDataUtil gdsProducerDataUtil = new GDSProducerDataUtil();
				GDSProducerRequest gdsProducerRequest = gdsProducerDataUtil
						.convertGDSProducerDataToGDSProducerRequest(gdsProducerData,
								gdsProducerConfiguration.getProductCode());
				String key = getKey(gdsProducerRequest);

				TreeSet<GDSProducerRequest> chunk = chunks.get(key);
				keyOrders.add(key);

				//Creating new chunk if key not present else add to previous existing
				if (chunk == null)
				{
					TreeSet<GDSProducerRequest> treeGDSProducerRequest = new TreeSet<GDSProducerRequest>();
					treeGDSProducerRequest.add(gdsProducerRequest);
					chunks.put(key, treeGDSProducerRequest);
				}
				else
				{
					chunk.add(gdsProducerRequest);
				}
			}
			catch (Exception e)
			{
				LOG.error("Unable to createChunks() for " + gdsProducerData.getEntityId() + " Due to {}", e);
			}
		}
		LOG.info("Producer chunks Created Successfully... ");
	}

	private void captureEventDataCreateChunks(List<EventInfo> eventInfos, Map<String, TreeSet<EventInfo>> chunks,
			LinkedHashSet<String> keyOrders)
	{
		LOG.info("Creating producer chunks... ");
		for (EventInfo eventInfo : eventInfos)
		{

			String key =
					gdsProducerConfiguration.getProductCode() + eventInfo.getEntityType() + eventInfo.getEntityId();

			TreeSet<EventInfo> chunk = chunks.get(key);
			keyOrders.add(key);

			//Creating new chunk if key not present else add to previous existing
			if (chunk == null)
			{
				TreeSet<EventInfo> treeEventInfo = new TreeSet<EventInfo>();
				treeEventInfo.add(eventInfo);
				chunks.put(key, treeEventInfo);
			}
			else
			{
				chunk.add(eventInfo);
			}

		}
		LOG.info("Producer chunks Created Successfully... ");
	}

	public String getKey(GDSProducerRequest gdsProducerRequest)
	{
		return gdsProducerConfiguration.getProductCode() + gdsProducerRequest.getCapturedEventData().getEventInfo()
				.getEntityType() + gdsProducerRequest.getCapturedEventData().getEventInfo().getEntityId();
	}

}
