package com.zycus.guaranteed_delivery_producer.service;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.Date;
import java.util.List;
import java.util.TimeZone;
import java.util.UUID;

import org.junit.Assert;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.context.SpringBootTest.WebEnvironment;
import org.springframework.test.annotation.Rollback;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.transaction.annotation.Transactional;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.zycus.guaranteed_delivery_producer.constant.GDSProducerStatus;
import com.zycus.guaranteed_delivery_producer.constant.ProducerExecutionAt;
import com.zycus.guaranteed_delivery_producer.dto.CapturedEventData;
import com.zycus.guaranteed_delivery_producer.dto.DBConnection;
import com.zycus.guaranteed_delivery_producer.dto.EventInfo;
import com.zycus.guaranteed_delivery_producer.enums.GDSProducerErrorEnum;
import com.zycus.guaranteed_delivery_producer.exception.GDSProducerException;
import com.zycus.guaranteed_delivery_producer.model.GDSProducerData;
import com.zycus.guaranteed_delivery_producer.util.ClusterLeader;

@RunWith(SpringRunner.class)
@SpringBootTest(webEnvironment = WebEnvironment.RANDOM_PORT)
@Transactional
@Rollback
public class GDSProducerServiceTest {

	@Autowired
	private GDSProducerService gdsProducerService;

	@Autowired
	private GDSProducerCallBack gdsProduerCallBack; 

	Long eventInfoId=14l;

	String eventId = "2296ca0e-d963-4810-b432-7c33c3fc8a6e";

	@Autowired
	private ClusterLeader clusterLeader;
	
	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
		System.setProperty("env", "INTEGRATION_BANGALORE");
		System.setProperty("productName", "PRODUCT_1");
		System.setProperty("configSourceHost", "10.10.10.153");
		System.setProperty("gdsProductName", "GUARANTEED-DELIVERY");
	}


	@Test
	public void saveProducerEventJDBC() throws GDSProducerException, SQLException, JsonProcessingException {
		//Connection connection=gdsProduerCallBack.getConnection().getConnection();
		//connection.setAutoCommit(false);
		System.out.println(new ObjectMapper().writeValueAsString(getEventInfo()));
		boolean flag = gdsProducerService.saveProducerEvent(getEventInfo(), gdsProduerCallBack.getConnection());
		Assert.assertEquals("Added successfully ", true, flag);
		//connection.rollback();
	}

	@Test
	public void testConsulLeaderShip() throws GDSProducerException, SQLException, JsonProcessingException {
		clusterLeader.accquireLeadership("NAREN");
	}

	@Test
	public void saveProducerEventMultipleJDBC() throws GDSProducerException{
		EventInfo eventInfo=getEventInfo();
		long temp=3;
		int x=1;
		for(int i=1;i<=40;i++) {
			if(i%5==0) {
				temp++;
				x=1;
			}
			if(i%3==0)
				eventInfo.setEntityType("PO");
			if(i%4==0)
				eventInfo.setEntityType("TEST1");
			if(i%5==0)
				eventInfo.setEntityType("TEST2");
			
			eventInfo.setEntityId(""+temp);
			eventInfo.setEventId(UUID.randomUUID().toString());
			eventInfo.setVersion("V"+(x++));
			gdsProducerService.saveProducerEvent(eventInfo,gdsProduerCallBack.getConnection());
		}
	}

	@Test
	public void saveProducerEventJDBCError() throws SQLException {
		Connection connection=gdsProduerCallBack.getConnection().getConnection();
		connection.setAutoCommit(false);
		try {
			gdsProducerService.saveProducerEvent(getErrorEventInfo(), gdsProduerCallBack.getConnection());
		} catch (GDSProducerException e) {
			Assert.assertEquals(GDSProducerErrorEnum.EVENTINFO_VALIDATION_FAILED.getValue(), e.getErrorCode());
		}
		connection.rollback();
	}

	@Test
	public void testGetAllPendingEventToCaptureJDBC() throws GDSProducerException, SQLException {
		Connection connection=gdsProduerCallBack.getConnection().getConnection();
		connection.setAutoCommit(false);
		List<EventInfo> eventInfos=gdsProducerService.getAllPendingEventToCapture(gdsProduerCallBack.getConnection());
		Assert.assertTrue("List size is greater than or equal to Zero",eventInfos.size()>=0 );
		connection.rollback();
	}

	@Test
	public void testUpdateCapturedEventDataJDBC() throws Exception {
		Connection connection=gdsProduerCallBack.getConnection().getConnection();
		connection.setAutoCommit(false);
		boolean flag = gdsProducerService.updateCapturedEventData(gdsProduerCallBack.captureEvent(getEventInfo()), gdsProduerCallBack.getConnection());
		Assert.assertEquals("Updated successfully ", true, flag);
		connection.rollback();

	}

	@Test
	public void testUpdateCapturedEventDataMessageSetNullJDBC() throws Exception {
		Connection connection=gdsProduerCallBack.getConnection().getConnection();
		connection.setAutoCommit(false);
		CapturedEventData capturedEventData =  gdsProduerCallBack.captureEvent(getEventInfo());
		capturedEventData.setMessageSet(null);
		boolean flag = gdsProducerService.updateCapturedEventData(capturedEventData, gdsProduerCallBack.getConnection());
		Assert.assertEquals("Updated successfully ", true, flag);
		connection.rollback();
	}

	@Test
	public void testUpdateCapturedEventDataJDBCError() {
		try {
			gdsProducerService.updateCapturedEventData(null, gdsProduerCallBack.getConnection());
		} catch (GDSProducerException e) {
			Assert.assertEquals(GDSProducerErrorEnum.CONVERTING_CAPTUREDEVENTDATA_TO_STRING_FAILED.getValue(), e.getErrorCode());
			Assert.assertEquals(GDSProducerErrorEnum.CONVERTING_CAPTUREDEVENTDATA_TO_STRING_FAILED.getText(), e.getErrorMessage());
		}
	}

	@Test
	public void testGetAllEventPendingToDeliverToGDSCJDBC() throws GDSProducerException, SQLException {
		Connection connection=gdsProduerCallBack.getConnection().getConnection();
		connection.setAutoCommit(false);
		List<GDSProducerData> dGdsProducerDatas=gdsProducerService.getAllEventPendingToDeliverToGDSC(gdsProduerCallBack.getConnection());
		Assert.assertTrue("List size is greater than or equal to Zero",dGdsProducerDatas.size()>=0 );
		connection.rollback();
	}

	@Test
	public void testUpdateExecutionAtJDBC() throws GDSProducerException, SQLException {
		Connection connection=gdsProduerCallBack.getConnection().getConnection();
		connection.setAutoCommit(false);
		boolean flag = gdsProducerService.updateExecutionAt(eventInfoId, ProducerExecutionAt.CAPTURING_EVENT_DATA, gdsProduerCallBack.getConnection());
		Assert.assertEquals("Updated successfully ", true, flag);
		connection.rollback();
	}

	@Test
	public void testUpdateStatusJDBC() throws GDSProducerException, SQLException {
		Connection connection=gdsProduerCallBack.getConnection().getConnection();
		connection.setAutoCommit(false);
		boolean flag = gdsProducerService.updateStatus(eventInfoId, GDSProducerStatus.GDSPRODUCER_PROCESSING, gdsProduerCallBack.getConnection());
		Assert.assertEquals("Added successfully ", true, flag);
		connection.rollback();
	}

	@Test
	public void testUpdateErrorCodeAndDescriptionJDBC() throws GDSProducerException, SQLException {
		Connection connection=gdsProduerCallBack.getConnection().getConnection();
		connection.setAutoCommit(false);
		boolean flag = gdsProducerService.updateErrorCodeAndDescription(eventInfoId,GDSProducerErrorEnum.CONVERTING_CAPTUREDEVENTDATA_TO_STRING_FAILED.getValue(),GDSProducerErrorEnum.CONVERTING_CAPTUREDEVENTDATA_TO_STRING_FAILED.getText(), gdsProduerCallBack.getConnection());
		Assert.assertEquals("Added successfully ", true, flag);
		connection.rollback();
	}

	@Test
	public void testUpdateGDSCIdJDBC() throws GDSProducerException, SQLException {
		Connection connection=gdsProduerCallBack.getConnection().getConnection();
		connection.setAutoCommit(false);
		DBConnection dbconnection = gdsProduerCallBack.getConnection();
		boolean flag = gdsProducerService.updateGDSCId(eventId, "Test123", dbconnection);
		Assert.assertEquals("Added successfully ", true, flag);
		connection.rollback();
	}

	@Test
	public void testupdateExecutionAtWithStatusJDBC() throws GDSProducerException, SQLException {
		Connection connection=gdsProduerCallBack.getConnection().getConnection();
		connection.setAutoCommit(false);
		DBConnection dbconnection = gdsProduerCallBack.getConnection();
		boolean flag = gdsProducerService.updateExecutionAtWithStatus(eventInfoId, ProducerExecutionAt.CAPTURING_EVENT_DATA, GDSProducerStatus.GDSPRODUCER_PROCESSING, dbconnection);
		Assert.assertEquals("Added successfully ", true, flag);
		connection.rollback();
	}

	public EventInfo getEventInfo() {
		EventInfo eventInfo=new EventInfo();
		eventInfo.setEventId(UUID.randomUUID().toString());
		eventInfo.setEventType("SUBMITTED");
		eventInfo.setEntityId("1");
		eventInfo.setEntityType("INVOICE");
		eventInfo.setExtraInfo("extra data");
		eventInfo.setBusinessRefId("EINVOICE");
		eventInfo.setTenantId("def68304-7e50-463c-95f5-7af9dcb4e600");
		TimeZone.setDefault(TimeZone.getTimeZone("UTC"));
		eventInfo.setTimeStamp(new Date());
		eventInfo.setVersion("V1");
		eventInfo.setId(eventInfoId);
		return eventInfo;
	}

	public EventInfo getErrorEventInfo() {
		EventInfo eventInfo=new EventInfo();
		eventInfo.setEventType("SUBMITTED");
		eventInfo.setEntityId("1");
		eventInfo.setEntityType("INVOICE");
		eventInfo.setBusinessRefId("EINVOICE");
		eventInfo.setTenantId("def68304-7e50-463c-95f5-7af9dcb4e600");
		TimeZone.setDefault(TimeZone.getTimeZone("UTC"));
		eventInfo.setTimeStamp(new Date());
		eventInfo.setVersion("V1");
		eventInfo.setId(eventInfoId);
		return eventInfo;
	}

}
