package com.zycus.guaranteed_delivery_producer.util;

import org.junit.Assert;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.junit4.SpringRunner;

import com.zycus.guaranteed_delivery_producer.dto.CapturedEventData;
import com.zycus.guaranteed_delivery_producer.dto.GDSProducerRequest;
import com.zycus.guaranteed_delivery_producer.model.GDSProducerData;
import com.zycus.guaranteed_delivery_producer.util.GDSProducerDataUtil;

@RunWith(SpringRunner.class)
public class GDSProducerDataUtilTest {

	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
		System.setProperty("env", "INTEGRATION_BANGALORE");
		System.setProperty("productName", "PRODUCT_1");
		System.setProperty("configSourceHost", "10.10.10.153");
		System.setProperty("gdsProductName", "GUARANTEED-DELIVERY");
	}
	
	@Test
	public void testGetCapturedEventData() {
		String data = "{\"eventInfo\":{\"id\":33,\"eventId\":\"2f75189f-5b8a-4918-87a8-afdf1509430d\",\"entityId\":\"1\",\"entityType\":\"INVOICE\",\"eventType\":\"SUBMITTED\",\"version\":\"V1\",\"extraInfo\":null,\"tenantId\":\"123456\",\"businessRefId\":\"EINVOICE\",\"timeStamp\":1512044360527},\"messageSet\":[{\"type\":\"EInvoice\",\"data\":\"123\"},{\"type\":\"EInvoice\",\"data\":\"12312312\"}]}";
		GDSProducerDataUtil gdsProducerDataUtil=new GDSProducerDataUtil();
		CapturedEventData capturedEventData = gdsProducerDataUtil.getCapturedEventData(data);
		Assert.assertNotNull("should not be null",capturedEventData);
		Assert.assertNotNull(capturedEventData.getEventInfo());
		Assert.assertNotNull(capturedEventData.getMessageSet());
		Assert.assertEquals(33, capturedEventData.getEventInfo().getId());

	}
	@Test
	public void testGetCapturedEventDataNull() {
		String data = null;
		GDSProducerDataUtil gdsProducerDataUtil=new GDSProducerDataUtil();
		CapturedEventData capturedEventData = gdsProducerDataUtil.getCapturedEventData(data);
		Assert.assertNull(capturedEventData);
		
	}
	@Test
	public void testConvertGDSProducerDataToGDSProducerRequest() {
		GDSProducerData gdsProducerData=new GDSProducerData();
		GDSProducerDataUtil gdsProducerDataUtil=new GDSProducerDataUtil();
		GDSProducerRequest gdsProducerRequest = gdsProducerDataUtil.convertGDSProducerDataToGDSProducerRequest(gdsProducerData,"EInvoice");
		Assert.assertEquals("Product code added successfully", "EInvoice",gdsProducerRequest.getProductCode());
	}

}
