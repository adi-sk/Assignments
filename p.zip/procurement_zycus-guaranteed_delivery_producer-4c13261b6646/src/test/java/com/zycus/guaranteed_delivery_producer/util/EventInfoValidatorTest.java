package com.zycus.guaranteed_delivery_producer.util;

import java.util.List;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.junit4.SpringRunner;

import com.zycus.guaranteed_delivery_producer.dto.EventInfo;

import uk.co.jemos.podam.api.PodamFactory;
import uk.co.jemos.podam.api.PodamFactoryImpl;

@RunWith(SpringRunner.class)
public class EventInfoValidatorTest {

	@Test
	public void testValidateEventInfo() {
		PodamFactory podam=new PodamFactoryImpl();
		EventInfo eventInfo=podam.manufacturePojo(EventInfo.class);
		List<String> errorList = EventInfoValidator.validateEventInfo(eventInfo);
		Assert.assertEquals(0, errorList.size());
	}
	@Test
	public void testValidateEventInfoEventId() {
		PodamFactory podam=new PodamFactoryImpl();
		EventInfo eventInfo=podam.manufacturePojo(EventInfo.class);
		eventInfo.setEventId("");
		List<String> errorList = EventInfoValidator.validateEventInfo(eventInfo);
		Assert.assertEquals(1, errorList.size());
	}
	@Test
	public void testValidateEventInfoTenantId() {
		PodamFactory podam=new PodamFactoryImpl();
		EventInfo eventInfo=podam.manufacturePojo(EventInfo.class);
		eventInfo.setTenantId("");
		List<String> errorList = EventInfoValidator.validateEventInfo(eventInfo);
		Assert.assertEquals(1, errorList.size());
	}
	@Test
	public void testValidateEventInfoEntityId() {
		PodamFactory podam=new PodamFactoryImpl();
		EventInfo eventInfo=podam.manufacturePojo(EventInfo.class);
		eventInfo.setEntityId("");
		List<String> errorList = EventInfoValidator.validateEventInfo(eventInfo);
		Assert.assertEquals(1, errorList.size());
	}
	@Test
	public void testValidateEventInfoVersionSize() {
		PodamFactory podam=new PodamFactoryImpl();
		EventInfo eventInfo=podam.manufacturePojo(EventInfo.class);
		eventInfo.setVersion("....................................................................................................................................");
		List<String> errorList = EventInfoValidator.validateEventInfo(eventInfo);
		Assert.assertEquals(1, errorList.size());
	}
}
