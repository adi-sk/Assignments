package com.zycus.guaranteed_delivery_producer.restclient;

import java.io.IOException;

import javax.ws.rs.core.Response;

import com.zycus.guaranteed_delivery_producer.dto.GDSResponse;
import org.apache.http.client.utils.URLEncodedUtils;
import org.json.JSONException;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.junit4.SpringRunner;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.zycus.guaranteed_delivery_producer.configuration.GDSProducerConfiguration;
import com.zycus.guaranteed_delivery_producer.dto.Acknowledge;
import com.zycus.guaranteed_delivery_producer.dto.GDSProducerRequest;
import com.zycus.guaranteed_delivery_producer.util.ObjectConversion;

@RunWith(SpringRunner.class)
public class GDSCRestEndPointTest {
	
	/*@Autowired
	private GDSProducerConfiguration gdsProducerConfiguration;*/
	
	@Test
	public void testUpdateCapturedEventData() throws JsonParseException, JsonMappingException, IOException, JSONException {
		GDSProducerRequest gdsProducerRequest = restDataGenerator();
		Response response = GDSCRestEndPoint.updateCapturedEventData(gdsProducerRequest, getConsulKVUrl(), "https://elastic.snaplogic.com:443/api/1/rest/slsched/feed/Zycus_GDS_LOCAL/projects/GDS/PostDataAPITask");
		System.out.println("RESPONSE DATA : "+response.getEntity());
		Assert.assertEquals(200, response.getStatus());
		GDSResponse ack =ObjectConversion.convertCGDSResposeToAck((String) response.getEntity());
		Assert.assertNotNull(ack.getGdscId());
		Assert.assertNotNull(ack.getTimeStamp());
	}

	private GDSProducerRequest restDataGenerator() throws IOException, JsonParseException, JsonMappingException {
		String data="{\r\n"+   
			    "\"id\"                :  123,\r\n"+
			    "\"timeStamp\"         :   121212121,\r\n"+
			    "\"productCode\"       :   \"eproc-service\",\r\n"+
			    "\"additionalInfo\"    :   \"this is a additional information\",\r\n"+
			    "\"status\"            :   \"SUCCESS\",\r\n"+
			    "\"executionAt\"       :   \"SENDING_TO_CGDS\",\r\n"+
			    "\"deliveryStatus\"    :   \"NOTHING\",\r\n"+
			    "\"errorCode\"         :   null,\r\n"+
			    "\"errorDescription\"  :   \"0 is just a discription\",\r\n"+
			    "\"capturedEventData\" :  {\r\n"+
				" \"eventInfo\" : {\r\n"+
											"\"id\" : 123,\r\n"+
			                                "\"eventId\" : \"4028843a-64290393-0164-2910ab0c-0007\",\r\n"+
			                                "\"entityId\" : \"25acf6ca-204f-4f3f-95bd-5fea43b413c2\",\r\n"+
			                                "\"entityType\" : \"REQUISITION\",\r\n"+
			                                "\"eventType\" : \"SUBMITTED\",\r\n"+
			                                "\"version\" : \"1\",\r\n"+
			                                "\"extraInfo\" : \"Extra Info\",\r\n"+
			                                "\"tenantId\" : \"6df34229-033e-446c-a448-d76289376730\",\r\n"+
			                                "\"businessRefId\" : \"eProc\",\r\n"+
			                                "\"timeStamp\" : 1529697306480\r\n"+
			                            "},\r\n"+
			                            "\"messageSet\" :[\r\n"+
			                                    "{\r\n"+
			                                        "\"type\" :    \"CRMS\",\r\n"+
			                                        "\"data\" :    \"This is data\"\r\n"+   
			                                    "},\r\n"+
			                                    "{\r\n"+
			                                        "\"type\" :    \"ICONSOLE\",\r\n"+
			                                        "\"data\" :    \"This is a i console data\"\r\n"+
			                                   " }\r\n"+
			                                "]\r\n"+
			                        "}\r\n"+
			"}";
		ObjectMapper objectMapper=new ObjectMapper();
		GDSProducerRequest gdsProducerRequest = objectMapper.readValue(data, GDSProducerRequest.class);
		System.out.println(objectMapper.writeValueAsString(gdsProducerRequest));
		return gdsProducerRequest;
	}
	
	public static void main(String[] args) {
		GDSCRestEndPointTest gdscRestEndPointTest=new GDSCRestEndPointTest();
		try {
			gdscRestEndPointTest.restDataGenerator();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	private static String getConsulKVUrl()
	{
		return "http://192.168.11.240:8500/v1/kv/DEV";
	}
}
