package com.zycus.guaranteed_delivery_producer.service;

import java.sql.Connection;
import java.sql.DriverManager;
import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.zycus.guaranteed_delivery_producer.dto.CapturedEventData;
import com.zycus.guaranteed_delivery_producer.dto.DBConnection;
import com.zycus.guaranteed_delivery_producer.dto.EventInfo;
import com.zycus.guaranteed_delivery_producer.dto.GDSMessage;

@Service
public class GDSProducerCallBackImpl implements GDSProducerCallBack {

	private static final Logger LOG = LoggerFactory.getLogger(GDSProducerCallBackImpl.class);
	
	static DBConnection dbConnection;
	
	static{
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			Connection connection=DriverManager.getConnection("jdbc:oracle:thin:@192.168.2.197:1521:ORCL","GDS","GDS"); 
			dbConnection= new DBConnection();
			dbConnection.setConnection(connection);
		} catch (Exception e) {
			LOG.error("Unable to create Connection object due to {} ",e);
		}  
	}
	@Override
	public CapturedEventData captureEvent(EventInfo eventInfo) {
		CapturedEventData capturedEventData=new CapturedEventData();
		capturedEventData.setEventInfo(eventInfo);
		List<GDSMessage> messageSet=new ArrayList<GDSMessage>();
		GDSMessage gdsMessage=new GDSMessage();
		gdsMessage.setData("data for sim");
		gdsMessage.setType("TYPEA");
		messageSet.add(gdsMessage);
		
		GDSMessage gdsMessage1=new GDSMessage();
		gdsMessage1.setData("data for Invoice");
		gdsMessage1.setType("TYPEB");
		messageSet.add(gdsMessage1);
		
		
		capturedEventData.setMessageSet(messageSet);
		return capturedEventData;
	}
	
	@Override
	public DBConnection getConnection() {
		return dbConnection;
	}

	@Override
	public void sendNotifcation(String msg) {
		LOG.info("Message "+msg);
	}

}
