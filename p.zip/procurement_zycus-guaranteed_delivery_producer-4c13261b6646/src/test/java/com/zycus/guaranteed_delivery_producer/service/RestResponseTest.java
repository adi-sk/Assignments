package com.zycus.guaranteed_delivery_producer.service;

import java.io.IOException;
import java.util.Date;

import org.json.JSONException;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.junit4.SpringRunner;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.zycus.guaranteed_delivery_producer.dto.Acknowledge;

@RunWith(SpringRunner.class)
public class RestResponseTest {

	String success=" { \"acknowledge\":{\r\n" + 
			"        \"timeStamp\": \"1512552319055\"," + 
			"        \"gdscId\": \"b2f98b36-4819-42b1-8f3d-63502798159e#1512987013099\"" + 
			"    }  }";

	String failure=" { \"acknowledge\" : {" + 
			"        \"errorCode\": \"313\",\r\n" + 
			"        \"errorDescription\": \"Rule not configured\",\r\n" + 
			"        \"stackTrace\": \"com.zycus.integration.GDS.exception.GDSCException: Rule not configured\"" + 
			"    }}";

	@Test
	public void testSuccess() throws JsonParseException, JsonMappingException, IOException, JSONException {
		ObjectMapper objectMapper=new ObjectMapper();
		Acknowledge acknowledge= objectMapper.readValue( success, Acknowledge.class);
		Assert.assertEquals("b2f98b36-4819-42b1-8f3d-63502798159e#1512987013099", acknowledge.getAcknowledge().getGdscId());
		Assert.assertEquals(new Date(1512552319055l), acknowledge.getAcknowledge().getTimeStamp());
	}
	@Test
	public void testFailure() throws JsonParseException, JsonMappingException, IOException, JSONException {
		ObjectMapper objectMapper=new ObjectMapper();
		Acknowledge acknowledge= objectMapper.readValue( failure, Acknowledge.class);
		Assert.assertEquals("313", acknowledge.getAcknowledge().getErrorCode());
		Assert.assertEquals("Rule not configured", acknowledge.getAcknowledge().getErrorDescription());
		Assert.assertEquals("com.zycus.integration.GDS.exception.GDSCException: Rule not configured", acknowledge.getAcknowledge().getStackTrace());
	}
	
}
